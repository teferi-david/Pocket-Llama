#!/usr/bin/env python3
"""Time two local chat turns; excludes microphone, transcription and speech."""
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

from core import SYSTEM_PROMPT, spoken_text

ROOT = Path(__file__).resolve().parent
URL = "http://127.0.0.1:8080/v1/chat/completions"


def measure(messages, max_tokens):
    payload = {
        "model": "pocket-llama", "messages": messages, "stream": True,
        "stream_options": {"include_usage": True}, "max_tokens": max_tokens,
        "temperature": 1.0, "top_p": 1.0, "top_k": 20, "min_p": 0,
        "presence_penalty": 2.0,
        "chat_template_kwargs": {"enable_thinking": False},
        "reasoning_effort": "none",
    }
    request = urllib.request.Request(
        URL, data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    # Ignore proxy environment variables for this localhost-only measurement.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    start = time.perf_counter()
    first = None
    answer = ""
    usage = {}
    finish_reason = None
    with opener.open(request, timeout=180) as response:
        for line in response:
            if not line.startswith(b"data: "):
                continue
            raw = line[6:].strip()
            if raw == b"[DONE]":
                break
            event = json.loads(raw)
            if event.get("error"):
                raise RuntimeError(str(event["error"]))
            usage = event.get("usage") or usage
            choices = event.get("choices") or []
            if not choices:
                continue
            choice = choices[0]
            finish_reason = choice.get("finish_reason") or finish_reason
            answer += choice.get("delta", {}).get("content") or ""
            if first is None and spoken_text(answer).strip():
                first = time.perf_counter() - start
    elapsed = time.perf_counter() - start
    answer = spoken_text(answer)
    if not answer or first is None:
        raise RuntimeError("No visible answer. Check model/template and reasoning settings.")
    return answer, first, elapsed, usage.get("completion_tokens"), finish_reason


def main():
    cfg = json.loads((ROOT / "config.json").read_text())
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    prompts = ["Why does bread rise? Answer in two short sentences.",
               "What happens if I forget the yeast? Answer in two short sentences."]
    print("Pause/close Pocket Llama first so only this test uses the model.")
    print("Two conversational turns; the second can reuse the server's prompt cache.")
    for number, prompt in enumerate(prompts, 1):
        messages.append({"role": "user", "content": prompt})
        answer, first, elapsed, tokens, reason = measure(messages, cfg["max_reply_tokens"])
        print(f"\nTurn {number}: {prompt}")
        print(answer)
        print(f"First visible text: {first:.2f} s; complete answer: {elapsed:.2f} s")
        if tokens is not None:
            print(f"Generated tokens: {tokens}")
        if reason == "length":
            print("Reply reached the token cap; this may be an incomplete answer.")
        messages.append({"role": "assistant", "content": answer})
    print("\nThese are model-only times. Voice adds silence detection, transcription and synthesis.")
    print("The app waits for the complete reply, then speaks sentences with paced captions; first text here is not first audio.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError) as exc:
        raise SystemExit(f"Timing check failed: {exc}. Check pocket-llm service readiness.")
