"""Find and pair Node Llama computers without entering SSH commands."""
import contextlib
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import ssl
import threading
import time
import uuid

from spake2 import SPAKE2_A
from node_protocol import (PORT,SERVICE,VERSION,authenticate,b64,identifier,local_ip,
                           proof,receive,send,ssh_key,unb64,write_json)


class NodeLink:
    def __init__(self, root, emit=lambda value:None, allow_loopback=False):
        self.root, self.emit, self.allow_loopback = Path(root), emit, allow_loopback
        self.root.mkdir(parents=True,exist_ok=True)
        self.root.chmod(0o700)
        self.path = self.root/'nodes.json'
        self.data = json.loads(self.path.read_text()) if self.path.exists() else {
            'pi_id':uuid.uuid4().hex,'preferred':None,'nodes':{}}
        self.lock = threading.RLock()
        self.busy = threading.Lock()
        self.cancelled = threading.Event()
        self.current = None
        write_json(self.path,self.data)

    def update(self, **value):
        self.emit(value)

    def discover(self, seconds=3):
        from zeroconf import Zeroconf, ServiceBrowser, ServiceListener, IPVersion
        found, lock = {}, threading.Lock()
        class Listener(ServiceListener):
            def add_service(inner, zc, type_, name):
                info = zc.get_service_info(type_,name,timeout=1000)
                if not info:
                    return
                props = {k.decode(errors='replace'):v.decode(errors='replace') for k,v in info.properties.items() if isinstance(v,bytes)}
                if props.get('version') != str(VERSION):
                    return
                try:
                    node_id = identifier(props.get('id'))
                except ValueError:
                    return
                ips = [ip for ip in info.parsed_addresses() if local_ip(ip)]
                if not ips or not 1 <= info.port <= 65535:
                    return
                with lock:
                    found[node_id] = {'id':node_id,'name':props.get('name','Node Llama')[:50],
                                      'host':ips[0],'port':info.port}
            def update_service(inner,*args):
                inner.add_service(*args)
            def remove_service(inner,zc,type_,name):
                pass
        try:
            with Zeroconf(ip_version=IPVersion.V4Only) as zc:
                browser=ServiceBrowser(zc,SERVICE,Listener())
                self.cancelled.wait(seconds)
                browser.cancel()
        except OSError:
            pass  # Remembered IPs below still work if multicast is unavailable.
        with lock:
            rows=list(found.values())
        # Last known addresses are a fallback when multicast is blocked.
        for node_id, saved in self.data['nodes'].items():
            if not any(n['id']==node_id for n in rows):
                rows.append({k:saved[k] for k in ('id','name','host','port')})
        reachable=[]
        for node in rows:
            if self.cancelled.is_set():
                break
            try:
                with socket.create_connection((node['host'],node['port']),timeout=.5):
                    pass
                node['paired']=node['id'] in self.data['nodes']
                reachable.append(node)
            except OSError:
                pass
        return sorted(reachable,key=lambda n:(not n['paired'],n['name'].lower()))[:10]

    def begin(self, choose=False):
        if not self.busy.acquire(blocking=False):
            return
        self.cancelled.clear()
        try:
            self.update(mode='search',message='Finding Node Llama on your Wi-Fi...')
            nodes=self.discover()
            if self.cancelled.is_set():
                return
            preferred=next((n for n in nodes if n['id']==self.data.get('preferred')),None)
            paired=[n for n in nodes if n['paired']]
            selected=preferred or (paired[0] if len(paired)==1 else None)
            if choose and nodes:
                self.update(mode='choose',nodes=nodes,message='Choose your computer.')
            elif selected:
                self._connect(selected)
            elif len(nodes)==1:
                self.select(nodes[0])
            elif nodes:
                self.update(mode='choose',nodes=nodes,message='Choose your computer. Signal does not show distance.')
            else:
                self.update(mode='error',message='No Node found. Open Node Llama on the same private Wi-Fi. Check its firewall permission.')
        except Exception as exc:
            self.update(mode='error',message=str(exc)[:200])
        finally:
            self.busy.release()

    def select(self,node):
        if node['id'] in self.data['nodes']:
            self._connect(node)
        else:
            self.current=node
            self.update(mode='code',node=node,message='On this PC press PAIR POCKET LLAMA. Enter its six-digit code here.')

    @contextlib.contextmanager
    def channel(self,node,pinned=None):
        if not local_ip(node['host']) and not (self.allow_loopback and node['host']=='127.0.0.1'):
            raise ValueError('Only private IPv4 LAN computers can be paired.')
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname=False
        context.verify_mode=ssl.CERT_NONE
        context.minimum_version=ssl.TLSVersion.TLSv1_2
        with socket.create_connection((node['host'],int(node['port'])),timeout=5) as raw:
            with context.wrap_socket(raw,server_hostname='node-llama') as sock:
                sock.settimeout(25)
                actual=hashlib.sha256(sock.getpeercert(binary_form=True)).hexdigest()
                if pinned is not None and actual != pinned:
                    raise ValueError('Computer identity changed. Forget this Node and pair again only if you reinstalled it.')
                with sock.makefile('rwb') as stream:
                    yield stream,actual

    def pair(self,code,node=None):
        if not re.fullmatch(r'[0-9]{6}',code):
            raise ValueError('Enter all six digits from the computer.')
        node=node or self.current
        if not node:
            raise ValueError('Find and select your computer first.')
        identifier(node['id'])
        with self.channel(node) as (stream,cert):
            spake=SPAKE2_A(code.encode(),idA=self.data['pi_id'].encode(),idB=node['id'].encode())
            send(stream,{'version':VERSION,'operation':'pair','node_id':node['id'],
                         'pi_id':self.data['pi_id'],'exchange':b64(spake.start())})
            response=receive(stream)
            key=spake.finish(unb64(response.get('exchange')))
            authenticate(response.get('proof'),proof(key,'node',cert,node['id'],self.data['pi_id']))
            send(stream,{'proof':proof(key,'pocket',cert,node['id'],self.data['pi_id'])})
            details=receive(stream)
            if details.get('id') != node['id']:
                raise ValueError('Computer identity changed during pairing.')
            public=ssh_key(details.get('ssh_key'))
            token=details.get('token')
            if not isinstance(token,str) or not 32<=len(token)<=100:
                raise ValueError('Invalid pairing credential.')
            hostkey=self.host_key()
            self.install_key(node['id'],public)
            saved={**node,'fingerprint':cert,'ssh_key':public,'token':token}
            saved.pop('paired',None)
            # Save before the final exchange so a dropped response can be retried.
            with self.lock:
                self.data['nodes'][node['id']]=saved
                self.data['preferred']=node['id']
                write_json(self.path,self.data)
            send(stream,{'user':getpass.getuser(),'hostkey':hostkey,'name':'Pocket Llama · '+socket.gethostname()[:35]})
            receive(stream)
            result=receive(stream)
            self.update(mode='connected',message=result['message'],node=saved)
            return result

    def _connect(self,node):
        saved=self.data['nodes'][node['id']]
        self.update(mode='search',message='Connecting to '+saved['name']+'...')
        with self.channel(node,saved['fingerprint']) as (stream,_):
            send(stream,{'version':VERSION,'operation':'connect','node_id':node['id'],
                         'pi_id':self.data['pi_id'],'token':saved['token']})
            result=receive(stream)
        with self.lock:
            saved.update(host=node['host'],port=node['port'])
            self.data['preferred']=node['id']
            write_json(self.path,self.data)
        self.update(mode='connected',message=result['message'],node=saved)
        return result

    def disconnect(self):
        node=self.data['nodes'].get(self.data.get('preferred'))
        if not node:
            raise ValueError('No paired computer selected.')
        with self.channel(node,node['fingerprint']) as (stream,_):
            send(stream,{'version':VERSION,'operation':'disconnect','node_id':node['id'],
                         'pi_id':self.data['pi_id'],'token':node['token']})
            result=receive(stream)
        self.update(mode='message',message=result['message'])

    def forget_all(self):
        # Removing a key revokes future sessions; an existing tunnel must be closed
        # on Windows (or sshd restarted) to revoke that established session.
        with self.lock:
            self.install_key(None,None)
            self.data['nodes']={}
            self.data['preferred']=None
            write_json(self.path,self.data)
        self.update(mode='message',message='Pairings removed. Close Node Llama on the PC to end any existing tunnel.')

    @staticmethod
    def host_key():
        return ssh_key(Path('/etc/ssh/ssh_host_ed25519_key.pub').read_text())

    def install_key(self,node_id,public):
        path=self.root/'authorized_keys'
        rows=path.read_text().splitlines() if path.exists() else []
        if node_id is None:
            rows=[]
        else:
            identifier(node_id)
            public=ssh_key(public)
            rows=[line for line in rows if not line.endswith(' node-llama:'+node_id)]
            # Installer restricts this account to TCP local forwarding and disables
            # stream-local forwarding. The per-key rule denies shell, PTY, agent, X11.
            rows.append('restrict,port-forwarding,permitopen="127.0.0.1:8080",command="/bin/false" '
                        +public+' node-llama:'+node_id)
        temp=path.with_suffix('.tmp')
        fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(fd,'w') as out:
            out.write('\n'.join(rows)+'\n')
        os.replace(temp,path)
        path.chmod(0o600)
