"""Negotiate hardware audio formats; keep speech recognition at mono 16 kHz."""
from dataclasses import dataclass
import logging
import time

import numpy as np

SPEECH_RATE = 16000
VAD_FRAME_BYTES = 480 * 2  # WebRTC VAD: 30 ms of mono int16 at 16 kHz.


@dataclass(frozen=True)
class AudioFormat:
    device: object
    name: str
    rate: int
    channels: int


def choose_format(sd, device, direction):
    """Probe only the selected device, trying its default rate first."""
    try:
        info = sd.query_devices(device, direction)
    except (sd.PortAudioError, ValueError) as exc:
        raise RuntimeError(
            f"Cannot find the selected {direction} device. "
            "Close Pocket Llama and run .venv/bin/python configure_audio.py "
            f"to select your USB audio devices. Details: {exc}") from exc
    device = info.get("index", device)
    max_channels = int(info[f"max_{direction}_channels"])
    if max_channels < 1:
        raise RuntimeError(f"{info['name']} has no {direction} channels. Run app.py --list-devices.")
    rates = dict.fromkeys([int(round(info["default_samplerate"])), 48000, 44100,
                          16000, 32000, 22050, 24000, 96000])
    check = sd.check_input_settings if direction == "input" else sd.check_output_settings
    last_error = None
    for rate in rates:
        if rate <= 0:
            continue
        for channels in (1, 2):
            if channels > max_channels:
                continue
            try:
                check(device=device, samplerate=rate, channels=channels, dtype="int16")
            except (sd.PortAudioError, ValueError) as exc:
                last_error = exc
                continue
            return AudioFormat(device, info["name"], rate, channels)
    raise RuntimeError(
        f"No supported mono/stereo int16 format for {direction} device {info['name']}. "
        "Close Pocket Llama and run .venv/bin/python configure_audio.py "
        f"to select your USB audio devices (app.py --list-devices lists them). Last error: {last_error}")


def mono_samples(pcm, channels):
    samples = np.frombuffer(pcm, dtype=np.int16).reshape(-1, channels)
    if channels == 1:
        return np.ascontiguousarray(samples[:, 0])
    # Float mixing prevents integer overflow when both channels are loud.
    return np.rint(samples.astype(np.float32).mean(axis=1)).astype(np.int16)


def convert_pcm(pcm, input_rate, input_channels, output_rate, output_channels=1):
    """Resample with an anti-aliasing filter and preserve audio duration/pitch."""
    samples = mono_samples(pcm, input_channels)
    if input_rate != output_rate:
        import soxr
        samples = soxr.resample(samples, input_rate, output_rate, quality="HQ")
    if output_channels > 1:
        samples = np.repeat(samples[:, None], output_channels, axis=1)
    return np.ascontiguousarray(samples, dtype=np.int16).tobytes()


class InputFrames:
    """Stateful resampling plus exact VAD framing across arbitrary input blocks."""
    def __init__(self, audio_format):
        self.format = audio_format
        self.pending = bytearray()
        self.resampler = None
        if audio_format.rate != SPEECH_RATE:
            import soxr
            self.resampler = soxr.ResampleStream(audio_format.rate, SPEECH_RATE, 1,
                                                 dtype="int16", quality="HQ")

    def feed(self, pcm, final=False):
        samples = mono_samples(pcm, self.format.channels)
        if self.resampler is not None:
            samples = self.resampler.resample_chunk(samples, last=final)
        self.pending.extend(samples.tobytes())
        frames = []
        while len(self.pending) >= VAD_FRAME_BYTES:
            frames.append(bytes(self.pending[:VAD_FRAME_BYTES]))
            del self.pending[:VAD_FRAME_BYTES]
        return frames


def play_pcm(pcm, sample_rate, channels, device, cancelled=lambda: False, sd=None,
             on_progress=None):
    if cancelled():
        return
    if sd is None:
        import sounddevice as sd
    audio_format = choose_format(sd, device, "output")
    audio = convert_pcm(pcm, sample_rate, channels, audio_format.rate, audio_format.channels)
    if cancelled():
        return
    logging.info("Playback: %s, %s Hz, %s channels", audio_format.name,
                 audio_format.rate, audio_format.channels)
    step = max(1, int(audio_format.rate * .05)) * audio_format.channels * 2
    with sd.RawOutputStream(device=audio_format.device, samplerate=audio_format.rate,
                            channels=audio_format.channels, dtype="int16") as output:
        start = output.time + output.latency if on_progress else 0
        duration = len(audio)/(2*audio_format.channels*audio_format.rate)
        submitted = 0.0
        for offset in range(0, len(audio), step):
            if cancelled():
                output.abort()
                return
            block = audio[offset:offset + step]
            underflow = output.write(block)
            submitted += len(block)/(2*audio_format.channels*audio_format.rate)
            if on_progress:
                if underflow:
                    # A device stall must not make captions race ahead.
                    start = max(start, output.time + output.latency - submitted)
                on_progress(max(0, min(submitted, output.time-start)))
        if on_progress:
            # The final write can still be buffered; track the device clock
            # through its tail instead of instantly revealing the final words.
            while True:
                if cancelled():
                    output.abort()
                    return
                played = max(0, min(duration, output.time-start))
                on_progress(played)
                if played >= duration:
                    break
                time.sleep(.02)
            output.stop()
            if not cancelled():
                on_progress(duration)
