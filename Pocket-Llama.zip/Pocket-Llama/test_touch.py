import queue
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

import numpy as np

from app import Engine
from core import ManualRecording, TouchGesture
from configure_display import choose_screen
import configure_display
from calibrate_touch import correction
from kiosk_install import BEGIN, END, without_block


class TouchTests(unittest.TestCase):
    def test_first_tap_listens_and_separate_hold_release_sends(self):
        gesture = TouchGesture()
        gesture.press("idle", 0)
        self.assertEqual(gesture.release("idle", .1), "listen")
        gesture.press("listening", 1)
        self.assertLess(gesture.progress(1.5), 1)
        self.assertIsNone(gesture.release("listening", 1.5))
        gesture.press("listening", 2)
        self.assertEqual(gesture.progress(2.8), 1)
        self.assertEqual(gesture.release("listening", 2.8), "send")
        self.assertEqual(gesture.progress(3), 0)

    def test_state_changes_and_leaving_touch_cancel_send(self):
        gesture = TouchGesture()
        gesture.press("listening", 0)
        self.assertIsNone(gesture.release("thinking", 1))
        gesture.press("listening", 2)
        gesture.cancel()
        self.assertIsNone(gesture.release("listening", 3))
        gesture.press("speaking", 4)
        self.assertEqual(gesture.release("speaking", 4.1), "interrupt")

    def test_manual_recording_keeps_silence_until_send(self):
        recording = ManualRecording(20)
        for i in range(100):
            self.assertFalse(recording.feed(b'x', i < 10))
        self.assertEqual(recording.finish(), b'x'*100)

    def test_manual_limit_and_silence_rejection(self):
        recording = ManualRecording(.3)
        for i in range(10):
            limited = recording.feed(b'x', False)
        self.assertTrue(limited)
        self.assertEqual(recording.finish(), b'')
        recording.feed(b'z', True)
        self.assertEqual(len(recording.frames), 10)

    def test_existing_auto_listen_does_not_open_mic_in_touch_mode(self):
        engine = Engine({"auto_listen": True}, queue.Queue())
        self.assertFalse(engine.enabled)
        engine.listen_once()
        self.assertFalse(engine.enabled)
        engine.models_ready.set()
        engine.listen_once()
        self.assertTrue(engine.enabled)
        self.assertFalse(engine.submit_recording.is_set())
        engine.send_recording()
        self.assertTrue(engine.submit_recording.is_set())

    def test_portrait_spi_rotates_and_existing_landscape_is_preserved(self):
        spi = {"name":"SPI-1", "enabled":True, "transform":"normal",
               "modes":[{"width":320,"height":480,"current":True}]}
        hdmi = {"name":"HDMI-A-2", "enabled":True, "transform":"normal",
                "modes":[{"width":1920,"height":1080,"current":True}]}
        self.assertEqual(choose_screen([hdmi, spi]), ("SPI-1", "90"))
        spi["transform"] = "270"
        self.assertEqual(choose_screen([hdmi, spi]), ("SPI-1", "270"))
        with self.assertRaisesRegex(RuntimeError, "SPI-1 is missing"):
            choose_screen([hdmi])

    def test_stale_hdmi_profile_is_repaired_without_losing_calibration(self):
        spi = {"name":"SPI-1", "enabled":True, "transform":"normal",
               "modes":[{"width":320,"height":480,"current":True}]}
        with tempfile.TemporaryDirectory() as directory:
            profile = Path(directory)
            (profile / "display.json").write_text(json.dumps({"output":"HDMI-A-2", "transform":"normal"}))
            (profile / "touch-verified").touch()
            matrix = "0 -1 1 1 0 0"
            (profile / "rc.xml").write_text(
                '<labwc_config><touch deviceName="ADS7846 Touchscreen" mapToOutput="HDMI-A-2"/>'
                '<libinput><device category="ADS7846 Touchscreen"><calibrationMatrix>'
                +matrix+'</calibrationMatrix></device></libinput></labwc_config>')
            with patch.object(configure_display, "PROFILE", profile), patch.object(configure_display, "outputs", return_value=[spi]):
                configure_display.prepare()
                self.assertFalse((profile / "touch-verified").exists())
                (profile / "touch-verified").touch()
                configure_display.prepare()
                self.assertTrue((profile / "touch-verified").exists())
            self.assertEqual(json.loads((profile / "display.json").read_text()), {"output":"SPI-1", "transform":"90"})
            root = ET.parse(profile / "rc.xml").getroot()
            self.assertEqual(root.find("touch").get("mapToOutput"), "SPI-1")
            self.assertEqual(root.find("libinput/device/calibrationMatrix").text, matrix)
            self.assertEqual(len(root.findall("keyboard/keybind")), 1)

    def test_exclusive_boot_disables_hdmi_in_same_layout_and_never_falls_back(self):
        spi = {"name":"SPI-1", "enabled":False, "transform":"normal",
               "modes":[{"width":320,"height":480,"preferred":True}]}
        hdmi = {"name":"HDMI-A-2", "enabled":True}
        with tempfile.TemporaryDirectory() as directory:
            profile = Path(directory)
            (profile / "display.json").write_text(json.dumps({"output":"HDMI-A-2", "transform":"normal"}))
            with patch.object(configure_display, "PROFILE", profile), patch.object(configure_display, "outputs", return_value=[hdmi, spi]), patch.object(configure_display.subprocess, "run") as run:
                configure_display.apply(exclusive=True)
                run.assert_called_once_with(["wlr-randr", "--output", "SPI-1", "--on", "--transform", "90", "--pos", "0,0", "--scale", "1", "--output", "HDMI-A-2", "--off"], check=True, timeout=8)
            with patch.object(configure_display, "PROFILE", profile), patch.object(configure_display, "outputs", return_value=[hdmi]), patch.object(configure_display.subprocess, "run") as run:
                with self.assertRaisesRegex(RuntimeError, "SPI-1 is missing"):
                    configure_display.apply(exclusive=True)
                run.assert_not_called()

    def test_saved_rotation_cannot_force_portrait_on_new_mode(self):
        spi = {"name":"SPI-1", "modes":[{"width":480,"height":320,"preferred":True}]}
        self.assertEqual(choose_screen([spi], "90"), ("SPI-1", "normal"))

    def test_calibration_solves_rotation_and_rejects_collapsed_points(self):
        desired = np.array([[.12,.18],[.88,.18],[.88,.82],[.12,.82]])
        observed = np.column_stack([1-desired[:,1], desired[:,0]])
        fixed = correction(observed, desired)
        actual = np.column_stack([observed, np.ones(4)]) @ fixed.T
        np.testing.assert_allclose(actual[:,:2], desired, atol=1e-8)
        with self.assertRaises(ValueError):
            correction([[.5,.5]]*4, desired)

    def test_kiosk_rollback_only_removes_managed_configuration(self):
        original = "[Seat:*]\nuser-session=LXDE-pi-labwc\n# keep my settings\n"
        managed = original+BEGIN+"[Seat:*]\nautologin-session=pocket-llama\n"+END
        self.assertEqual(without_block(managed), original)
        self.assertEqual(without_block(original), original)


if __name__ == "__main__":
    unittest.main()
