#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $EUID -eq 0 ]]; then
  echo 'Run bash install.sh as your normal Pi user, without sudo.' >&2
  exit 1
fi
if [[ $(dpkg --print-architecture) != arm64 || $(uname -m) != aarch64 ]]; then
  echo 'This installer requires a 64-bit ARM Raspberry Pi OS installation.' >&2
  exit 1
fi
if [[ "$PWD" != "$HOME/Pocket-Llama" ]]; then
  echo 'Place this folder at ~/Pocket-Llama before installing.' >&2
  exit 1
fi
if [[ "$PWD" =~ [[:space:]%] ]]; then
  echo 'Use a home directory without whitespace or percent signs.' >&2
  exit 1
fi
echo 'Installing system libraries (sudo will request your Pi password).'
sudo apt update
sudo apt install -y build-essential cmake git curl pkg-config libcurl4-openssl-dev \
  libopenblas-dev python3-venv python3-dev python3-tk libportaudio2 portaudio19-dev \
  libsndfile1 ffmpeg alsa-utils xwayland fonts-dejavu-core
mkdir -p models voices logs
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
if [[ ! -f config.json ]]; then
  cp config.example.json config.json
fi

if [[ ! -d llama.cpp/.git ]]; then
  git clone --depth 1 https://github.com/ggml-org/llama.cpp.git
fi
cmake -S llama.cpp -B llama.cpp/build -DCMAKE_BUILD_TYPE=Release \
  -DGGML_NATIVE=ON -DGGML_BLAS=ON -DGGML_BLAS_VENDOR=OpenBLAS \
  -DGGML_CUDA=OFF -DGGML_VULKAN=OFF
cmake --build llama.cpp/build --config Release -j 4 --target llama-server

if [[ ! -d whisper.cpp/.git ]]; then
  git clone --depth 1 https://github.com/ggml-org/whisper.cpp.git
fi
cmake -S whisper.cpp -B whisper.cpp/build -DCMAKE_BUILD_TYPE=Release \
  -DGGML_NATIVE=ON -DGGML_CUDA=OFF -DGGML_VULKAN=OFF -DWHISPER_BUILD_SERVER=ON
cmake --build whisper.cpp/build --config Release -j 4 --target whisper-server

model_file=models/Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf
if [[ ! -s "$model_file" ]]; then
  curl --fail --location --retry 3 --continue-at - \
    'https://huggingface.co/mradermacher/Huihui-Qwen3.5-2B-abliterated-GGUF/resolve/f36848fead3fdda244cf60195c46993d23183d4c/Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf' \
    --output "$model_file.part"
  mv "$model_file.part" "$model_file"
fi
if [[ ! -s whisper.cpp/models/ggml-base.en.bin ]]; then
  bash whisper.cpp/models/download-ggml-model.sh base.en
fi
if [[ ! -s voices/en_US-lessac-medium.onnx || ! -s voices/en_US-lessac-medium.onnx.json ]]; then
  .venv/bin/python -m piper.download_voices --data-dir voices en_US-lessac-medium
fi

.venv/bin/python - <<'PY'
import hashlib, json, platform, subprocess
from pathlib import Path
p=Path('models/Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf')
expected_sha256='aa25eea787afe56a097268f7ed3460cb623e1901d2e89cd2b654cabb42f80636'
with p.open('rb') as f:
    if f.read(4) != b'GGUF':
        raise SystemExit('The downloaded model is not a GGUF. Remove it and retry.')
    f.seek(0)
    if hashlib.file_digest(f, 'sha256').hexdigest() != expected_sha256:
        raise SystemExit(f'Model checksum mismatch. Remove {p} and rerun install.sh.')
manifest={'python':platform.python_version(), 'machine':platform.machine(),
          'model':{'file':str(p), 'sha256':expected_sha256,
                   'repo':'mradermacher/Huihui-Qwen3.5-2B-abliterated-GGUF',
                   'revision':'f36848fead3fdda244cf60195c46993d23183d4c'},
          'note':'Records this installation; downloaded source revisions may vary.'}
for repo in ('llama.cpp','whisper.cpp'):
    manifest[repo]=subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
Path('installed-versions.json').write_text(json.dumps(manifest,indent=2)+'\n')
Path('installed-python-packages.txt').write_text(subprocess.check_output(
    ['.venv/bin/python','-m','pip','freeze'],text=True))
PY
echo 'Dependencies and model downloads complete. Next: bash enable-services.sh'
