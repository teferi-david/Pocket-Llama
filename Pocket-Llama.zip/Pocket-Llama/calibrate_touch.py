"""Recoverable touch calibration for Pocket Llama's dedicated labwc session."""
import argparse
from pathlib import Path
import subprocess
import time
import tkinter as tk
import xml.etree.ElementTree as ET
import numpy as np

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / ".kiosk"
TARGETS = [(.14, .18), (.86, .18), (.86, .70), (.14, .70)]
CHECKS = [(.25, .28), (.75, .65)]


def correction(observed, targets):
    inputs = np.array([[x, y, 1] for x, y in observed], dtype=float)
    if not np.all(np.isfinite(inputs)) or np.linalg.matrix_rank(inputs) != 3:
        raise ValueError("Touches were too close together.")
    matrix, _, _, _ = np.linalg.lstsq(inputs, np.asarray(targets), rcond=None)
    if np.max(np.abs(inputs @ matrix - targets)) > .1:
        raise ValueError("Touches did not match the targets.")
    gains = np.linalg.svd(matrix[:2].T, compute_uv=False)
    if gains.min() < .25 or gains.max() > 4:
        raise ValueError("Touch positions were too distorted.")
    return np.vstack((matrix.T, [0, 0, 1]))


class TouchSamples:
    """One median press position per target; release coordinates are not sampled."""
    def __init__(self):
        self.reset(0)

    def reset(self, now, delay=.65):
        self.ready_at = now + delay
        self.started = None
        self.samples = []

    def press(self, point, now):
        if now < self.ready_at or self.started is not None:
            return
        self.started = now
        self.samples = [point]

    def move(self, point):
        if self.started is not None:
            self.samples.append(point)
            self.samples = self.samples[-100:]

    def release(self, now):
        if self.started is None:
            return None
        started, samples = self.started, self.samples
        self.started, self.samples = None, []
        self.ready_at = now + .65
        if now - started < .06:
            return None
        values = np.asarray(samples, dtype=float)
        point = np.median(values, axis=0)
        if not np.all(np.isfinite(point)):
            raise ValueError("Please touch the cross again.")
        # A late lift-off jump may be an outlier; a drag must not become a tap.
        deviations = np.linalg.norm(values - point, axis=1)
        if np.median(deviations) > .05:
            raise ValueError("Keep your finger still, then lift it.")
        return point.tolist()


def atomic_bytes(path, data):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(data)
    temporary.replace(path)


def reload_labwc():
    subprocess.run(["labwc", "--reconfigure"], check=True, timeout=5,
                   capture_output=True, text=True)


class ProfileChange:
    """A candidate matrix is kept only after the two check targets pass."""
    def __init__(self, profile, reload=reload_labwc):
        self.path = profile / "rc.xml"
        self.backup = profile / "rc.xml.calibration-pending"
        self.reload = reload
        self.pending = False
        # Recover an interrupted earlier candidate before sampling new points.
        if self.backup.exists():
            atomic_bytes(self.path, self.backup.read_bytes())
            self.reload()
            self.backup.unlink()
        self.original = self.path.read_bytes()

    def apply(self, fix):
        root = ET.fromstring(self.original)
        for node in root.iter():
            node.tag = node.tag.split("}")[-1]
        libinput = root.find("libinput")
        if libinput is None:
            libinput = ET.SubElement(root, "libinput")
        device = next((x for x in libinput.findall("device")
                       if x.get("category") == "ADS7846 Touchscreen"), None)
        if device is None:
            device = ET.SubElement(libinput, "device", category="ADS7846 Touchscreen")
        calibration = device.find("calibrationMatrix")
        if calibration is None:
            calibration = ET.SubElement(device, "calibrationMatrix")
        values = [float(x) for x in (calibration.text or "1 0 0 0 1 0").split()]
        if len(values) != 6 or not np.all(np.isfinite(values)):
            raise ValueError("Existing touch matrix must contain six finite numbers.")
        old = np.array(values + [0, 0, 1]).reshape(3, 3)
        calibration.text = " ".join(f"{x:.8f}" for x in (fix @ old)[:2].flatten())
        ET.indent(root)
        atomic_bytes(self.backup, self.original)
        self.pending = True
        atomic_bytes(self.path, ET.tostring(root, encoding="utf-8", xml_declaration=True))
        try:
            self.reload()
        except Exception:
            self.restore()
            raise

    def restore(self):
        if self.pending:
            atomic_bytes(self.path, self.original)
            # Keep the recovery copy if reload fails, so next boot can restore it.
            self.reload()
            self.backup.unlink(missing_ok=True)
            self.pending = False

    def commit(self):
        self.backup.unlink(missing_ok=True)
        self.pending = False
        self.original = self.path.read_bytes()


def mark_skipped(profile):
    profile.mkdir(exist_ok=True)
    (profile / "touch-skipped").write_text("Calibration skipped; existing touch settings retained.\n")
    (profile / "touch-verified").unlink(missing_ok=True)


class CalibrationSession:
    def __init__(self, profile, change):
        self.profile, self.change = profile, change
        self.stage, self.observed, self.index = "collect", [], 0
        self.error = ""

    @property
    def target(self):
        return (CHECKS if self.stage == "verify" else TARGETS)[self.index]

    def fail(self, message):
        try:
            self.change.restore()
        except Exception as exc:
            message += f" Restore needs a reboot: {exc}"
        self.stage, self.error = "error", message

    def retry(self):
        self.change.restore()
        self.stage, self.observed, self.index, self.error = "collect", [], 0, ""

    def accept(self, point):
        if self.stage not in ("collect", "verify"):
            return
        if self.stage == "verify":
            if np.linalg.norm(np.asarray(point) - self.target) > .08:
                self.fail("Check missed. Previous settings restored.")
                return
            self.index += 1
            if self.index == len(CHECKS):
                self.change.commit()
                (self.profile / "touch-verified").write_text("Touch calibration checked.\n")
                (self.profile / "touch-skipped").unlink(missing_ok=True)
                self.stage = "done"
            return
        self.observed.append(point)
        self.index += 1
        if self.index == len(TARGETS):
            try:
                # Already-aligned touch needs no new matrix at all.
                if np.max(np.linalg.norm(np.asarray(self.observed)-TARGETS, axis=1)) > .05:
                    self.change.apply(correction(self.observed, TARGETS))
                self.stage, self.index = "verify", 0
            except Exception as exc:
                self.fail(str(exc))

    def skip(self):
        self.change.restore()
        mark_skipped(self.profile)
        self.stage = "done"


class CalibrationWindow:
    def __init__(self, session, fullscreen=True):
        self.session = session
        self.root = tk.Tk()
        self.root.title("Pocket Llama touch setup")
        self.root.geometry("480x320")
        self.root.configure(bg="black")
        self.root.attributes("-fullscreen", fullscreen)
        self.canvas = tk.Canvas(self.root, bg="black", highlightthickness=0, cursor="crosshair")
        self.canvas.pack(fill="both", expand=True)
        self.samples = TouchSamples()
        self.size = None
        self.message = ""
        self.ready = False
        self.paint_timer = None
        self.skip_button = tk.Button(self.root, text="SKIP / KEEP TOUCH", command=self.skip,
                                    font=("DejaVu Sans Mono", 10, "bold"), takefocus=True)
        self.skip_button.place(relx=.02, rely=1, y=-8, anchor="sw", relwidth=.54, height=38)
        self.retry_button = tk.Button(self.root, text="RETRY", command=self.retry,
                                     font=("DejaVu Sans Mono", 10, "bold"))
        self.retry_button.place(relx=.98, rely=1, y=-8, anchor="se", relwidth=.38, height=38)
        self.canvas.bind("<Configure>", self.resize)
        self.canvas.bind("<ButtonPress-1>", self.press)
        self.canvas.bind("<B1-Motion>", self.motion)
        self.canvas.bind("<ButtonRelease-1>", self.release)
        self.root.bind("<Escape>", lambda e: self.skip())
        self.root.protocol("WM_DELETE_WINDOW", self.skip)
        self.focus_timer = self.root.after(100, self.root.focus_force)

    def close(self):
        for timer in (self.paint_timer, self.focus_timer):
            if timer is not None:
                self.root.after_cancel(timer)
        self.root.destroy()

    def point(self, event):
        return (event.x / max(1, self.canvas.winfo_width()),
                event.y / max(1, self.canvas.winfo_height()))

    def resize(self, event):
        size = (event.width, event.height)
        if size == self.size:
            return
        self.size = size
        # Fullscreen can settle after Tk initially maps its window.
        if self.session.observed or self.session.stage == "verify":
            try:
                self.session.retry()
            except Exception as exc:
                self.session.fail(str(exc))
        self.new_target()

    def new_target(self):
        if self.paint_timer is not None:
            self.root.after_cancel(self.paint_timer)
        self.ready = False
        self.samples.reset(time.monotonic())
        self.draw()
        def ready():
            self.paint_timer = None
            self.ready = True
            self.draw()
        self.paint_timer = self.root.after(650, ready)

    def draw(self):
        self.canvas.delete("all")
        width, height = self.size or (480, 320)
        stage = self.session.stage
        title = "TOUCH SETUP PAUSED" if stage == "error" else (
            f"CHECK TOUCH {self.session.index+1}/2" if stage == "verify"
            else f"SET UP TOUCH {self.session.index+1}/4")
        self.canvas.create_text(width/2, height*.36, text=title, fill="white",
                                font=("DejaVu Sans Mono", 12, "bold"))
        detail = self.session.error if stage == "error" else (
            self.message or ("Touch the white cross, then lift your finger."
                             if self.ready else "Lift your finger. Wait for the white cross."))
        self.canvas.create_text(width/2, height*.49, text=detail, fill="white", width=width-28,
                                font=("DejaVu Sans Mono", 10))
        self.canvas.create_text(width/2, height*.79, text="Esc: keep touch settings and continue",
                                fill="#cccccc", font=("DejaVu Sans Mono", 9))
        if stage in ("collect", "verify"):
            x, y = self.session.target
            x, y = x*width, y*height
            color = "white" if self.ready else "#555555"
            self.canvas.create_oval(x-22, y-22, x+22, y+22, outline=color, width=2)
            self.canvas.create_line(x-16, y, x+16, y, fill=color, width=3)
            self.canvas.create_line(x, y-16, x, y+16, fill=color, width=3)

    def press(self, event):
        if self.ready and self.session.stage in ("collect", "verify"):
            self.samples.press(self.point(event), time.monotonic())

    def motion(self, event):
        self.samples.move(self.point(event))

    def release(self, event):
        # Deliberately ignore event.x/y at lift-off.
        try:
            point = self.samples.release(time.monotonic())
            if point is None:
                return
            self.message = ""
            self.session.accept(point)
        except Exception as exc:
            self.message = str(exc)
        if self.session.stage == "done":
            self.close()
        else:
            self.new_target()

    def retry(self):
        try:
            self.session.retry()
            self.message = ""
        except Exception as exc:
            self.session.fail(str(exc))
        self.new_target()

    def skip(self):
        try:
            self.session.skip()
        except Exception as exc:
            self.session.fail(str(exc))
            self.draw()
            return
        self.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    options = parser.add_mutually_exclusive_group()
    options.add_argument("--skip", action="store_true", help="Keep current touch settings and skip future startup calibration")
    options.add_argument("--retry-next-boot", action="store_true", help="Show calibration on the next boot")
    args = parser.parse_args()
    if args.skip:
        # This also works through SSH, without an active Wayland environment.
        pending = PROFILE / "rc.xml.calibration-pending"
        if pending.exists():
            atomic_bytes(PROFILE / "rc.xml", pending.read_bytes())
            pending.unlink()
            print("Restored pre-calibration settings on disk. Reboot to apply them.")
        mark_skipped(PROFILE)
        print("Calibration skipped. Existing touch mapping retained; reboot to continue.")
        return
    if args.retry_next_boot:
        for name in ("touch-skipped", "touch-verified"):
            (PROFILE / name).unlink(missing_ok=True)
        print("Touch setup will appear on the next boot.")
        return
    from configure_display import outputs
    if not any(x["name"] == "SPI-1" and x.get("enabled") for x in outputs()):
        raise SystemExit("SPI-1 is not active; cannot calibrate it.")
    change = ProfileChange(PROFILE)
    try:
        window = CalibrationWindow(CalibrationSession(PROFILE, change))
        window.root.mainloop()
    finally:
        change.restore()


if __name__ == "__main__":
    main()
