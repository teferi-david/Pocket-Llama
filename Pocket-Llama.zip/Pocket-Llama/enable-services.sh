#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $EUID -eq 0 || "$PWD" != "$HOME/Pocket-Llama" || "$PWD" =~ [[:space:]%] ]]; then
  echo 'Run as your normal user from ~/Pocket-Llama (no spaces in the path).' >&2
  exit 1
fi
test -x llama.cpp/build/bin/llama-server
test -x whisper.cpp/build/bin/whisper-server
test -s models/Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf
test -s whisper.cpp/models/ggml-base.en.bin
pi_user=$(id -un)
pi_group=$(id -gn)
for engine in llm stt; do
  sudo tee "/etc/systemd/system/pocket-${engine}.service" >/dev/null <<EOF
[Unit]
Description=Pocket Llama ${engine} local model server
After=local-fs.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=${pi_user}
Group=${pi_group}
WorkingDirectory=${PWD}
ExecStart=/bin/bash ${PWD}/run-${engine}.sh
Restart=on-failure
RestartSec=5
TimeoutStopSec=15
NoNewPrivileges=true
PrivateTmp=true
UMask=0077

[Install]
WantedBy=multi-user.target
EOF
done
sudo systemctl daemon-reload
sudo systemctl enable pocket-llm pocket-stt
sudo systemctl restart pocket-llm pocket-stt
echo 'Model services enabled. Check readiness with curl http://127.0.0.1:8080/health'
