"""Local pairing protocol v1. TLS certificate binding + SPAKE2 code authentication."""
import base64
import hashlib
import hmac
import ipaddress
import json
import os
from pathlib import Path
import re
import socket

SERVICE = '_nodellama._tcp.local.'
PORT = 8878
VERSION = 1
NETWORKS = tuple(ipaddress.ip_network(n) for n in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','169.254.0.0/16'))


def local_ip(value):
    try:
        ip = ipaddress.ip_address(value)
        return ip.version == 4 and any(ip in n for n in NETWORKS)
    except ValueError:
        return False


def addresses():
    import ifaddr
    try:
        return sorted({ip.ip for adapter in ifaddr.get_adapters() for ip in adapter.ips
                       if isinstance(ip.ip, str) and local_ip(ip.ip)})
    except OSError:
        return []


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch('[a-f0-9]{32}', value):
        raise ValueError('Invalid device identity.')
    return value


def ssh_key(value):
    from cryptography.hazmat.primitives.serialization import load_ssh_public_key
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    if not isinstance(value, str) or len(value) > 500 or '\n' in value or '\r' in value:
        raise ValueError('Invalid SSH key.')
    parts = value.split()
    if len(parts) < 2 or parts[0] != 'ssh-ed25519':
        raise ValueError('An Ed25519 SSH key is required.')
    key = ' '.join(parts[:2])
    if not isinstance(load_ssh_public_key(key.encode()), Ed25519PublicKey):
        raise ValueError('Invalid SSH key type.')
    return key


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as output:
        json.dump(value, output, indent=2)
        output.write('\n')
    os.replace(temporary, path)
    if os.name != 'nt':
        path.chmod(0o600)


def send(stream, value):
    raw = json.dumps(value, separators=(',', ':')).encode() + b'\n'
    if len(raw) > 16384:
        raise ValueError('Pairing message is too large.')
    stream.write(raw)
    stream.flush()


def receive(stream):
    raw = stream.readline(16385)
    if not raw or len(raw) > 16384 or not raw.endswith(b'\n'):
        raise ValueError('Incomplete or oversized pairing message.')
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError('Invalid pairing message.')
    if value.get('error'):
        raise ValueError(str(value['error'])[:300])
    return value


def b64(value):
    return base64.b64encode(value).decode()


def unb64(value):
    if not isinstance(value, str) or len(value) > 300:
        raise ValueError('Invalid pairing exchange.')
    return base64.b64decode(value, validate=True)


def proof(key, role, certificate, node_id, pi_id):
    binding = f'node-llama-v1|{role}|{certificate}|{identifier(node_id)}|{identifier(pi_id)}'
    return hmac.new(key, binding.encode(), hashlib.sha256).hexdigest()


def authenticate(value, expected):
    if not isinstance(value, str) or not hmac.compare_digest(value, expected):
        raise ValueError('Pairing code did not match. Open a new code on your computer and retry.')


def wake_text(text):
    """Exact leading wake phrase; normal chat cannot trigger on embedded text."""
    match = re.match(r'^\s*(?:hey[ ,.!?]+)?(?:llama|lama)[\s,.!?]*(.*)$', text, re.I)
    if not match or (len(text) > match.start() and re.match(r'^\s*(?:hey\s+)?(?:llama|lama)[a-z]', text, re.I)):
        return None
    return match.group(1).strip()


def connection_command(text):
    value = re.sub(r'[^a-z ]', '', text.lower())
    value = ' '.join(value.split())
    if value in ('connect to node', 'connect to node llama', 'connect node', 'connect to my node'):
        return 'connect'
    if value in ('disconnect from node', 'disconnect node', 'disconnect from node llama'):
        return 'disconnect'
    return None
