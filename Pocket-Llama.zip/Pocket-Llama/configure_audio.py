#!/usr/bin/env python3
"""Select physical audio devices without retaining changeable ALSA card numbers."""
import argparse
import fcntl
import json
from pathlib import Path
import re
import shutil

from audio_io import choose_format

ROOT = Path(__file__).resolve().parent


def stable_selector(sd, index, direction):
    info = sd.query_devices(index, direction)
    # Card numbers in '(hw:2,0)' can change when HDMI or USB devices change.
    name = re.sub(r"\s*\(hw:\d+,\d+(?:,\d+)?\)\s*$", "", info["name"]).strip()
    if name.lower() in {"default", "sysdefault", "pulse", "pipewire", "dmix"}:
        raise ValueError("Choose the named USB hardware so it stays selected after reboot.")
    try:
        resolved = sd.query_devices(name, direction)
    except (ValueError, sd.PortAudioError) as exc:
        raise ValueError(
            "The name is not unique. Disconnect the unused duplicate audio device, "
            "then rerun setup.") from exc
    if resolved["index"] != index:
        raise ValueError("That name resolves to a different device; configuration was not saved.")
    return name


def select_device(sd, direction):
    devices = sd.query_devices()
    available = {i: d for i, d in enumerate(devices) if d[f"max_{direction}_channels"] > 0}
    if not available:
        raise RuntimeError(f"No {direction} devices found. Connect your USB audio hardware and rerun.")
    label = "microphone" if direction == "input" else "speaker or earbuds"
    print(f"\nChoose your USB {label}:")
    for index, info in available.items():
        note = " [HDMI monitor audio]" if "hdmi" in info["name"].lower() else ""
        print(f"  {index}: {info['name']}{note}")
    while True:
        answer = input("Enter its number above (q to cancel): ").strip()
        if answer.lower() == "q":
            raise KeyboardInterrupt
        try:
            index = int(answer)
            if index not in available:
                raise ValueError("Choose a number from this list.")
            if "hdmi" in available[index]["name"].lower():
                raise ValueError("The small-screen session disables HDMI. Choose your USB audio hardware.")
            selector = stable_selector(sd, index, direction)
            fmt = choose_format(sd, selector, direction)
        except (ValueError, RuntimeError, sd.PortAudioError) as exc:
            print(f"Could not use that device: {exc}")
            continue
        print(f"Selected: {selector} ({fmt.rate} Hz, {fmt.channels} channel(s))")
        return selector


def save_devices(path, selections):
    cfg = json.loads(path.read_text())
    cfg.update(selections)
    backup = path.with_name("config.before-audio.json")
    if not backup.exists():
        shutil.copy2(path, backup)
    temporary = path.with_name("config.audio-tmp.json")
    temporary.write_text(json.dumps(cfg, indent=2) + "\n")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-only", action="store_true", help="Keep the existing microphone selection")
    args = parser.parse_args()
    import sounddevice as sd
    if not (ROOT / "config.json").exists():
        raise SystemExit("config.json is missing. Run install.sh first.")
    with (ROOT / ".app.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit("Close the Pocket Llama window before configuring audio.")
        try:
            selections = {}
            if not args.output_only:
                selections["input_device"] = select_device(sd, "input")
            selections["output_device"] = select_device(sd, "output")
            save_devices(ROOT / "config.json", selections)
        except (EOFError, KeyboardInterrupt):
            raise SystemExit("\nCancelled; config.json was not changed.")
        except RuntimeError as exc:
            raise SystemExit(str(exc))
    print("\nSaved audio devices by name. Now check recording and audible playback:")
    print("  .venv/bin/python app.py --test-audio")


if __name__ == "__main__":
    main()
