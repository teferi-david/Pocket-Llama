"""Keep display changes in Pocket Llama's own labwc profile."""
import argparse
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / ".kiosk"


def outputs():
    return json.loads(subprocess.check_output(["wlr-randr", "--json"], text=True, timeout=8))


def choose_screen(items, saved_transform=None):
    target = next((x for x in items if x["name"] == "SPI-1"), None)
    if target is None:
        raise RuntimeError("SPI-1 is missing. Check the small screen with wlr-randr. "
                           "Pocket Llama will not launch on HDMI.")
    modes = target.get("modes", [])
    mode = next((m for m in modes if m.get("current")), None)
    mode = mode or next((m for m in modes if m.get("preferred")), None)
    if mode is None:
        raise RuntimeError("The selected display has no usable mode.")
    transform = saved_transform or target.get("transform", "normal")
    portrait_mode = mode["height"] > mode["width"]
    swapped = transform in ("90", "270", "flipped-90", "flipped-270")
    if portrait_mode != swapped:
        transform = "90" if portrait_mode else "normal"
    return target["name"], transform


def prepare():
    items = outputs()
    path = PROFILE / "display.json"
    previous = json.loads(path.read_text()) if path.exists() else {}
    saved_transform = previous.get("transform") if previous.get("output") == "SPI-1" else None
    name, transform = choose_screen(items, saved_transform)
    PROFILE.mkdir(exist_ok=True)
    settings = {"output": name, "transform": transform}
    path.write_text(json.dumps(settings, indent=2)+"\n")
    if previous != settings:
        (PROFILE / "touch-verified").unlink(missing_ok=True)
        (PROFILE / "touch-skipped").unlink(missing_ok=True)
    target = PROFILE / "rc.xml"
    source = target if target.exists() else Path.home() / ".config/labwc/rc.xml"
    root = ET.parse(source).getroot() if source.exists() else ET.Element("labwc_config")
    for node in root.iter():
        node.tag = node.tag.split("}")[-1]
    # Repair old HDMI mappings while preserving existing device calibration.
    for node in list(root.findall("touch")):
        if node.get("deviceName", "") in ("", "ADS7846 Touchscreen"):
            root.remove(node)
    ET.SubElement(root, "touch", deviceName="ADS7846 Touchscreen",
                  mapToOutput="SPI-1", mouseEmulation="yes")
    libinput = root.find("libinput")
    if libinput is None:
        libinput = ET.SubElement(root, "libinput")
    device = next((x for x in libinput.findall("device") if x.get("category") == "ADS7846 Touchscreen"), None)
    if device is None:
        device = ET.SubElement(libinput, "device", category="ADS7846 Touchscreen")
    matrix = device.find("calibrationMatrix")
    if matrix is None:
        matrix = ET.SubElement(device, "calibrationMatrix")
        matrix.text = "1 0 0 0 1 0"
    keyboard = root.find("keyboard")
    if keyboard is None:
        keyboard = ET.SubElement(root, "keyboard")
    if not any(x.get("key") == "C-A-t" for x in keyboard.findall("keybind")):
        bind = ET.SubElement(keyboard, "keybind", key="C-A-t")
        ET.SubElement(bind, "action", name="Execute", command="foot")
    ET.indent(root)
    ET.ElementTree(root).write(target, encoding="unicode", xml_declaration=True)
    # An explicit empty startup file prevents the Raspberry Pi desktop startup.
    (PROFILE / "autostart").write_text("#!/bin/sh\n# Pocket Llama is the session client.\n")
    (PROFILE / "shutdown").write_text("#!/bin/sh\n")
    (PROFILE / "xinitrc").write_text("#!/bin/sh\n")
    (PROFILE / "environment").write_text("XCURSOR_SIZE=16\n")
    print(f"Prepared dedicated display: {settings['output']}, transform {settings['transform']}.")


def apply(exclusive=False):
    settings = json.loads((PROFILE / "display.json").read_text())
    items = outputs()
    saved_transform = settings.get("transform") if settings.get("output") == "SPI-1" else None
    name, transform = choose_screen(items, saved_transform)
    command = ["wlr-randr", "--output", name, "--on", "--transform", transform,
               "--pos", "0,0", "--scale", "1"]
    if exclusive:
        for item in items:
            if item["name"] != name and item.get("enabled"):
                command.extend(["--output", item["name"], "--off"])
    # Apply the complete layout together before opening the app.
    subprocess.run(command, check=True, timeout=8)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--prepare", action="store_true")
    p.add_argument("--apply", action="store_true")
    p.add_argument("--exclusive", action="store_true")
    args = p.parse_args()
    if args.prepare:
        prepare()
    if args.apply:
        apply(args.exclusive)
