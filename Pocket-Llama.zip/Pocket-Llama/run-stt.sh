#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
exec ./whisper.cpp/build/bin/whisper-server \
  --model ./whisper.cpp/models/ggml-base.en.bin \
  --host 127.0.0.1 --port 8081 --threads 4 --language en --no-gpu \
  --public ./whisper.cpp/examples/server/public
