#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $EUID -eq 0 || "$PWD" != "$HOME/Pocket-Llama" || "$PWD" =~ [[:space:]%] ]]; then
  echo 'Run as your desktop user from ~/Pocket-Llama.' >&2
  exit 1
fi
hailo_python="$HOME/hailo-apps/.venv/bin/python"
test -x "$hailo_python"
"$hailo_python" -c 'import hailo_platform, flask; import hailo_apps'
pi_user=$(id -un)
pi_group=$(id -gn)
sudo tee /etc/systemd/system/pocket-hailo.service >/dev/null <<EOF
[Unit]
Description=Pocket Llama experimental Hailo-8 speech service
After=local-fs.target
StartLimitIntervalSec=0

[Service]
User=${pi_user}
Group=${pi_group}
WorkingDirectory=${HOME}/hailo-apps
ExecStart=${hailo_python} ${PWD}/hailo-bridge.py
Environment=HF_HUB_OFFLINE=1
Environment=TRANSFORMERS_OFFLINE=1
Restart=on-failure
RestartSec=10
TimeoutStopSec=15
UMask=0077

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now pocket-hailo
ready=0
for attempt in {1..120}; do
  if curl --silent --fail --max-time 2 http://127.0.0.1:8082/health >/dev/null; then
    ready=1
    break
  fi
  sleep 1
done
if [[ $ready != 1 ]]; then
  echo 'Hailo did not become ready. CPU speech config is unchanged.' >&2
  echo 'Inspect: journalctl -u pocket-hailo -n 80 --no-pager' >&2
  exit 1
fi
.venv/bin/python - <<'PY'
import json
from pathlib import Path
p=Path('config.json')
c=json.loads(p.read_text())
c.update(stt_backend='hailo',stt_url='http://127.0.0.1:8082')
p.write_text(json.dumps(c,indent=2)+'\n')
PY
sudo systemctl disable --now pocket-stt
echo 'Hailo selected. Close and reopen Pocket Llama, or reboot.'
