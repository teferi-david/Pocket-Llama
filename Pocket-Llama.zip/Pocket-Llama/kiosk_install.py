"""Root-only LightDM session registration; leave existing settings intact."""
import argparse
import os
from pathlib import Path
import pwd
import re

BEGIN = "# BEGIN POCKET LLAMA KIOSK\n"
END = "# END POCKET LLAMA KIOSK\n"


def without_block(text):
    return re.sub(re.escape(BEGIN)+r".*?"+re.escape(END), "", text, flags=re.S)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--enable", action="store_true")
    p.add_argument("--disable", action="store_true")
    p.add_argument("--user", required=True)
    p.add_argument("--project", required=True)
    args = p.parse_args()
    if os.geteuid() != 0:
        raise SystemExit("Run through enable-kiosk.sh or disable-kiosk.sh.")
    user = pwd.getpwnam(args.user)
    project = Path(args.project).resolve()
    if project != Path(user.pw_dir) / "Pocket-Llama" or re.search(r"[\s%]", str(project)):
        raise SystemExit("Expected the installing user's ~/Pocket-Llama directory.")
    conf = Path("/etc/lightdm/lightdm.conf")
    original = conf.read_text() if conf.exists() else ""
    clean = without_block(original)
    session = Path("/usr/share/wayland-sessions/pocket-llama.desktop")
    if args.enable:
        backup = Path("/etc/lightdm/lightdm.conf.before-pocket-llama")
        if not backup.exists():
            backup.write_text(original)
        session.parent.mkdir(parents=True, exist_ok=True)
        session.write_text(f"[Desktop Entry]\nName=Pocket Llama\nComment=Dedicated offline assistant\nExec=/bin/bash {project}/kiosk-session.sh\nType=Application\nDesktopNames=labwc\n")
        # LightDM merges repeated groups; the final values override earlier ones.
        clean += f"\n{BEGIN}[Seat:seat0]\nautologin-user={args.user}\nautologin-user-timeout=0\nautologin-session=pocket-llama\n{END}"
    elif args.disable:
        session.unlink(missing_ok=True)
    conf.write_text(clean)
    print("Dedicated startup enabled." if args.enable else "Previous desktop login settings restored.")


if __name__ == "__main__":
    main()
