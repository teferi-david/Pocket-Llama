#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $EUID -eq 0 || "$PWD" != "$HOME/Pocket-Llama" || "$PWD" =~ [[:space:]%] ]]; then
  echo 'Run as your normal desktop user from ~/Pocket-Llama.' >&2
  exit 1
fi
if [[ -z ${WAYLAND_DISPLAY:-} ]]; then
  echo 'Run this in the Pi desktop terminal, where the working screen is connected.' >&2
  exit 1
fi
test -f config.json
test -x .venv/bin/python
systemctl cat lightdm.service >/dev/null
sudo apt-get install -y labwc wlr-randr xwayland foot fonts-dejavu-core
.venv/bin/python -m pip install 'Pillow>=11,<13'
python3 configure_display.py --prepare
# Disable the old duplicate app launcher while this dedicated session is active.
if [[ -f "$HOME/.config/autostart/pocket-llama.desktop" ]]; then
  mv "$HOME/.config/autostart/pocket-llama.desktop" "$HOME/.config/autostart/pocket-llama.desktop.before-kiosk"
fi
sudo python3 kiosk_install.py --enable --user "$(id -un)" --project "$PWD"
sudo systemctl set-default graphical.target
sudo systemctl enable lightdm.service pocket-llm.service
backend=$(.venv/bin/python -c 'import json; print(json.load(open("config.json"))["stt_backend"])')
if [[ $backend == hailo ]]; then
  sudo systemctl enable pocket-hailo.service
else
  sudo systemctl enable pocket-stt.service
fi
echo 'Ready. Reboot when convenient. First kiosk boot asks you to tap calibration targets.'
echo 'Recovery: bash ~/Pocket-Llama/disable-kiosk.sh, then reboot.'
