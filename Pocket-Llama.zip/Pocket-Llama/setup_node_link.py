"""One-time SSH configuration for code pairing; preserves normal SSH login keys."""
import getpass
import json
from pathlib import Path
import re
import subprocess
import tempfile

from node_protocol import write_json

ROOT=Path(__file__).resolve().parent


def run(*args,**kw):
    return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout


def main():
    user=getpass.getuser()
    if user=='root' or not re.fullmatch('[a-zA-Z_][a-zA-Z0-9_-]{0,31}',user):
        raise SystemExit('Run this as the normal Pi user, without sudo.')
    if ROOT != Path.home()/'Pocket-Llama' or any(c.isspace() for c in str(ROOT)):
        raise SystemExit('Keep the application in ~/Pocket-Llama without spaces in the path.')
    folder=ROOT/'.node-link'
    folder.mkdir(exist_ok=True,mode=0o700)
    if folder.is_symlink():
        raise SystemExit('The pairing folder must not be a symlink.')
    folder.chmod(0o700)
    conf=Path('/etc/ssh/sshd_config.d/80-pocket-llama-node.conf')
    previous=run('sudo','cat',str(conf)) if conf.exists() else None
    path=str(folder/'authorized_keys')
    text=(f'Match User {user}\n'
          f'    AuthorizedKeysFile .ssh/authorized_keys .ssh/authorized_keys2 {path}\n'
          '    AllowTcpForwarding local\n'
          '    AllowStreamLocalForwarding no\n'
          'Match all\n')
    with tempfile.TemporaryDirectory(prefix='pocket-node-') as temp:
        source=Path(temp)/'config'
        source.write_text(text)
        if previous is not None:
            backup=folder/'sshd-config-before-node.txt'
            if not backup.exists():backup.write_text(previous)
        try:
            run('sudo','install','-m','644',str(source),str(conf))
            run('sudo','/usr/sbin/sshd','-t')
            effective=run('sudo','/usr/sbin/sshd','-T','-C',f'user={user},host=localhost,addr=127.0.0.1')
            if (path not in effective or 'allowtcpforwarding local\n' not in effective
                    or 'allowstreamlocalforwarding no\n' not in effective):
                raise RuntimeError('Another SSH rule overrides the Node settings; no change was kept.')
            run('sudo','systemctl','enable','--now','ssh')
            run('sudo','systemctl','reload','ssh')
        except Exception:
            if previous is None:run('sudo','rm','-f',str(conf))
            else:
                source.write_text(previous)
                run('sudo','install','-m','644',str(source),str(conf))
            raise
    cfg_path=ROOT/'config.json'
    cfg=json.loads(cfg_path.read_text())
    cfg['wake_enabled']=True
    write_json(cfg_path,cfg)
    print('Wake listening is ON. Menu > Wake / Mic switches it off.')
    print('Nearby speech is transcribed locally for the wake phrase. The microphone pauses in menus and during replies.')
    print('SSH keys allow only the model tunnel. Existing normal SSH login keys are preserved.')
    print('This account now permits only local TCP forwarding; Unix-socket/remote forwarding are disabled.')


if __name__=='__main__':
    main()
