#!/usr/bin/env python3
"""Local, conversational Pocket Llama prototype. No model tools or shell access."""
import argparse
import asyncio
import contextlib
import fcntl
import io
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import queue
import subprocess
import threading
import time
import tkinter as tk
from tkinter import messagebox
import wave

from core import SYSTEM_PROMPT, SpeechChunker, Utterance, ManualRecording, discard_oldest_pair, spoken_text
from speech_ui import ReadyEstimate, SpeechAudio

ROOT = Path(__file__).resolve().parent


def load_config():
    path = ROOT / "config.json"
    if not path.exists():
        raise RuntimeError("Run install.sh first; config.json is missing.")
    cfg = json.loads(path.read_text())
    from urllib.parse import urlparse
    for key in ("llm_url", "stt_url"):
        url = urlparse(cfg[key])
        if url.scheme != "http" or url.hostname != "127.0.0.1":
            raise ValueError(f"{key} must be a local http://127.0.0.1 address.")
    return cfg


def wav_bytes(pcm):
    buf = io.BytesIO()
    with wave.open(buf, "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(16000)
        output.writeframes(pcm)
    return buf.getvalue()


async def cancellable(awaitable, cancelled):
    task = asyncio.create_task(awaitable)
    try:
        while not task.done():
            if cancelled():
                raise asyncio.CancelledError
            await asyncio.sleep(.05)
        if cancelled():
            raise asyncio.CancelledError
        return await task
    finally:
        if not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task


async def lines_with_ticks(response):
    """Allow cancellation checks while the HTTP stream has no new token."""
    lines = response.aiter_lines().__aiter__()
    pending = None
    try:
        while True:
            if pending is None:
                pending = asyncio.create_task(anext(lines))
            done, _ = await asyncio.wait({pending}, timeout=.1)
            if not done:
                yield None
                continue
            try:
                line = pending.result()
            except StopAsyncIteration:
                return
            pending = None
            yield line
    finally:
        if pending is not None:
            if not pending.done():
                pending.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await pending


class Engine:
    def __init__(self, cfg, events):
        self.cfg, self.events = cfg, events
        self.lock = threading.Lock()
        self.epoch = 0
        self.touch_mode = cfg.get("interaction_mode", "touch") == "touch"
        self.enabled = False if self.touch_mode else cfg["auto_listen"]
        self.submit_recording = threading.Event()
        self.models_ready = threading.Event()
        self.closing = threading.Event()
        self.typed = queue.Queue()
        self.history = []
        self.clear_history = threading.Event()
        self.voice = None
        self.ready_estimate = ReadyEstimate()
        self.voice_alignments = False
        self.ui_paused = threading.Event()
        self.announcements = queue.Queue()
        self.voice_followup = False
        from node_link import NodeLink
        self.node_link = NodeLink(ROOT / '.node-link', self.node_event)

    def node_event(self, value):
        self.emit('node', value)
        if value.get('mode') == 'connected':
            self.announcements.put('Connected to ' + value.get('node', {}).get('name', 'Node Llama') + '.')

    def pause_background(self, paused):
        if paused and not self.ui_paused.is_set():
            self.ui_paused.set()
            self.cancel(enabled=False)
        elif not paused:
            self.ui_paused.clear()

    def speak_notice(self, text, epoch):
        stopped = threading.Event()
        chunk = SpeechAudio.from_parts(text, list(self.synthesize(text, epoch, stopped)))
        if not self.stale(epoch):
            self.state('speaking', 'Connection status', epoch)
            self.emit('audio_active', True, epoch)
            try:
                self.play_audio(chunk, epoch, stopped)
            finally:
                self.emit('audio_active', False, epoch)

    def cancel(self, enabled=None, clear=False):
        with self.lock:
            self.epoch += 1
            if enabled is not None:
                self.enabled = enabled
        if clear:
            self.clear_history.set()
            while not self.typed.empty():
                with contextlib.suppress(queue.Empty):
                    self.typed.get_nowait()

    def emit(self, kind, value, epoch=None):
        self.events.put((kind, value, epoch))

    def state(self, name, detail="", epoch=None):
        self.emit("state", name, epoch)
        self.emit("status", detail, epoch)

    def listen_once(self):
        if self.models_ready.is_set():
            self.submit_recording.clear()
            self.cancel(enabled=True)

    def send_recording(self):
        self.submit_recording.set()

    def stale(self, epoch):
        return self.closing.is_set() or epoch != self.epoch

    def record(self, epoch, automatic=False, background=False):
        import sounddevice as sd
        import webrtcvad
        from audio_io import InputFrames, choose_format
        vad = webrtcvad.Vad(self.cfg["vad_mode"])
        detector = Utterance(650 if background else self.cfg["silence_ms"], 8 if background else self.cfg["max_record_seconds"])
        manual = ManualRecording(self.cfg["max_record_seconds"]) if self.touch_mode and not automatic else None
        audio_format = choose_format(sd, self.cfg["input_device"], "input")
        converter = InputFrames(audio_format)
        logging.info("Recording: %s, %s Hz, %s channels", audio_format.name,
                     audio_format.rate, audio_format.channels)
        frames = queue.Queue(maxsize=100)
        overflow = threading.Event()

        def callback(indata, count, timing, status):
            if status:
                overflow.set()
            try:
                frames.put_nowait(bytes(indata))
            except queue.Full:
                overflow.set()

        with sd.RawInputStream(samplerate=audio_format.rate,
                               blocksize=max(1, round(audio_format.rate * .03)), dtype="int16",
                               channels=audio_format.channels, device=audio_format.device,
                               callback=callback):
            if not background:
                self.state('listening', 'Speak; a pause sends automatically.' if automatic else 'Speak, then hold and release to send.', epoch)
            started, last_level = time.monotonic(), 0
            while not self.stale(epoch):
                if automatic and not detector.active and time.monotonic() - started > 8:
                    return b''
                if manual and self.submit_recording.is_set():
                    return manual.finish()
                if overflow.is_set():
                    raise RuntimeError("Microphone audio overflow. Check the audio device and CPU load.")
                try:
                    block = frames.get(timeout=.1)
                except queue.Empty:
                    continue
                if not background and time.monotonic() - last_level >= .09:
                    import numpy as np
                    samples = np.frombuffer(block, dtype=np.int16).astype(np.float32)
                    rms = float(np.sqrt(np.mean(samples * samples))) / 32768 if samples.size else 0
                    self.emit("level", (min(1, rms * 12), time.monotonic() - started), epoch)
                    last_level = time.monotonic()
                for frame in converter.feed(block):
                    is_speech = vad.is_speech(frame, 16000)
                    if manual:
                        if manual.feed(frame, is_speech):
                            return manual.finish()
                        continue
                    before = detector.active
                    result = detector.feed(frame, is_speech)
                    if detector.active and not before and not background:
                        self.emit("status", "Hearing you…", epoch)
                    if result is not None:
                        return result
        return b""

    async def ready(self, client):
        llm = await client.get(self.cfg["llm_url"] + "/health", timeout=3)
        llm.raise_for_status()
        endpoint = "/health" if self.cfg["stt_backend"] == "hailo" else "/"
        stt = await client.get(self.cfg["stt_url"] + endpoint, timeout=3)
        stt.raise_for_status()

    async def transcribe(self, client, pcm):
        result = await client.post(self.cfg["stt_url"] + "/inference",
                                   files={"file": ("speech.wav", wav_bytes(pcm), "audio/wav")},
                                   data={"response_format": "json", "temperature": "0.0",
                                         "language": "en"}, timeout=180)
        result.raise_for_status()
        text = result.json().get("text", "").strip()
        # Do not hand bracketed noise markers to the chat model.
        if not text or (text.startswith("[") and text.endswith("]")):
            return ""
        return text

    async def answer(self, client, text, epoch, on_phrase):
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self.history + [
            {"role": "user", "content": text}]
        # Count the actual model tokens; trim complete old exchanges.
        budget = self.cfg["context_size"] - self.cfg["max_reply_tokens"] - 128
        while True:
            formatted = await client.post(self.cfg["llm_url"] + "/apply-template",
                                           json={"messages": messages})
            formatted.raise_for_status()
            tokens = await client.post(self.cfg["llm_url"] + "/tokenize",
                                      json={"content": formatted.json()["prompt"], "add_special": True})
            tokens.raise_for_status()
            if len(tokens.json()["tokens"]) <= budget:
                break
            messages = discard_oldest_pair(messages)
        payload = {"model": "pocket-llama", "messages": messages, "stream": True,
                   "max_tokens": self.cfg["max_reply_tokens"], "temperature": 1.0,
                   "top_p": 1.0, "top_k": 20, "min_p": 0, "presence_penalty": 2.0,
                   "chat_template_kwargs": {"enable_thinking": False},
                   "reasoning_effort": "none"}
        answer = ""
        # Sentence-only speech also ignores any saved experimental phrase settings.
        chunker = SpeechChunker()
        async with client.stream("POST", self.cfg["llm_url"] + "/v1/chat/completions",
                                 json=payload, timeout=180) as response:
            if response.is_error:
                await response.aread()
            response.raise_for_status()
            async with contextlib.aclosing(lines_with_ticks(response)) as lines:
                async for line in lines:
                    if self.stale(epoch):
                        raise asyncio.CancelledError
                    if line is None:
                        continue
                    if not line.startswith("data: "):
                        continue
                    raw = line[6:]
                    if raw == "[DONE]":
                        break
                    data = json.loads(raw)
                    if data.get("error"):
                        raise RuntimeError(str(data["error"]))
                    choices = data.get("choices", [])
                    if choices:
                        delta = choices[0].get("delta", {}).get("content") or ""
                        answer += delta
                        for phrase in chunker.feed(delta):
                            on_phrase(phrase)
        answer = spoken_text(answer)
        if not answer:
            raise RuntimeError("The model returned no spoken answer. Check its chat template and reasoning settings.")
        for phrase in chunker.feed("", final=True):
            on_phrase(phrase)
        return answer, messages[1:] + [{"role": "assistant", "content": answer}]

    def synthesize(self, text, epoch, stopped):
        if self.stale(epoch) or stopped.is_set():
            return
        options = {"include_alignments": True} if self.voice_alignments else {}
        for chunk in self.voice.synthesize(text, **options):
            if self.stale(epoch) or stopped.is_set():
                return
            yield chunk

    def play_audio(self, chunk, epoch, stopped, prefix=""):
        from audio_io import play_pcm
        import numpy as np
        gain = max(0, min(1, float(self.cfg.get("voice_volume", 1))))
        pcm = chunk.audio_int16_bytes
        if gain != 1:
            pcm = (np.frombuffer(pcm, dtype=np.int16).astype(np.float32)*gain).astype(np.int16).tobytes()
        last_caption = None
        def progress(seconds):
            nonlocal last_caption
            caption = (prefix + " " + chunk.visible(seconds)).strip()
            if caption != last_caption and not self.stale(epoch) and not stopped.is_set():
                self.emit("caption", caption, epoch)
                last_caption = caption
        play_pcm(pcm, chunk.sample_rate, chunk.sample_channels,
                 self.cfg["output_device"], lambda: self.stale(epoch) or stopped.is_set(),
                 on_progress=progress)

    def queue_audio(self, audio, chunk, epoch, stopped):
        while not self.stale(epoch) and not stopped.is_set():
            try:
                audio.put(chunk, timeout=.05)
                return True
            except queue.Full:
                continue
        return False

    def synthesize_queued(self, phrases, audio, epoch, stopped):
        while not self.stale(epoch) and not stopped.is_set():
            try:
                phrase = phrases.get(timeout=.05)
            except queue.Empty:
                continue
            if phrase is None:
                self.queue_audio(audio, None, epoch, stopped)
                return
            parts = list(self.synthesize(phrase, epoch, stopped))
            if self.stale(epoch) or stopped.is_set():
                return
            chunk = SpeechAudio.from_parts(phrase, parts)
            if not self.queue_audio(audio, chunk, epoch, stopped):
                return

    def play_queued(self, audio, epoch, stopped, started):
        first = True
        spoken = ""
        while not self.stale(epoch) and not stopped.is_set():
            try:
                chunk = audio.get(timeout=.05)
            except queue.Empty:
                continue
            if chunk is None:
                return
            if first:
                ready_seconds = time.monotonic() - started
                logging.info("First speech audio ready %.2f s after answer request",
                             ready_seconds)
            self.state("speaking", "Tap to interrupt.", epoch)
            self.emit("audio_active", True, epoch)
            try:
                self.play_audio(chunk, epoch, stopped, prefix=spoken)
            finally:
                self.emit("audio_active", False, epoch)
            if self.stale(epoch) or stopped.is_set():
                return
            if first:
                self.ready_estimate.observe(ready_seconds)
                first = False
            spoken = (spoken + " " + chunk.text).strip()
            self.emit("caption", spoken, epoch)

    async def answer_and_speak(self, client, text, epoch):
        # Finish the complete text before any speech. Once ready, synthesize the
        # next whole sentence during playback, keeping the natural phrasing.
        started = time.monotonic()
        self.emit("generation_wait", {"started": started, "estimate": self.ready_estimate.seconds}, epoch)
        sentences = []
        reply, history = await self.answer(client, text, epoch, sentences.append)
        if self.stale(epoch):
            raise asyncio.CancelledError
        phrases = queue.Queue()
        for sentence in sentences:
            phrases.put(sentence)
        phrases.put(None)
        audio = queue.Queue(maxsize=2)
        stopped = threading.Event()
        synthesis = asyncio.create_task(asyncio.to_thread(self.synthesize_queued, phrases, audio, epoch, stopped))
        speech = asyncio.create_task(asyncio.to_thread(self.play_queued, audio, epoch, stopped, started))
        try:
            pending = {synthesis, speech}
            while pending:
                done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
                for task in done:
                    task.result()  # Propagate failure in either speech worker.
            if self.stale(epoch):
                raise asyncio.CancelledError
            self.history = history
            return reply
        finally:
            stopped.set()
            phrases.put(None)
            for worker in (synthesis, speech):
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await asyncio.shield(worker)

    def warm_voice(self):
        # Pay lazy phonemizer/inference setup cost before the first question.
        for _ in self.voice.synthesize("Ready."):
            pass

    def load_voice(self, voice_path):
        from piper import PiperVoice
        import inspect
        if "include_alignments" in inspect.signature(PiperVoice.load).parameters:
            try:
                voice = PiperVoice.load(str(voice_path), include_alignments=True)
                self.voice_alignments = True
                return voice
            except (ImportError, ValueError) as exc:
                logging.info("Piper alignment unavailable; using audio-duration pacing: %s", exc)
        return PiperVoice.load(str(voice_path))

    async def run_async(self):
        import httpx
        self.ready_estimate = ReadyEstimate(ROOT / ".ui-timing.json")
        self.state("loading", "Loading voice...")
        voice_path = ROOT / self.cfg["voice"]
        self.voice = await asyncio.to_thread(self.load_voice, voice_path)
        await asyncio.to_thread(self.warm_voice)
        async with httpx.AsyncClient(trust_env=False, timeout=30) as client:
            while not self.closing.is_set():
                try:
                    await self.ready(client)
                    self.models_ready.set()
                    break
                except Exception:
                    self.state("loading", "Loading local models...")
                    await asyncio.sleep(2)
            while not self.closing.is_set():
                if self.clear_history.is_set():
                    self.history.clear()
                    self.clear_history.clear()
                epoch = self.epoch
                try:
                    typed = self.typed.get_nowait()
                except queue.Empty:
                    typed = None
                try:
                    announcement = self.announcements.get_nowait()
                except queue.Empty:
                    announcement = None
                if announcement:
                    await asyncio.to_thread(self.speak_notice, announcement, epoch)
                    await asyncio.sleep(.6)
                    continue
                if self.ui_paused.is_set() and typed is None:
                    await asyncio.sleep(.1)
                    continue
                wake_capture = not self.enabled and typed is None
                if wake_capture:
                    wake_on = self.cfg.get('wake_enabled', False)
                    self.state('idle', 'MIC ON · Say Llama, or tap to talk.' if wake_on else 'MIC OFF · Tap anywhere to talk.', epoch)
                    if not wake_on:
                        await asyncio.sleep(.15)
                        continue
                try:
                    if typed is None:
                        automatic = wake_capture or self.voice_followup
                        self.voice_followup = False
                        pcm = await asyncio.to_thread(self.record, epoch, automatic, wake_capture)
                        if self.stale(epoch):
                            continue
                        if self.touch_mode:
                            self.enabled = False
                        if not pcm:
                            if not wake_capture:
                                self.emit('notice', 'No speech heard. Say Llama or tap to try again.', epoch)
                            continue
                        if not wake_capture:
                            self.state('transcribing', 'Turning your voice into text...', epoch)
                        text = await cancellable(self.transcribe(client, pcm), lambda: self.stale(epoch))
                        if not text:
                            continue
                    else:
                        text = typed
                    if self.stale(epoch):
                        continue
                    from node_protocol import wake_text, connection_command
                    after_wake = wake_text(text)
                    if wake_capture and after_wake is None:
                        continue  # Background speech stays out of the chat model/history.
                    if after_wake is not None:
                        text = after_wake
                        if not text:
                            self.enabled, self.voice_followup = True, True
                            self.emit('notice', 'Listening. Say your question or Connect to Node.', epoch)
                            continue
                    command = connection_command(text)
                    if command:
                        self.enabled = False
                        self.state('idle', 'Connecting to Node...' if command == 'connect' else 'Disconnecting...', epoch)
                        if command == 'connect':
                            await asyncio.to_thread(self.node_link.begin)
                        else:
                            try:
                                await asyncio.to_thread(self.node_link.disconnect)
                            except Exception as exc:
                                self.emit('node', {'mode':'error','message':str(exc)[:200]})
                        continue
                    self.emit("user", text, epoch)
                    self.state("thinking", "Thinking...", epoch)
                    reply = await cancellable(self.answer_and_speak(client, text, epoch), lambda: self.stale(epoch))
                    self.emit("reply", reply, epoch)
                    # Let the speaker's tail fade before opening a fresh mic stream.
                    await asyncio.sleep(.45)
                except asyncio.CancelledError:
                    # Playback has stopped; also let any speaker tail fade.
                    await asyncio.sleep(.45)
                    continue
                except Exception as exc:
                    logging.exception("Conversation failed")
                    self.enabled = False
                    self.state("error", "Tap RETRY or open MENU.", epoch)
                    self.emit("error", str(exc), epoch)
                    # Leave the error visible until the UI explicitly retries.
                    while epoch == self.epoch and not self.closing.is_set():
                        await asyncio.sleep(.1)

    def run(self):
        try:
            asyncio.run(self.run_async())
        except Exception as exc:
            logging.exception("Engine startup failed")
            self.state("error", "Startup failed. Tap RETRY.")
            self.emit("error", str(exc))



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--list-devices", action="store_true")
    parser.add_argument("--test-audio", action="store_true")
    parser.add_argument("--windowed", action="store_true")
    parser.add_argument("--preview", action="store_true", help="Preview touch UI without models/audio")
    parser.add_argument("--kiosk", action="store_true")
    args = parser.parse_args()
    if args.list_devices or args.test_audio:
        import sounddevice as sd
    if args.list_devices:
        print(sd.query_devices())
        return
    cfg = json.loads((ROOT / "config.example.json").read_text()) if args.preview else load_config()
    if args.test_audio:
        from audio_io import choose_format, convert_pcm, play_pcm
        capture = choose_format(sd, cfg["input_device"], "input")
        playback = choose_format(sd, cfg["output_device"], "output")
        print(f"Input: {capture.name}, {capture.rate} Hz, {capture.channels} channel(s)")
        print(f"Output: {playback.name}, {playback.rate} Hz, {playback.channels} channel(s)")
        print("Recording five seconds. Say a short sentence now.")
        pcm = sd.rec(5 * capture.rate, samplerate=capture.rate, channels=capture.channels,
                     dtype="int16", device=capture.device)
        sd.wait()
        speech_pcm = convert_pcm(pcm.tobytes(), capture.rate, capture.channels, 16000)
        (ROOT / "mic-test.wav").write_bytes(wav_bytes(speech_pcm))
        print("Playing your recording.")
        play_pcm(speech_pcm, 16000, 1, cfg["output_device"])
        print("Saved mic-test.wav. Delete it when finished testing.")
        return
    (ROOT / "logs").mkdir(exist_ok=True)
    handler = RotatingFileHandler(ROOT / "logs" / "app.log", maxBytes=500000, backupCount=2)
    logging.basicConfig(handlers=[handler], level=logging.INFO)
    # Prevent two graphical sessions from claiming the same microphone.
    with (ROOT / ".app.lock").open("w") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit("Pocket Llama is already running.")
        if args.windowed or args.preview:
            cfg["fullscreen"] = False
        if args.kiosk:
            cfg["fullscreen"] = True
            cfg["interaction_mode"] = "touch"
        from touch_ui import Window
        window = Window(cfg, Engine, preview=args.preview)
        window.root.mainloop()


if __name__ == "__main__":
    main()
