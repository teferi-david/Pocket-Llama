import asyncio
import unittest
from core import Utterance, discard_oldest_pair, spoken_text


class SpeechTests(unittest.TestCase):
    def test_background_noise_never_opens_utterance(self):
        d = Utterance()
        for i in range(500):
            self.assertIsNone(d.feed(bytes([i % 256]), i % 6 == 0))
        self.assertFalse(d.active)

    def test_preroll_retains_first_syllable_and_ends_after_silence(self):
        d = Utterance(silence_ms=300)
        frames = []
        result = None
        for i in range(24):
            frame = bytes([i])
            frames.append(frame)
            result = d.feed(frame, 4 <= i < 14)
            if i < 23:
                self.assertIsNone(result)
        self.assertEqual(result, b''.join(frames))

    def test_recording_limit_stops_continuous_speech(self):
        d = Utterance(max_seconds=1)
        out = None
        for _ in range(34):
            out = d.feed(b'x', True)
            if out is not None:
                break
        self.assertIsNotNone(out)
        self.assertLessEqual(len(out), 34)

    def test_history_drops_pairs_preserves_system_and_new_question(self):
        data = [{'role': 'system'}, {'role': 'user', 'content': 'old'},
                {'role': 'assistant'}, {'role': 'user', 'content': 'new'}]
        self.assertEqual(discard_oldest_pair(data), [data[0], data[-1]])
        with self.assertRaises(ValueError):
            discard_oldest_pair([data[0], data[-1]])

    def test_reasoning_never_spoken(self):
        self.assertEqual(spoken_text('<think>private\nreasoning</think>Hi.'), 'Hi.')
        self.assertEqual(spoken_text('<think>unfinished'), '')
        self.assertEqual(spoken_text('Try **this** [link](https://example.com).'), 'Try this link.')


class CancelTests(unittest.IsolatedAsyncioTestCase):
    async def test_cancel_during_network_wait_drops_task(self):
        from app import cancellable
        ended = asyncio.Event()
        cancel = asyncio.Event()
        async def waiting():
            try:
                await asyncio.sleep(60)
            finally:
                ended.set()
        task = asyncio.create_task(cancellable(waiting(), cancel.is_set))
        await asyncio.sleep(.02)
        cancel.set()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertTrue(ended.is_set())


if __name__ == '__main__':
    unittest.main()
