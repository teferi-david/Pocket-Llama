#!/usr/bin/env bash
set -u
echo '--- Operating system ---'
cat /etc/os-release
uname -m
free -h
df -h /
echo '--- Power and temperature ---'
vcgencmd get_throttled
vcgencmd measure_temp
echo '--- Audio devices ---'
arecord -l
aplay -l
echo '--- Model readiness ---'
curl --max-time 3 --silent --show-error http://127.0.0.1:8080/health
echo
systemctl --no-pager --full status pocket-llm pocket-stt
