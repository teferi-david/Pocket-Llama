Pocket Llama: first boot to portable conversational assistant

**Voice connection update:** See `VOICE-CONNECT.md` for “Llama, connect to Node,”
a one-time six-digit touchscreen pairing, and background wake listening. Update
both apps and run `bash ~/Pocket-Llama/enable-node-link.sh` once, then reboot.
No SD-card reflash or model/display reinstall is needed. Wake listening can be
switched off in MENU → WAKE / MIC.

===========================================================

Prepared for David's Raspberry Pi 5 16 GB build, 26 September 2026.

This is a runnable starter project, not a flashed OS image or a hardware-certified product. The Python logic and shell syntax were checked locally; the complete stack has not been run on your Pi. You have confirmed that the small display and touch now work on your 64-bit Trixie installation. Keep that working configuration and skip completed first-boot steps. The X1201 remains disconnected during software setup. The Hailo adapter is experimental and must pass the standalone hardware test before you enable it. No performance or battery-life figure is promised.

This edition defaults to Huihui-Qwen3.5-2B-abliterated Q4_K_M, approximately 1.27 GB, to balance conversational capability and response time on your Raspberry Pi 5 16 GB. The app, speech recognition and spoken replies stay local after the initial downloads. Start at step 4 if the Pi desktop, internet, display and touch are already working.

Your first Pi benchmark succeeded: turn 1 produced first text in 2.64 s and its 53-token complete answer in 13.12 s; turn 2 produced first text in 2.19 s and its 85-token complete answer in 19.99 s. These are model-only times from your screenshot. You subsequently confirmed that the audio update works.

This edition uses your requested generate-then-speak flow. Pocket Llama finishes the complete text response before speech starts. During that wait, the main box contains only animated “Generating…” text and an approximate countdown. It then speaks natural, complete sentences while revealing the words at their audio playback positions. The next sentence is synthesized during current playback. Short phrase and per-word synthesis remain disabled.

The first spoken response now waits for the entire model answer plus the first sentence’s synthesis. This deliberately increases the initial pause compared with speaking during generation. The display no longer shows raw generated tokens ahead of speech. Your transcribed prompt remains in History, and the main box contains only the current assistant state or spoken reply. Text is wrapped using measured glyph widths and clipped to the box; longer replies advance through four-line pages as they are spoken.

This edition also fixes the `Invalid sample rate [PaErrorCode -9997]` failure in the audio test and conversation loop. The original code requested 16 kHz directly from the microphone. The update probes the selected input and output for supported sample rates and mono/stereo channels, then uses SoXR to convert microphone audio to mono 16 kHz for speech detection and recognition. Spoken replies are converted to the output device's supported format.

This edition adds the 480×320 landscape touchscreen interface based on your `llama_talk_animation.gif`. It uses the original llama frames, black-and-white layout, dotted header, bordered dialogue box and bottom touch controls. Animation is sampled at eight UI updates per second, preserving the source timing; changed image tiles are repainted to reduce SPI display traffic. Actual smoothness still depends on the 8 MHz screen and Pi load.

**Countdown and spoken captions:** the initial wait estimate is 20 seconds, broadly based on your earlier measured model-only completion times. It learns the time from the answer request until the first audio is ready using recent successful turns, saving only the average and count in `.ui-timing.json`. It is always labelled an estimate. If it runs out, “Taking longer than estimated…” replaces the countdown; the interface does not promise a false zero or a fixed completion time.

Install `piper-tts[alignment]>=1.8,<2` for Piper’s optional phoneme/audio timing. Supported voices are patched in memory on load; the existing voice file is retained. Word boundaries use these timings when the phoneme groups match the displayed words. When alignment is unavailable or words expand differently (such as numbers), captions fall back to pacing within the actual audio duration. Playback progress uses the output device clock and reported latency, including the buffered tail. Word synchronization is therefore approximate in fallback cases and can also be affected by the SPI refresh delay. No additional speech-recognition model or cloud service is used for captions.

**Calibration-loop fix:** if the older wizard repeats “Touches did not match the targets,” press Esc on the attached keyboard to leave it and open Pocket Llama for this boot. The update below samples the press instead of the lift-off coordinate, filters movement with a median, ignores bounced releases, and waits 0.65 seconds between targets. Targets are gray while settling and turn white when ready. The canvas dimensions are measured after fullscreen settles. Failed checks now pause with Retry and Skip buttons instead of automatically looping; an unverified candidate matrix is restored before retry or skip. A recovery copy also handles an interrupted new calibration attempt. The older wizard did not retain a pre-attempt backup, so settings already changed by that version cannot automatically be recovered from such a backup.

If the dedicated session prevents downloading the update, press Ctrl+Alt+T and run `bash ~/Pocket-Llama/disable-kiosk.sh`, then `sudo reboot` to return to the desktop. Download the updated ZIP there, extract it as shown below, and run `bash enable-kiosk.sh` followed by `sudo reboot` to restore small-screen-only startup. If SSH is already enabled, transferring the ZIP and updating through SSH is an alternative; re-enabling the existing kiosk setup is unnecessary when it was not disabled.

**HDMI audio error update:** your latest screenshot shows playback selecting `vc4-hdmi-1` and rejecting its audio format. Use the new audio selector below to choose your actual USB microphone and USB earbuds/speaker. It saves unique device names without ALSA card numbers, so removing HDMI or changing enumeration does not retain a stale numeric selection. It does not guess which microphone you want. The SPI touchscreen itself does not carry speaker audio.

**Update your working Pi first.** Close Pocket Llama, save the new ZIP to the Pi's Downloads folder as `Pocket-Llama.zip`, replacing the older download, then run these commands one at a time:

```bash
unzip -o ~/Downloads/Pocket-Llama.zip -d ~
cd ~/Pocket-Llama
.venv/bin/python -m pip install "Pillow>=11,<13" "piper-tts[alignment]>=1.8,<2"
.venv/bin/python configure_audio.py
.venv/bin/python app.py --test-audio
.venv/bin/python app.py --windowed
```

The selector first lists microphones, then outputs. Enter the number beside your SunFounder microphone and then your USB earbuds/speaker. The number is used only for this selection; a unique name is saved in `config.json`. `config.before-audio.json` preserves the configuration before the first selection. Use `configure_audio.py --output-only` if you want to retain your existing microphone selection. HDMI and generic default routes are rejected by this selector because this build uses a dedicated small-screen session. Existing manually configured routes remain supported by the app.

Run the audio test before opening the window: say a sentence during its five-second recording and check that you hear it back. If it fails, keep the full error and run `.venv/bin/python app.py --list-devices`; resolve audio before changing startup. Close the test window before running the kiosk installer. The windowed test can appear on HDMI; the dedicated startup below is restricted to the small screen.

This installs Pillow for screen rendering and Piper’s alignment support for spoken captions. Your existing models, voice, virtual environment and configuration remain in place. Existing installations automatically use touch interaction unless they explicitly set `interaction_mode` to `handsfree`; kiosk startup always selects touch mode. Sentence-by-sentence speech and the working sample-rate conversion are retained. No model reinstall is needed.

**Use the touchscreen.**

1. The llama moves while the voice and local model services become ready. The loading bar is an activity indicator, not a percentage.
2. Tap the main screen or `TAP TO TALK` to open the microphone.
3. Speak your prompt. Pauses do not send it.
4. Press and hold for about 0.65 seconds until `RELEASE TO SEND` appears, then lift your finger. This submits the recording. It is a separate gesture after the initial tap.
5. The app transcribes, shows “Generating…” until the full reply is ready, then speaks complete sentences with words appearing during playback. The microphone stays closed through playback. Tap to interrupt and start another recording, or tap `STOP` to return to idle.
6. After the answer, tap again for the next question. Follow-ups retain conversation context.

The time limit in your existing `max_record_seconds` (normally 20 seconds) automatically submits a recording if you do not send it sooner. A silent recording is discarded. `CANCEL` discards the current recording. `HISTORY` shows full completed answers with touch page controls; main-screen text can be shortened to fit. Footer buttons perform their labelled actions rather than starting a recording. `MENU` offers New chat, Help, voice-volume controls, Restart and Shut down. Volume is applied directly to the assistant audio, including raw ALSA output devices, and saved to `config.json`. Restart and shutdown require an on-screen confirmation. The battery icon shows `?` because UPS battery telemetry is not connected; it is not a battery-level estimate.

**Enable dedicated startup once the windowed touch test works.** In a terminal on the Pi desktop, while the small screen is connected:

```bash
cd ~/Pocket-Llama
bash enable-kiosk.sh
sudo reboot
```

The setup registers a dedicated LightDM/labwc session. On boot it starts Pocket Llama without a desktop panel, wallpaper or file manager. Model services still start at boot. The app displays its animated loading screen while it waits for model readiness. This is a dedicated application session on Raspberry Pi OS, not a newly flashed OS image; earlier firmware/kernel boot screens can still appear before the graphical session starts.

The setup requires `SPI-1`, places it at the origin, scales it to 1× and chooses a landscape transform (480×320 for your panel). Existing landscape direction is retained. It repairs any old profile that selected HDMI, preserving touch calibration and requesting recalibration if the output/orientation changes. At each session start it turns on the SPI panel and disables the other connected outputs in one layout update before opening the app. If SPI setup fails, it retries briefly and stops app startup; it does not fall back to displaying Pocket Llama on HDMI. The installer keeps the working SPI driver overlay and 8 MHz setting unchanged. HDMI may still show early firmware/kernel/login output before this session takes control. You can unplug HDMI after confirming the small-screen boot works.

**First kiosk boot:** wait for each cross to turn white, touch its center briefly and lift your finger fully. Complete four targets and two check targets. Use the touchscreen, not the external mouse, to calibrate it. If touch is already accurate, no new matrix is written. If samples or checks fail, the wizard pauses with Retry and Skip / Keep Touch; it does not restart automatically. Skip or Esc keeps the settings from the start of this attempt, opens Pocket Llama, and records a separate skip choice so future boots continue directly to the app. Only successful checks are marked verified. Calibration and display settings live in `~/Pocket-Llama/.kiosk/`; normal desktop screen settings are retained. Skipping does not correct an inaccurate or rotated touch mapping.

To persistently skip setup from a terminal after installing this update, close the wizard first and run:

```bash
cd ~/Pocket-Llama
.venv/bin/python calibrate_touch.py --skip
sudo reboot
```

To request the improved calibration on the next boot instead:

```bash
cd ~/Pocket-Llama
.venv/bin/python calibrate_touch.py --retry-next-boot
sudo reboot
```

If landscape is upside down, use SSH or a maintenance terminal to edit `.kiosk/display.json`: switch `90` to `270` (or `normal` to `180` for a natively landscape panel), then run `.venv/bin/python calibrate_touch.py --retry-next-boot` from the project folder and reboot to recalibrate.

**Recovery:** `Ctrl+Alt+T` opens a terminal in the dedicated session. `Ctrl+Alt+Q` exits the app to the maintenance terminal. SSH also remains available if previously enabled. To restore your prior desktop startup:

```bash
cd ~/Pocket-Llama
bash disable-kiosk.sh
sudo reboot
```

The disable script removes only Pocket Llama's managed login block and restores its previous desktop autostart file. Existing desktop settings and the original LightDM configuration backup are retained. Session errors are recorded in `logs/kiosk-session.log`; application launch errors in `logs/kiosk.log`; voice errors in `logs/app.log`. Unexpected app exits are retried; repeated failures open the maintenance terminal. If the display is blank, use SSH or `Ctrl+Alt+F2` to log in and run the recovery commands.

**Acceptance check before disconnecting the keyboard:** verify all touch targets, one spoken answer and one follow-up, Hold/Release, Cancel, Stop, full History pages, volume changes, New chat, a restart and a safe shutdown. Check an unplugged-network boot after model downloads are complete. The Pi's physical display, touch mapping and boot manager cannot be exercised here; those checks must be completed on the device.

The model receives no tools or device-control interface. Restart, shutdown and volume are fixed UI controls activated by the user. Conversation and recordings are processed locally; history remains in RAM and clears on restart or New chat. No web UI, cloud voice service or hosted dependency is used at runtime.

**1. Connect the Pi for first boot.**

Eject the microSD card from your computer and insert it into the unpowered Pi. Attach its cooler, a micro-HDMI monitor using HDMI0 (the port nearest USB-C), keyboard/mouse, your USB microphone, and USB earbuds or a USB speaker. Use your Pi-compatible wall supply for setup.

For direct USB-C power to the Pi, disconnect the X1201 electrically first. When the X1201 is installed and powering the Pi, use its specified power input instead; Geekworm explicitly says not to feed the Pi's USB-C power socket in that arrangement. Use the supported matching battery pair before battery tests. The protected UltraLast cells you mentioned do not match Geekworm's published X1201 battery requirement. Do not use the previously photographed mixed pair.

The Pi 5 has no built-in loudspeaker or analog headphone jack. Your USB earbuds suffice for testing. A built-in speaking device still needs a speaker/audio output you can mount.

Keep the working 3.5-inch GPIO screen fitted and retain the external monitor and keyboard for setup. Keep the case open until the complete stack works.

Power on and allow several minutes for the first boot. Complete any first-run setup and join Wi-Fi. Installation requires internet; everyday conversations will not.

**2. Get a terminal and check the OS.**

Either open Terminal on the Pi's desktop or use Terminal on your Mac. In these examples the username is `pocket` and hostname is `pocketllama`; replace them if you chose different values in Imager.

On your Mac:

```bash
ssh pocket@pocketllama.local
```

Accept the first-connection host key when it is your Pi, then enter its password. Password characters do not appear as you type. If `.local` does not resolve, find the Pi's address in your router and substitute that address. If SSH was not enabled, turn it on from the Pi's settings or `sudo raspi-config` using the attached keyboard.

On the Pi:

```bash
cat /etc/os-release
uname -m
dpkg --print-architecture
free -h
df -h /
```

Expect 64-bit Raspberry Pi OS, `aarch64`, `arm64`, roughly 15 GiB of memory, and enough free storage. Keep at least 15 GB free for the baseline and additional space for Hailo dependencies. Current Raspberry Pi AI instructions target Trixie. If you installed Lite, the included graphical startup needs a desktop; for this fresh build, using the 64-bit Desktop image is the simpler route. Do not reflash an already working installation just because an older version name appears: identify it first.

**3. Update the system.**

On the Pi, while on reliable wall power:

```bash
sudo apt update
sudo apt full-upgrade -y
sudo rpi-eeprom-update -a
sudo reboot
```

Reboot closes the SSH connection. Wait for the Pi to return, then reconnect using the same SSH command. If an update reports an error, resolve it before running the later installer.

**4. Transfer this project to the Pi.**

Save `Pocket-Llama.zip` from the chat to your Mac's Downloads folder. In a NEW Mac terminal, not inside your SSH session:

```bash
scp ~/Downloads/Pocket-Llama.zip pocket@pocketllama.local:~/
```

In the Pi terminal:

```bash
sudo apt install -y unzip
unzip -o ~/Pocket-Llama.zip -d ~
cd ~/Pocket-Llama
```

The final location must be `~/Pocket-Llama`, with `app.py` directly inside it. You can also copy the ZIP using a USB drive. Do not run the installation on your Mac; the scripts are for the Pi.

If downloading directly on the Pi, save the updated ZIP as `~/Downloads/Pocket-Llama.zip`, then use `unzip -o ~/Downloads/Pocket-Llama.zip -d ~` instead. The `-o` option replaces the supplied project scripts if you extracted an earlier edition. This archive contains no `config.json`, downloaded models, voices or virtual environment, so those existing items are retained. If you edited the supplied Python or shell scripts yourself, copy the project folder first. Close a running Pocket Llama app before updating it.

**5. Install the local engines and models.**

```bash
cd ~/Pocket-Llama
bash install.sh
```

Run this as your ordinary user. The script asks for sudo only for the system packages. It installs dependencies in a separate Python environment, builds CPU versions of llama.cpp and whisper.cpp, downloads Huihui-Qwen3.5-2B-abliterated Q4_K_M, downloads Whisper base.en, and installs the Piper Lessac voice. It creates `config.json` without overwriting an existing configuration. Compilation and downloads may take a while.

The selected file is `Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf`, from `mradermacher/Huihui-Qwen3.5-2B-abliterated-GGUF`. It is 1,270,809,024 bytes (about 1.27 GB or 1.18 GiB). The installer pins the Hugging Face revision and checks its SHA-256. Actual RAM use is higher because the runtime, context, speech engines and OS also need memory. The 16 GB Pi has room for this stack; CPU throughput, prompt length and cooling are more relevant constraints for response time. Q4_K_M retains more precision than the smaller 2/3-bit versions. Only the language GGUF is downloaded; no vision projector is needed for this conversational interface.

Huihui describes this as an uncensored/abliterated version of Qwen3.5-2B. Abliteration reduces refusal behavior; it does not guarantee no refusals or correct answers. Thinking is disabled, context is 4,096 tokens, and fresh configurations cap replies at 96 tokens. The app requests one or two short sentences and uses Qwen's non-thinking text defaults: temperature 1.0, top-k 20, top-p 1.0, min-p 0 and presence penalty 2.0. The model has no tools or ability to take device actions. You do not need a Hugging Face account or token for this public GGUF download.

For an existing installation, `config.json` is retained, including an earlier 192-token reply limit. For shorter maximum replies, open `nano ~/Pocket-Llama/config.json`, change `"max_reply_tokens": 192` to `"max_reply_tokens": 96`, save, and reopen the app. A smaller cap reduces maximum output length; it does not increase generation speed and can cut off a long answer.

Why this model: Qwen's own evaluation places standard Qwen3.5-2B above standard Qwen3-1.7B on several knowledge benchmarks in non-thinking mode, although not on every metric. Those results do not measure this abliterated quantization. A first-hand Pi 5 report found standard Qwen3.5-2B at roughly 5–6 generated tokens/s, later about 8 after further optimizations, versus roughly 4–5 for 4B. Its software/settings differ from this build, so use those as context, not a speed guarantee. A 4B model is worth considering if measured pauses are acceptable and you want stronger answers; 2B is the conservative starting balance for voice. See the timing check below.

The installer records source revisions and model identity in `installed-versions.json` and Python versions in `installed-python-packages.txt`. Keep these with your eventual system image. If the installer stops, read the error; do not keep running later steps. A normal rerun resumes the same source directories and skips completed model downloads. An older model already in `models/` remains on disk but is not loaded by the updated launch script.

**6. Start the persistent model services.**

```bash
cd ~/Pocket-Llama
bash enable-services.sh
curl http://127.0.0.1:8080/health
```

If the model is still loading, wait and run the curl command again. Expect an OK health response. These two services start at boot and keep Qwen and CPU Whisper loaded. They listen only on the Pi itself. The 4,096-token context and one conversation slot keep memory bounded. Running `enable-services.sh` also restarts already-running services, so the new small model replaces the previous one in memory. Reopen the app after the services are ready.

Test Qwen directly:

```bash
curl http://127.0.0.1:8080/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"pocket-llama","messages":[{"role":"user","content":"Introduce yourself in one sentence."}],"max_tokens":80,"chat_template_kwargs":{"enable_thinking":false},"reasoning_effort":"none"}'
```

Then measure two short conversational turns with the app paused or closed:

```bash
python3 benchmark-model.py
```

This prints time to first visible text and time to the complete answer for each turn. The follow-up may reuse cached prompt tokens. It excludes microphone silence detection, transcription and speech synthesis. The updated interface hides generated text behind “Generating…” until the full response is ready, then reveals it during speech. First text in this benchmark is not first visible text in the app; app speech waits for the full reply and the first sentence’s synthesis. Test several real voice turns before deciding that the delay is acceptable; this timing script deliberately measures the model without concurrent speech.

If it fails:

```bash
systemctl status pocket-llm pocket-stt --no-pager
journalctl -u pocket-llm -n 60 --no-pager
journalctl -u pocket-stt -n 60 --no-pager
```

**7. Select and test the microphone and sound output.**

From a terminal on the PI DESKTOP (the local graphical session):

```bash
wpctl status
cd ~/Pocket-Llama
.venv/bin/python app.py --list-devices
.venv/bin/python configure_audio.py
.venv/bin/python app.py --test-audio
```

The test prints the selected input/output names, supported sample rates and channel counts, records five seconds, plays it back, and saves `mic-test.wav`. You should hear your own sentence clearly. Hardware may use 44.1 or 48 kHz; the saved recording and speech-recognition input are always mono 16 kHz after resampling. Keep the file for the transcription test below, then delete it when finished if you do not want to retain it.

Use the desktop sound settings to choose the SunFounder USB microphone and USB earbuds/speaker. Your earbuds also have a mic, so verify which microphone is active. You can set the default source and sink with `wpctl set-default ID`, using each actual numeric ID from `wpctl status`; do not reuse an example ID.

For an explicit named USB input/output, use `configure_audio.py` with Pocket Llama closed. This is also the fix when the app selects `vc4-hdmi-1` and reports `Invalid sample rate` after changing displays. If your hardware needs a custom route, you can instead edit its configuration:

```bash
nano ~/Pocket-Llama/config.json
```

Set `input_device` or `output_device` to a unique device-name substring from the app's `--list-devices` output, in quotes, rather than a guessed card number. Keep `null` to use the system default. Device numbers may change after reboot. Validate the selected devices again after enabling autologin. The app probes only the selected device; it does not silently switch microphones. If an older installation reports `Invalid sample rate`, apply the audio update at the start of this guide, including the SoXR dependency. If the updated test still fails, retain the full error and device list to identify the correct device. ALSA can print warnings for a format probe that fails before another format succeeds; check whether recording and playback actually complete.

Test transcription of that recording:

```bash
curl http://127.0.0.1:8081/inference \
  -F 'file=@/home/pocket/Pocket-Llama/mic-test.wav' \
  -F response_format=json
```

Replace `/home/pocket` if your username differs, or run the following relative-path version from the project folder:

```bash
curl http://127.0.0.1:8081/inference -F 'file=@mic-test.wav' -F response_format=json
```

Test the synthesized voice:

```bash
cd ~/Pocket-Llama
.venv/bin/python -m piper -m en_US-lessac-medium --data-dir voices \
  -f voice-test.wav -- 'Hello David. Pocket Llama is ready.'
aplay voice-test.wav
```

**8. Run the custom interface manually.**

From the Pi desktop terminal:

```bash
cd ~/Pocket-Llama
.venv/bin/python app.py --windowed
```

Wait for the loading screen to finish, tap to listen, speak, then hold and release to send. The quick-start section above describes all touch controls. Test the complete voice loop in this window before changing startup.

**9. Enable dedicated startup.**

Follow `bash enable-kiosk.sh` in the quick-start section above. It replaces desktop-app autostart with a dedicated Pocket Llama session and includes recovery. The older `enable-autostart.sh` remains available only if you prefer to open the app on the ordinary desktop.

**10. Preserve the working touchscreen and select it for the app.**

Your Hosyond 3.5-inch GPIO/SPI screen and touch are now working. Back up the working configuration:

```bash
sudo cp -n /boot/firmware/config.txt /boot/firmware/config.txt.working-screen
```

The setup that resolved the white screen used `dtparam=spi=on`, `dtoverlay=vc4-kms-v3d`, and `dtoverlay=piscreen,drm,speed=8000000,rotate=90` under `[all]`. This is a record of the working setup, not a request to add duplicate lines or reinstall a driver. Keep the battery/UPS board disconnected while finishing software setup.

Open Pi menu → Preferences → Control Centre → Screens. Select SPI-1 as the primary display and use landscape 480×320 for the app. The current overlay rotation can present 320×480 portrait; use the display orientation controls and verify the result. For touch mapping, right-click SPI-1 → Touchscreen → ADS7846 Touchscreen → Mouse Emulation → Apply. Keep whichever already-working touch settings match your panel.

Test touch at all four corners and the center. Rotation of the image and rotation/calibration of touch must agree. After a successful windowed app test, shut down, unplug HDMI and boot again to test the small screen alone. The AI HAT uses the Pi PCIe connector, but the display and HAT still need GPIO access and physical clearance; verify the stack and any extension cable while power is disconnected. The model installer does not modify display configuration. Dedicated kiosk display changes are held separately in `.kiosk/`.

**11. Add the AI HAT+ 26 TOPS.**

The HAT accelerates supported Whisper speech recognition; Qwen still runs on the Pi CPU. This is the Hailo-8 path, not the HAT+ 2 / Hailo-10H LLM path.

Shut down, disconnect wall and battery power, fit the HAT using its spacers/stacking header, and connect its PCIe ribbon with the orientation in Raspberry Pi's hardware guide. Keep the cooler fitted and leave clearance above it. Reapply power and run:

```bash
sudo apt update
sudo apt install -y dkms hailo-all
sudo reboot
```

After reboot:

```bash
hailortcli fw-control identify
python3 -c 'import hailo_platform; print(hailo_platform.__file__)'
```

Expect Hailo-8/HAILO8 for your 26 TOPS board. Do not install `hailo-h10-all`, which belongs to the HAT+ 2. Hailo's current standalone speech README specifies HailoRT 4.20 or newer. The runtime, kernel driver, Python binding and compiled model must be compatible; report a mismatch rather than mixing random versions. Our main app environment remains separate.

Create the Hailo speech environment:

```bash
sudo apt install -y ffmpeg libportaudio2 python3-gi python3-gi-cairo gir1.2-gtk-4.0
cd ~
git clone --depth 1 https://github.com/hailo-ai/hailo-apps.git
cd ~/hailo-apps
python3 -m venv --system-site-packages .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -e '.[speech-rec]' flask
.venv/bin/python -m pip check
```

If any stage fails, keep using CPU speech and capture that exact error. Do not remove upstream dependency pins or use `sudo pip` to push through it. The official Hailo installer is an alternative if its current repository version requires additional setup.

With internet available, run the official standalone test on the recorded WAV:

```bash
cd ~/hailo-apps
.venv/bin/python -m hailo_apps.python.standalone_apps.speech_recognition.speech_recognition \
  --arch hailo8 --variant base --audio "$HOME/Pocket-Llama/mic-test.wav"
```

The first run downloads model/decoder resources and tokenizer data. Fix any download, directory-permission, or Hailo binding error here before proceeding. The official tiny.en variant is not listed for Hailo-8; use base or tiny. The Hailo decoder also uses some host CPU processing, so the HAT does not eliminate all speech CPU work.

Once the official test produces a good transcript, run the included experimental persistent adapter:

```bash
cd ~/hailo-apps
.venv/bin/python ~/Pocket-Llama/hailo-bridge.py
```

From a second Pi terminal:

```bash
curl http://127.0.0.1:8082/health
cd ~/Pocket-Llama
curl http://127.0.0.1:8082/inference -F 'file=@mic-test.wav'
```

Compare transcription correctness and elapsed time against port 8081 using the same recording. This adapter imports Hailo's current Python pipeline, including internal helper functions; upstream API changes may require an adjustment. It has not been hardware-tested here. Do not interpret a successful driver identification as a successful transcription test.

Stop the manually running adapter with Ctrl+C. Then:

```bash
cd ~/Pocket-Llama
bash enable-hailo.sh
sudo reboot
```

The script installs a separate `pocket-hailo` service, waits for its health response, switches the app to port 8082, then disables CPU Whisper. It enables offline Hugging Face/Transformers operation after the caches have been populated. If startup fails, the config is not switched. Inspect:

```bash
journalctl -u pocket-hailo -n 80 --no-pager
```

To revert:

```bash
cd ~/Pocket-Llama
bash disable-hailo.sh
sudo reboot
```

Retest without internet. Keep the HAT only if measured transcription latency, total response time, heat and battery use justify it in this enclosure.

**12. Make it portable with the X1201.**

First verify the UPS board revision and install a matched pair of the battery type specified by Geekworm: unprotected flat-top 3.7 V 18650 cells. Confirm polarity and matching charge level. Follow the X1201 hardware instructions for its pogo-pin contact, spacers, power input, and switch. With the UPS fitted, use its specified 5 V input; do not also power the Pi through USB-C.

Enable I2C from `sudo raspi-config`, then follow Geekworm's current X120X Software instructions for your exact X1201 revision. Configure battery monitoring and orderly low-battery shutdown, and verify their readings before relying on them. Do not add an arbitrary 5 A firmware override until the actual supply and UPS arrangement meet Geekworm's requirements. The starter does not fake a battery percentage or install a guessed UPS shutdown script.

Before closing the enclosure, test: operation on external power, transition to battery while chatting, reconnecting external power, ordinary software shutdown, and low-battery shutdown. For the last test, temporarily raise the documented software threshold so it can be checked without deeply discharging the cells, then restore the appropriate setting. Use the board's documented charge/discharge indicators to distinguish shutdown from loss of battery protection.

**13. Tune responsiveness and appearance.**

Start with the selected 2B abliterated model, 4,096 context, thinking disabled, and short spoken responses. Run `python3 benchmark-model.py` to measure the Pi CPU stage separately. If transcription is the bottleneck, compare CPU tiny.en against base.en, or Hailo tiny against base. The AI HAT+ 26 TOPS does not accelerate this GGUF LLM; Raspberry Pi's LLM-capable HAT is the different AI HAT+ 2. If answer quality is insufficient, a 4B compatible GGUF can be tried later using the same interface, with a latency tradeoff. Do not choose an 8B model just because it fits in RAM, or add swap/increase context as a cure for slow generation.

In touch mode, the hold-and-release gesture sends your recording; `silence_ms` is used only in optional hands-free mode. `max_reply_tokens` limits answer length. `max_record_seconds` is 20 for the prototype. `vad_mode` is 0–3; higher values reject more background noise but may miss quieter speech. Restart the app after changes. If changing context, change both `run-llm.sh` and `config.json`, then restart `pocket-llm`.

Edit colors, title, fonts, and controls in `touch_ui.py`. The existing Pocket Llama loading view is your first custom start screen. For an earlier boot logo, add a Plymouth theme only after verifying that the small display's driver initializes early enough. That final splash configuration depends on the actual display stack; this package does not overwrite boot files automatically.

**14. Finish the printed case.**

Measure the assembled hardware, including connector bodies and cable bends. Provide screen retention, insulated board mounting, fan intake/exhaust, clear battery access, microphone opening, speaker opening if fitted, USB-C charging access, the UPS switch, microSD access, and strain relief. Keep batteries away from the CPU/HAT heatsinks and do not block the cooler. Print a fit-test section before the whole shell.

Run a sustained conversation test with the lid open, then closed. Check:

```bash
vcgencmd measure_temp
vcgencmd get_throttled
free -h
```

`0x0` from `get_throttled` means no active or recorded throttle/undervoltage flags since boot. Nonzero values need decoding; a historical flag does not necessarily mean the problem is active now. Compare the same workload when judging whether the case causes a problem. Measure actual battery runtime; capacity labels alone do not predict it reliably.

**15. Prove the finished build and make a recovery image.**

Verify a cold boot opens the app without keyboard intervention, a first question receives a spoken answer, a follow-up after another tap retains context, silence does not trigger repeated invented speech, the device never listens to its own playback, Hold/Release, Cancel/Stop/New chat behave as expected, and audio devices survive reboot.

Turn Wi-Fi off USING THE PI'S DESKTOP, then reboot and repeat several turns. Do not disable Wi-Fi from your only SSH connection. All model and tokenizer caches must already exist. Test the Hailo path offline separately if enabled.

After all hardware and battery checks pass, shut down normally and use your computer to make a whole-card backup image of the microSD. Preserve both partitions, keep the original card untouched, restore the image to a spare equal-or-larger card, and boot-test the spare. Do not use Raspberry Pi Imager's Write action on your working card as a backup step; it overwrites it. A private image contains Wi-Fi credentials and SSH keys, so make a sanitized version before sharing it publicly.

Your private tested image is then the first Pocket Llama appliance OS image. The dedicated kiosk session and app restart loop are included. A future release can add a verified early boot splash, battery status and speaking-over-playback support.

**Troubleshooting reference**

| Symptom | First check |
|---|---|
| SSH hostname fails | Same network, SSH enabled, router IP address |
| Small screen is white | Compare the saved working overlay and 8 MHz SPI speed; continue via HDMI |
| `Waiting for local models` | Service status and journals from step 6 |
| No microphone / wrong microphone or HDMI output selected | Close the app; run `.venv/bin/python configure_audio.py`, then `app.py --test-audio` using the same Python |
| `Invalid sample rate` / `-9997` | Apply the updated app and SoXR dependency above; rerun `--test-audio` and inspect its device names |
| `No module named 'soxr'` | From the project folder, run `.venv/bin/python -m pip install "soxr>=0.5,<2"` |
| No voice | USB output selection, `voice-test.wav`, volume |
| App does not open after reboot | `logs/kiosk-session.log`, `logs/kiosk.log`, LightDM status; use `disable-kiosk.sh` for recovery |
| `SPI-1 is missing` at startup | Restore the working SPI screen configuration; the app deliberately does not fall back to HDMI. Use SSH or a text console to run `disable-kiosk.sh` for desktop recovery |
| Calibration repeats / touches did not match targets | Esc exits the old wizard. Install the update; wait for white targets and fully lift between touches. Retry or Skip / Keep Touch replaces the loop |
| Can't open display over SSH | Launch the UI in the local desktop terminal |
| Hailo device absent | Power off, check PCIe cable, drivers, `hailortcli` |
| Hailo dependency/HEF mismatch | Exact version output; keep baseline CPU path |
| Random reboot under inference | Supply/UPS/cell suitability, throttling flags, temperature |
| App stalls during Hailo decode | Hailo service journal; restart it or revert to CPU |

**Primary references checked for this build**

- Dedicated session: https://labwc.github.io/labwc.1.html
- Touch calibration: https://labwc.github.io/labwc-config.5.html
- Piper audio alignments: https://github.com/OHF-Voice/piper1-gpl/blob/main/docs/ALIGNMENTS.md
- Playback clock and latency: https://python-sounddevice.readthedocs.io/en/latest/api/streams.html
- LightDM session configuration: https://github.com/ubuntu/lightdm/blob/main/data/lightdm.conf
- Raspberry Pi AI hardware/software: https://www.raspberrypi.com/documentation/computers/ai.html
- AI HAT assembly and differences: https://www.raspberrypi.com/documentation/accessories/ai-hat-plus.html
- llama.cpp build: https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md
- llama.cpp server: https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md
- Standard Qwen model evaluation and sampling: https://huggingface.co/Qwen/Qwen3.5-2B
- Abliterated model: https://huggingface.co/huihui-ai/Huihui-Qwen3.5-2B-abliterated
- Qwen GGUF: https://huggingface.co/mradermacher/Huihui-Qwen3.5-2B-abliterated-GGUF
- Exact file: https://huggingface.co/mradermacher/Huihui-Qwen3.5-2B-abliterated-GGUF/blob/f36848fead3fdda244cf60195c46993d23183d4c/Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf
- First-hand Pi 5 comparison (different build/settings): https://www.reddit.com/r/LocalLLaMA/comments/1rj0m27/qwen35_2b_4b_and_9b_tested_on_raspberry_pi5/
- whisper.cpp server: https://github.com/ggml-org/whisper.cpp/tree/master/examples/server
- Piper CLI and API: https://github.com/OHF-Voice/piper1-gpl/tree/main/docs
- Audio device format probing: https://python-sounddevice.readthedocs.io/en/latest/api/checking-hardware.html
- SoXR resampling API: https://python-soxr.readthedocs.io/en/latest/soxr.html
- Hailo speech recognition: https://github.com/hailo-ai/hailo-apps/tree/main/hailo_apps/python/standalone_apps/speech_recognition
- Hailo installation: https://github.com/hailo-ai/hailo-apps/blob/main/doc/user_guide/installation.md
- Hosyond support: https://hosyond.com/
- X1201 hardware and linked software instructions: https://wiki.geekworm.com/X1201

Third-party engines, models, and voices retain their own licenses. Review these before distributing or selling an image; notably Piper is GPL-licensed and voice terms are separate. Models and third-party binaries are downloaded by the installer, not bundled in this ZIP.
