"""Audio-format regression tests; no microphone or speaker is required."""
import unittest
import json
from pathlib import Path
import tempfile

import numpy as np

from audio_io import AudioFormat, InputFrames, choose_format, convert_pcm, mono_samples, play_pcm
from configure_audio import stable_selector, save_devices


class FakeAudio:
    class PortAudioError(Exception):
        pass

    def __init__(self, supported=(48000, 2), default_rate=48000):
        self.supported = supported
        self.default_rate = default_rate
        self.checked = []
        self.writes = []
        self.aborted = False
        self.closed = False
        self.opened = None

    def query_devices(self, device, direction):
        if device not in (None, "USB test", 7):
            raise AssertionError("Unexpected device selection")
        return {"index": 7, "name": "USB test", "default_samplerate": self.default_rate,
                "max_input_channels": 2, "max_output_channels": 2}

    def check_input_settings(self, **settings):
        self.checked.append(settings)
        if (settings["samplerate"], settings["channels"]) != self.supported:
            raise self.PortAudioError("Invalid sample rate or channel count")

    check_output_settings = check_input_settings

    def RawOutputStream(self, **settings):
        self.check_output_settings(**settings)
        self.opened = settings
        return self

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.closed = True

    def write(self, pcm):
        self.writes.append(pcm)

    def abort(self):
        self.aborted = True


def tone(rate, seconds=.6, hz=1000):
    time = np.arange(round(rate * seconds)) / rate
    return np.rint(12000 * np.sin(2 * np.pi * hz * time)).astype(np.int16)


class AudioTests(unittest.TestCase):
    def test_audio_name_survives_card_renumbering_and_hdmi_removal(self):
        class Enumeration:
            class PortAudioError(Exception):
                pass

            def __init__(self, index, card):
                self.info = {"index":index, "name":f"USB Earbuds: USB Audio (hw:{card},0)"}

            def query_devices(self, selected, direction):
                if selected == self.info["index"] or selected in self.info["name"]:
                    return self.info
                raise ValueError("Not found")

        before = Enumeration(7, 3)
        saved = stable_selector(before, 7, "output")
        self.assertEqual(saved, "USB Earbuds: USB Audio")
        after = Enumeration(2, 0)
        self.assertEqual(after.query_devices(saved, "output")["index"], 2)

    def test_ambiguous_audio_names_are_rejected_instead_of_saving_card_number(self):
        class Ambiguous:
            class PortAudioError(Exception):
                pass

            def query_devices(self, selected, direction):
                if isinstance(selected, int):
                    return {"index":selected, "name":"USB Audio (hw:3,0)"}
                raise ValueError("Multiple matching devices")

        with self.assertRaisesRegex(ValueError, "not unique"):
            stable_selector(Ambiguous(), 4, "output")

    def test_device_save_preserves_model_and_mic_settings_and_original_backup(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            original = {"input_device":"SunFounder", "output_device":1, "voice":"voices/test.onnx", "max_reply_tokens":96}
            path.write_text(json.dumps(original))
            save_devices(path, {"output_device":"USB Earbuds"})
            updated = json.loads(path.read_text())
            self.assertEqual(updated, {**original, "output_device":"USB Earbuds"})
            save_devices(path, {"output_device":"USB Speaker"})
            self.assertEqual(json.loads((path.parent / "config.before-audio.json").read_text()), original)

    def test_native_rate_and_stereo_only_device_with_rate_fallback(self):
        for supported in ((48000, 2), (44100, 1)):
            with self.subTest(supported=supported):
                sd = FakeAudio(supported)
                actual = choose_format(sd, "USB test", "input")
                self.assertEqual((actual.rate, actual.channels), supported)
                self.assertEqual(actual.device, 7)
                self.assertTrue(all(s["device"] == 7 for s in sd.checked))
                self.assertTrue(all(s["dtype"] == "int16" for s in sd.checked))

    def test_unsupported_device_has_actionable_error(self):
        with self.assertRaisesRegex(RuntimeError, "USB test.*--list-devices"):
            choose_format(FakeAudio(supported=None), 7, "input")

    def test_mono_mix_does_not_overflow(self):
        stereo = np.array([[32767, 32767], [-32768, -32768], [12000, 4000]], dtype=np.int16)
        np.testing.assert_array_equal(mono_samples(stereo.tobytes(), 2),
                                      [32767, -32768, 8000])

    def test_arbitrary_input_blocks_preserve_duration_pitch_and_vad_framing(self):
        for rate in (16000, 44100, 48000):
            with self.subTest(rate=rate):
                samples = np.repeat(tone(rate)[:, None], 2, axis=1)
                converter = InputFrames(AudioFormat(7, "USB test", rate, 2))
                frames = []
                offset = 0
                sizes = [17, 479, 2048, 113]
                block_number = 0
                while offset < len(samples):
                    stop = min(len(samples), offset + sizes[block_number % len(sizes)])
                    frames.extend(converter.feed(samples[offset:stop].tobytes(),
                                                  final=stop == len(samples)))
                    offset = stop
                    block_number += 1
                self.assertEqual(len(frames), 20)  # 600 ms / 30 ms
                self.assertTrue(all(len(frame) == 960 for frame in frames))
                self.assertEqual(converter.pending, b"")
                actual = np.frombuffer(b"".join(frames), dtype=np.int16)
                expected = np.frombuffer(convert_pcm(samples.tobytes(), rate, 2, 16000),
                                         dtype=np.int16)
                np.testing.assert_allclose(actual, expected, atol=2)
                frequencies = np.fft.rfftfreq(len(actual), 1 / 16000)
                self.assertAlmostEqual(frequencies[np.abs(np.fft.rfft(actual)).argmax()], 1000)

    def test_downsampling_filters_frequencies_above_speech_nyquist(self):
        out = convert_pcm(tone(48000, hz=12000).tobytes(), 48000, 1, 16000)
        samples = np.frombuffer(out, dtype=np.int16).astype(np.float64)[500:-500]
        self.assertLess(np.sqrt(np.mean(samples ** 2)), 20)

    def test_piper_rate_playback_uses_supported_output_without_pitch_change(self):
        sd = FakeAudio()
        play_pcm(tone(22050).tobytes(), 22050, 1, "USB test", sd=sd)
        self.assertEqual(sd.opened["samplerate"], 48000)
        self.assertEqual(sd.opened["channels"], 2)
        actual = np.frombuffer(b"".join(sd.writes), dtype=np.int16).reshape(-1, 2)
        self.assertEqual(len(actual), 28800)  # 600 ms at 48 kHz
        np.testing.assert_array_equal(actual[:, 0], actual[:, 1])
        frequencies = np.fft.rfftfreq(len(actual), 1 / 48000)
        self.assertAlmostEqual(frequencies[np.abs(np.fft.rfft(actual[:, 0])).argmax()], 1000)
        self.assertTrue(sd.closed)
        self.assertFalse(sd.aborted)

    def test_cancellation_aborts_active_playback_and_closes_stream(self):
        sd = FakeAudio()
        play_pcm(tone(22050).tobytes(), 22050, 1, 7,
                 cancelled=lambda: bool(sd.writes), sd=sd)
        self.assertEqual(len(sd.writes), 1)
        self.assertEqual(len(sd.writes[0]), 4800 * 2)  # 50 ms, stereo int16
        self.assertTrue(sd.aborted)
        self.assertTrue(sd.closed)


if __name__ == "__main__":
    unittest.main()
