"""480x320 touch interface using the user's original llama animation."""
from collections import deque
from datetime import datetime
import math
import json
from pathlib import Path
import queue
import subprocess
import threading
import time

from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageTk

from core import TouchGesture
from speech_ui import estimate_label

ROOT = Path(__file__).resolve().parent
SIZE = (480, 320)


def font(size):
    for name in ("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
                 "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"):
        if Path(name).exists():
            return ImageFont.truetype(name, size)
    return ImageFont.load_default(size=size)


def wrap(text, width=58):
    import textwrap
    return textwrap.wrap(str(text), width=width, break_long_words=True) or [""]


def wrap_pixels(text, face, width):
    """Fit actual rendered glyph widths, including a long unbroken word."""
    rows, line = [], ""
    for word in str(text).split():
        candidate = (line + " " + word).strip()
        if face.getlength(candidate) <= width:
            line = candidate
            continue
        if line:
            rows.append(line)
            line = ""
        for char in word:
            if line and face.getlength(line+char) > width:
                rows.append(line)
                line = ""
            line += char
    if line or not rows:
        rows.append(line)
    return rows


class Scene:
    def __init__(self):
        self.small, self.body, self.title = font(10), font(12), font(12)
        self.frames = []
        self.durations = []
        # Extract only the animated character at runtime; reference UI text is
        # replaced with live state, real time, and the user's actual conversation.
        with Image.open(ROOT / "assets/llama_talk_animation.gif") as gif:
            for i in range(gif.n_frames):
                gif.seek(i)
                self.durations.append(gif.info.get("duration", 50))
                self.frames.append(gif.convert("RGB").crop((340, 116, 700, 418)).resize(
                    (158, 132), Image.Resampling.NEAREST))

    def draw(self, state="idle", detail="", reply="", user="", level=(),
             elapsed=0, hold=0, phase=0, active=False, overlay=None, page=0,
             turns=(), history_index=0, volume=0.7, notice="", wait_label=""):
        im = Image.new("RGB", SIZE, "black")
        d = ImageDraw.Draw(im)
        d.text((18, 10), "LLAMA-OS v0.1", font=self.title, fill="white")
        d.text((358, 11), datetime.now().strftime("%I:%M %p").lstrip("0"), font=self.small, fill="white")
        d.rectangle((443, 10, 463, 21), outline="white", width=2)
        d.rectangle((464, 13, 466, 18), fill="white")
        d.text((450, 9), "?", font=self.small, fill="white")
        for x in range(18, 465, 6):
            d.rectangle((x, 27, x+2, 29), fill="white")
        command = "BOOT" if state == "loading" else "RUN TALK"
        d.text((18, 39), "C:\\LLAMA>", font=self.small, fill="#777777")
        d.text((83, 39), command, font=self.small, fill="white")
        if state == "loading":
            # First cycle in the supplied GIF already contains the head sway.
            index = self.animation_frame(0, 25, phase)
        elif active:
            index = self.animation_frame(81, 171, phase)
        elif state in ("thinking", "transcribing", "listening"):
            index = self.animation_frame(0, 25, phase)
        else:
            index = 0
        im.paste(self.frames[index], (161, 48))
        d.rectangle((18, 181, 462, 276), outline="white", width=2)
        d.rectangle((22, 185, 458, 272), outline="white")
        speaker = "YOU" if state == "listening" else "LLAMA"
        d.rectangle((29, 172, 35 + len(speaker)*7, 187), fill="black", outline="white")
        d.text((33, 173), speaker, font=self.small, fill="white")
        footer = ("< > HISTORY", "TAP TO TALK", "MENU")
        if state == "loading":
            d.text((34, 200), "* Waking up Pocket Llama...", font=self.body, fill="white")
            d.text((34, 224), detail or "Loading local models...", font=self.small, fill="#aaaaaa")
            d.rectangle((34, 249, 446, 257), outline="white")
            x = 35 + (phase*13) % 360
            d.rectangle((x, 250, min(x+45, 445), 256), fill="white")
            footer = ("", "LOADING" + "."*(phase % 4), "MENU")
        elif state == "listening":
            d.text((34, 198), "Listening... speak naturally.", font=self.body, fill="white")
            automatic = 'automatically' in detail
            hint = 'Pause when finished to send.' if automatic else ('Release to send.' if hold >= 1 else 'Hold anywhere, then release to send.')
            d.text((34, 218), hint, font=self.small, fill="#aaaaaa")
            values = list(level)[-48:]
            values = [0] * (48-len(values)) + values
            for i, value in enumerate(values):
                h = max(2, min(22, int(value*22)))
                x = 35 + i*8
                d.rectangle((x, 253-h//2, x+3, 253+h//2), fill="white")
            d.text((412, 198), f"{elapsed:02.0f}s", font=self.small, fill="white")
            if hold:
                d.rectangle((24, 269, 24+int(432*hold), 271), fill="white")
            footer = ("", "PAUSE TO SEND" if automatic else ("RELEASE TO SEND" if hold >= 1 else "HOLD TO SEND"), "CANCEL")
        else:
            # One clipped content layer: prompts and assistant text never share
            # the same box. Prompts remain available in conversation History.
            pane = Image.new("RGB", (414, 73), "black")
            pd = ImageDraw.Draw(pane)
            if state == "transcribing":
                text = "Transcribing" + "."*((phase//4)%3+1)
            elif state == "thinking":
                pd.text((0, 7), "Generating" + "."*((phase//4)%3+1), font=self.body, fill="white")
                pd.text((0, 35), wait_label or "Estimating time...", font=self.small, fill="#aaaaaa")
                text = None
            elif state == "error":
                text = detail or "Something needs attention."
            else:
                text = notice or reply or ("Speaking..." if state == "speaking" else detail or "Hi! Tap anywhere to talk.")
            if text is not None:
                rows = wrap_pixels(text, self.body, 410)
                start = ((len(rows)-1)//4)*4 if reply and state != "error" else 0
                for n, line in enumerate(rows[start:start+4]):
                    pd.text((0, 4+n*16), line, font=self.body, fill="white")
            im.paste(pane, (34, 195))
            if state in ("thinking", "transcribing", "speaking"):
                footer = ("", "TAP TO INTERRUPT", "STOP")
            elif state == "error":
                footer = ("", "RETRY", "MENU")
        self.footer(d, footer)
        if overlay:
            self.overlay(im, overlay, turns, history_index, page, volume, detail)
        return im

    def animation_frame(self, start, stop, tick):
        # Keep the supplied animation's timing while sampling at eight UI fps.
        elapsed = (tick*125) % sum(self.durations[start:stop])
        for index in range(start, stop):
            elapsed -= self.durations[index]
            if elapsed < 0:
                return index
        return start

    def footer(self, d, labels):
        d.rectangle((0, 281, 479, 319), fill="white")
        for x, text in zip((76, 240, 418), labels):
            d.text((x, 301), text, font=self.small, fill="black", anchor="mm")

    def overlay(self, im, mode, turns, index, page, volume, detail):
        d = ImageDraw.Draw(im)
        d.rectangle((0, 32, 479, 280), fill="black")
        if mode == "menu":
            d.text((18, 41), "POCKET LLAMA / MENU", font=self.title, fill="white")
            buttons = [(18, 68, 232, 107, 'NEW CHAT'), (248, 68, 462, 107, 'NODE / CONNECT'),
                       (18, 120, 232, 159, 'VOLUME -'), (248, 120, 462, 159, 'VOLUME +'),
                       (18, 172, 232, 211, 'WAKE / MIC'), (248, 172, 462, 211, 'HELP'),
                       (18, 224, 232, 263, 'RESTART'), (248, 224, 462, 263, 'SHUT DOWN')]
            for x1, y1, x2, y2, text in buttons:
                d.rectangle((x1, y1, x2, y2), outline="white", width=2)
                d.text(((x1+x2)//2, (y1+y2)//2), text, font=self.body, fill="white", anchor="mm")

            self.footer(d, ("", "BACK TO LLAMA", ""))
        elif mode in ("shutdown", "reboot", "exit"):
            question = {"shutdown": "Shut down safely?", "reboot": "Restart the Pi?", "exit": "Exit to maintenance terminal?"}[mode]
            d.text((240, 112), question, font=self.title, fill="white", anchor="mm")
            d.text((240, 145), "Your conversation is held only in memory.", font=self.small, fill="#aaaaaa", anchor="mm")
            self.footer(d, ("CANCEL", "", "CONFIRM"))
        elif mode == "history":
            if turns:
                index = max(0, min(index, len(turns)-1))
                prompt, answer = turns[index]
                rows = wrap("YOU: " + prompt, 58) + [""] + wrap("LLAMA: " + answer, 58)
                pages = max(1, math.ceil(len(rows)/11))
                page = max(0, min(page, pages-1))
                title = f"HISTORY {index+1}/{len(turns)}   PAGE {page+1}/{pages}"
                d.text((18, 41), title, font=self.title, fill="white")
                for n, line in enumerate(rows[page*11:(page+1)*11]):
                    d.text((18, 67+n*17), line, font=self.body, fill="white")
            else:
                d.text((18, 65), "No completed conversations yet.", font=self.body, fill="white")
            self.footer(d, ("< PREVIOUS", "NEXT >", "BACK"))
        elif mode == "help":
            rows = ["TAP the main screen to start listening.",
                    "Speak your question or follow-up.",
                    "HOLD the screen until RELEASE TO SEND.",
                    "Release your finger to send the recording.",
                    "Recording also sends at its time limit.",
                    "Tap while speaking to interrupt.",
                    "HISTORY shows complete answers.",
                    "Battery ? = no battery telemetry.",
                    "MENU > Shut down before unplugging."]
            for n, text in enumerate(rows):
                d.text((18, 55+n*22), text, font=self.small, fill="white")
            self.footer(d, ("", "BACK", ""))


class Window:
    def __init__(self, cfg, engine_factory, preview=False):
        import tkinter as tk
        self.cfg, self.engine_factory, self.preview = cfg, engine_factory, preview
        self.root = tk.Tk(className="PocketLlama")
        self.root.title("Pocket Llama")
        self.root.configure(bg="black")
        self.root.geometry("480x320")
        self.root.minsize(480, 320)
        self.root.attributes("-fullscreen", cfg.get("fullscreen", True))
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.bind("<Escape>", lambda e: self.escape())
        self.root.bind("<F11>", lambda e: self.root.attributes("-fullscreen", not self.root.attributes("-fullscreen")))
        self.root.bind("<Control-Alt-q>", lambda e: self.close())
        self.canvas = tk.Canvas(self.root, width=480, height=320, bg="black", highlightthickness=0, cursor="none")
        self.canvas.place(relx=.5, rely=.5, anchor="center", width=480, height=320)
        self.canvas.bind("<ButtonPress-1>", self.press)
        self.canvas.bind("<ButtonRelease-1>", self.release)
        self.canvas.bind("<Leave>", lambda e: self.gesture.cancel())
        self.scene = Scene()
        self.gesture = TouchGesture()
        self.tiles, self.previous = [], None
        for y in range(0, 320, 80):
            for x in range(0, 480, 80):
                photo = ImageTk.PhotoImage(Image.new("RGB", (80, 80), "black"))
                self.canvas.create_image(x, y, image=photo, anchor="nw")
                self.tiles.append((x, y, photo))
        self.state, self.detail, self.reply, self.user = "loading", "Loading local models...", "", ""
        self.notice, self.overlay = "", None
        self.node_view, self.node_code, self.node_page = {"mode":"menu"}, "", 0
        self.node_busy = False
        self.level = deque([0]*48, maxlen=48)
        self.elapsed, self.phase, self.active = 0, 0, False
        self.generation_started, self.generation_estimate = None, 20.0
        self.turns, self.history_index, self.page = [], 0, 0
        self.volume, self.down_region = float(cfg.get("voice_volume", 1)), None
        self.events = queue.Queue()
        self.engine = engine_factory(cfg, self.events)
        self.worker = threading.Thread(target=self.engine.run, daemon=True)
        self.closed = False
        if not preview:
            self.worker.start()
        else:
            self.root.after(2000, lambda: self.events.put(("state", "idle", None)))
        self.root.after(25, self.poll)
        self.root.after(25, self.animate)

    def background(self, action):
        def run():
            try:
                action()
            except Exception as exc:
                self.events.put(("ui_error", str(exc), None))
        threading.Thread(target=run, daemon=True).start()

    def change_volume(self, amount):
        target = max(0, min(1, self.volume+amount))
        try:
            if not self.preview:
                path = ROOT / "config.json"
                cfg = json.loads(path.read_text())
                cfg["voice_volume"] = target
                temporary = ROOT / "config.json.tmp"
                temporary.write_text(json.dumps(cfg, indent=2)+"\n")
                temporary.replace(path)
            self.cfg["voice_volume"] = target
            self.volume = target
        except Exception as exc:
            self.notice, self.overlay = str(exc), None

    def node_action(self, action):
        if self.node_busy:
            return
        self.node_busy = True
        def run():
            try:
                action()
            except Exception as exc:
                self.events.put(('node', {'mode':'error','message':str(exc)[:200]}, None))
            finally:
                self.events.put(('node_done', None, None))
        threading.Thread(target=run,daemon=True).start()

    def toggle_wake(self):
        enabled = not self.cfg.get('wake_enabled',False)
        path = ROOT/'config.json'
        if not self.preview:
            from node_protocol import write_json
            cfg=json.loads(path.read_text())
            cfg['wake_enabled']=enabled
            write_json(path,cfg)
        self.cfg['wake_enabled']=enabled
        self.engine.cancel(enabled=False)
        self.node_view={'mode':'message','message':('Wake listening ON. Nearby speech is transcribed locally to detect Llama. Nothing is sent to a cloud service.' if enabled else 'Wake listening OFF. Tap the main screen to talk. The idle microphone is off.')}
        self.overlay='node'

    def region(self, x, y):
        if y >= 281:
            return "left" if x < 150 else "right" if x >= 350 else "center"
        if self.overlay == 'node':
            mode=self.node_view.get('mode')
            if mode=='code' and 245<=x<465 and 76<=y<264:
                col=min(2,int((x-245)/74));row=min(3,int((y-76)/47))
                return 'key:'+('123456789<0+'[row*3+col])
            if mode=='choose' and 69<=y<261:
                return 'node:'+str(self.node_page*4+int((y-69)/48))
            if mode=='menu' and 69<=y<261:
                return ['connect','choose','disconnect','forget'][int((y-69)/48)]
        if self.overlay == 'menu':
            col=0 if x<240 else 1
            if 68<=y<=107:return ('new','node')[col]
            if 120<=y<=159:return ('quieter','louder')[col]
            if 172<=y<=211:return ('wake','help')[col]
            if 224<=y<=263:return ('reboot','shutdown')[col]
        return "main"

    def press(self, event):
        self.down_region = self.region(event.x, event.y)
        if not self.overlay and self.down_region in ("main", "center"):
            self.gesture.press(self.state, time.monotonic())

    def release(self, event):
        region = self.region(event.x, event.y)
        if region != self.down_region:
            self.gesture.cancel()
            return
        if self.overlay:
            self.overlay_action(region)
            return
        if region == "right":
            if self.state in ("listening", "thinking", "transcribing", "speaking"):
                self.stop()
            else:
                self.overlay = "menu"
            return
        if region == "left" and self.state == "idle":
            self.overlay, self.history_index, self.page = "history", max(0, len(self.turns)-1), 0
            return
        if self.state == "error" and region in ("main", "center"):
            self.retry()
            return
        action = self.gesture.release(self.state, time.monotonic())
        if action in ("listen", "interrupt"):
            self.active = False
            self.notice = ""
            self.reply, self.user, self.elapsed = "", "", 0
            self.level.clear()
            if self.preview:
                self.state = "listening"
            else:
                self.engine.listen_once()
        elif action == "send":
            self.state = "transcribing"
            self.engine.send_recording()

    def stop(self):
        self.gesture.cancel()
        self.engine.cancel(enabled=False)
        self.active = False
        self.generation_started = None
        self.state = "idle" if self.engine.models_ready.is_set() or self.preview else "loading"

    def overlay_action(self, region):
        mode = self.overlay
        if mode=='node':
            view=self.node_view.get('mode')
            if region=='right':
                self.engine.node_link.cancelled.set()
                self.overlay=None
            elif self.node_busy:
                return
            elif region=='left':
                if view=='choose' and self.node_page:
                    self.node_page-=1
                else:self.node_view={'mode':'menu'}
            elif region=='connect' or region=='center' and view in ('error','message','connected'):
                self.node_action(self.engine.node_link.begin)
            elif region=='choose':self.node_action(lambda:self.engine.node_link.begin(choose=True))
            elif region=='disconnect':self.node_action(self.engine.node_link.disconnect)
            elif region=='wake':self.toggle_wake()
            elif region=='forget':self.node_view={'mode':'confirm-forget','message':'Forget all Node pairings? Close Node Llama on each computer to end any existing tunnel.'}
            elif region=='center' and view=='confirm-forget':self.node_action(self.engine.node_link.forget_all)
            elif region=='center' and view=='choose':
                if (self.node_page+1)*4<len(self.node_view.get('nodes',[])):self.node_page+=1
            elif region.startswith('node:'):
                index=int(region.split(':')[1]);nodes=self.node_view.get('nodes',[])
                if index<len(nodes):self.node_action(lambda:self.engine.node_link.select(nodes[index]))
            elif region.startswith('key:'):
                key=region[4:]
                if key=='<':self.node_code=self.node_code[:-1]
                elif key=='+':
                    if len(self.node_code)==6:
                        code=self.node_code
                        self.node_view={'mode':'search','message':'Pairing with your computer...'}
                        self.node_action(lambda:self.engine.node_link.pair(code))
                elif len(self.node_code)<6:self.node_code+=key
            return
        if mode in ("shutdown", "reboot", "exit"):
            if region == "left":
                self.overlay = "menu"
            elif region == "right":
                if mode == "exit":
                    self.close()
                else:
                    self.stop()
                    self.background(lambda: subprocess.run(
                        ["systemctl", "poweroff" if mode == "shutdown" else "reboot"],
                        check=True, capture_output=True, timeout=10))
            return
        if mode == "history":
            if region == "right":
                self.overlay = None
            elif self.turns and region in ("left", "center"):
                rows = wrap("YOU: " + self.turns[self.history_index][0], 58) + [""] + wrap("LLAMA: " + self.turns[self.history_index][1], 58)
                pages = max(1, math.ceil(len(rows)/11))
                if region == "center":
                    if self.page+1 < pages:
                        self.page += 1
                    elif self.history_index+1 < len(self.turns):
                        self.history_index += 1
                        self.page = 0
                elif self.page:
                    self.page -= 1
                elif self.history_index:
                    self.history_index -= 1
                    self.page = 0
            return
        if region in ("left", "center", "right"):
            self.overlay = None
        elif region == "new":
            self.engine.cancel(enabled=False, clear=True)
            self.turns.clear()
            self.user = self.reply = self.notice = ""
            self.overlay = None
        elif region=='node':
            self.overlay='node'
            self.node_view={'mode':'menu'}
        elif region=='wake':
            self.toggle_wake()
        elif region == "help":
            self.overlay = "help"
        elif region in ("reboot", "shutdown"):
            self.overlay = region
        elif region in ("quieter", "louder"):
            self.change_volume(-.1 if region == "quieter" else .1)

    def retry(self):
        self.engine.closing.set()
        self.engine.cancel(enabled=False)
        self.state, self.detail = "loading", "Restarting voice interface..."
        def wait_for_worker():
            if self.closed:
                return
            if self.worker.is_alive():
                self.root.after(100, wait_for_worker)
                return
            self.events = queue.Queue()
            self.engine = self.engine_factory(self.cfg, self.events)
            self.worker = threading.Thread(target=self.engine.run, daemon=True)
            self.worker.start()
        wait_for_worker()

    def poll(self):
        for _ in range(150):
            try:
                kind, value, epoch = self.events.get_nowait()
            except queue.Empty:
                break
            if epoch is not None and epoch != self.engine.epoch:
                continue
            if kind=='node':
                self.overlay='node'
                self.node_view=value
                self.node_page=0
                if value.get('mode')=='code':self.node_code=''
            elif kind=='node_done':
                self.node_busy=False
            elif kind == "state":
                if self.state != value:
                    self.gesture.cancel()
                self.state = value
                if value != "speaking":
                    self.active = False
            elif kind == "status":
                self.detail = value
            elif kind == "user":
                self.user, self.reply, self.notice = value, "", ""
            elif kind == "caption":
                self.reply = value
            elif kind == "generation_wait":
                self.generation_started = value["started"]
                self.generation_estimate = value["estimate"]
            elif kind == "reply":
                self.turns.append((self.user, value))
                self.turns = self.turns[-50:]
            elif kind == "level":
                strength, self.elapsed = value
                self.level.append(strength)
            elif kind == "audio_active":
                self.active = value
            elif kind == "volume":
                self.volume = value
            elif kind == "notice":
                self.notice = value
            elif kind == "ui_error":
                self.notice = value
                self.overlay = None
            elif kind == "error":
                self.state, self.detail, self.overlay = "error", value, None
                self.active = False
        self.engine.pause_background(bool(self.overlay))
        if not self.closed:
            self.root.after(40, self.poll)

    def animate(self):
        frame = self.scene.draw(self.state, self.detail, self.reply, self.user, self.level,
                                self.elapsed, self.gesture.progress(time.monotonic()),
                                self.phase, self.active, self.overlay, self.page,
                                self.turns, self.history_index, self.volume, self.notice,
                                estimate_label(self.generation_started, self.generation_estimate, time.monotonic()))
        d=ImageDraw.Draw(frame)
        mic='MIC ON' if self.cfg.get('wake_enabled',False) and self.state=='idle' and not self.overlay else 'MIC OFF'
        if self.state=='listening':mic='REC'
        d.text((292,39),mic,font=self.scene.small,fill='#aaaaaa')
        if self.overlay=='node':
            self.draw_node(frame)
        # Only changed tiles are repainted, limiting damage on the slow SPI display.
        for x, y, photo in self.tiles:
            box = (x, y, x+80, y+80)
            crop = frame.crop(box)
            if self.previous is None or ImageChops.difference(crop, self.previous.crop(box)).getbbox():
                photo.paste(crop)
        self.previous = frame
        self.phase += 1
        if not self.closed:
            self.root.after(125, self.animate)

    def draw_node(self,frame):
        d=ImageDraw.Draw(frame);d.rectangle((0,32,479,280),fill='black')
        mode=self.node_view.get('mode','menu')
        d.text((18,41),'NODE LLAMA',font=self.scene.title,fill='white')
        def box(x,y,w,h,label):
            d.rectangle((x,y,x+w,y+h),outline='white',width=2)
            d.text((x+w//2,y+h//2),label,font=self.scene.body,fill='white',anchor='mm')
        if mode=='menu':
            for i,label in enumerate(['CONNECT TO NODE','CHOOSE COMPUTER','DISCONNECT','FORGET ALL PAIRINGS']):
                box(18,71+i*48,444,40,label)
        elif mode=='code':
            node=self.node_view.get('node',{})
            for i,line in enumerate(wrap(node.get('name','Computer'),26)[:2]):d.text((18,77+i*18),line,font=self.scene.body,fill='white')
            d.text((18,126),self.node_code.ljust(6,'_'),font=font(27),fill='white')
            for i,line in enumerate(wrap('Enter the code shown in Node Llama on your PC.',27)):d.text((18,173+i*18),line,font=self.scene.small,fill='white')
            for i,key in enumerate('123456789<0+'):
                box(245+(i%3)*74,76+(i//3)*47,68,41,'SEND' if key=='+' else key)
        elif mode=='choose':
            for i,node in enumerate(self.node_view.get('nodes',[])[self.node_page*4:(self.node_page+1)*4]):
                label=('[PAIRED] ' if node.get('paired') else '')+node['name']
                box(18,71+i*48,444,40,label[:43])
        else:
            msg=self.node_view.get('message','Working...')
            for i,line in enumerate(wrap_pixels(msg,self.scene.body,434)[:9]):d.text((22,83+i*19),line,font=self.scene.body,fill='white')
        self.scene.footer(d,('PREV' if mode=='choose' else 'NODE MENU',
                           'NEXT' if mode=='choose' else 'FORGET' if mode=='confirm-forget' else 'CONNECT' if mode in ('error','message','connected') else '',
                           'BACK'))

    def escape(self):
        if self.overlay:
            self.overlay = None
        else:
            self.stop()
            self.overlay = "menu"

    def close(self):
        self.closed = True
        self.engine.closing.set()
        self.engine.cancel(enabled=False)
        self.root.destroy()
