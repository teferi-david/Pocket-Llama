#!/usr/bin/env python3
"""Experimental persistent Hailo-8 STT adapter. Run in Hailo's own environment.

Uses the official hailo-apps Whisper pipeline inspected 2026-09-26.
Requires a working standalone speech_recognition example first.
Listen-only loopback service; no shell commands, URL fetching or file paths accepted.
"""
import io
import threading
import wave
from flask import Flask, jsonify, request
import numpy as np

from hailo_apps.python.standalone_apps.speech_recognition.speech_recognition import (
    _setup_imports, _ensure_npy_assets, VARIANT_MODELS)
from hailo_apps.python.standalone_apps.speech_recognition.whisper_pipeline import WhisperPipeline
from hailo_apps.python.standalone_apps.speech_recognition.audio_utils import improve_audio, preprocess_audio
from hailo_apps.python.standalone_apps.speech_recognition.postprocessing import clean_transcription
from pathlib import Path


def main():
    resolve_arch, get_logger, resolve_hef_paths, app_name, resource_root, npy_name = _setup_imports()
    variant, arch = "base", "hailo8"
    names = VARIANT_MODELS[variant][arch]
    resolved = resolve_hef_paths(hef_paths=list(names), app_name=app_name, arch=arch)
    npy_dir = Path(resource_root) / npy_name
    _ensure_npy_assets(variant, npy_dir, app_name, arch, resource_root)
    pipeline = WhisperPipeline(str(resolved[0].path), str(resolved[1].path),
                               variant=variant, npy_dir=str(npy_dir), add_embed=True)
    lock = threading.Lock()
    app = Flask(__name__)
    app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024

    @app.get('/health')
    def health():
        return jsonify(status='ok', backend='hailo8', variant=variant)

    @app.post('/inference')
    def inference():
        if not lock.acquire(blocking=False):
            return jsonify(error='busy'), 503
        try:
            if 'file' not in request.files:
                return jsonify(error='Missing WAV file'), 400
            try:
                with wave.open(io.BytesIO(request.files['file'].read()), 'rb') as wav:
                    if (wav.getframerate(), wav.getnchannels(), wav.getsampwidth()) != (16000, 1, 2):
                        return jsonify(error='Expected 16-kHz mono 16-bit PCM WAV'), 400
                    if wav.getnframes() > 16000 * 30:
                        return jsonify(error='Audio exceeds 30 seconds'), 400
                    audio = np.frombuffer(wav.readframes(wav.getnframes()), dtype='<i2').astype(np.float32) / 32768
            except (wave.Error, EOFError, ValueError):
                return jsonify(error='Invalid WAV'), 400
            if not len(audio):
                return jsonify(text='')
            audio, start = improve_audio(audio)
            if start is None:
                return jsonify(text='')
            chunks = preprocess_audio(audio, chunk_length=pipeline.get_chunk_length(),
                                      chunk_offset=max(start - .2, 0))
            texts = []
            for mel in chunks:
                pipeline.send_data(mel)
                # Official API blocks until this chunk is complete.
                texts.append(pipeline.get_transcription())
            return jsonify(text=clean_transcription(' '.join(texts)).strip())
        finally:
            lock.release()
    try:
        app.run(host='127.0.0.1', port=8082, threaded=True, use_reloader=False)
    finally:
        pipeline.stop()


if __name__ == '__main__':
    main()
