# Pocket Llama: “Llama, connect to Node”

This update adds a voice connection command and touchscreen pairing to the existing
Pocket Llama OS experience. You do not need to flash the SD card or reinstall the
model, display driver, audio configuration or kiosk.

Both apps must receive this update. The earlier Node Llama build does not advertise
itself or accept code pairing.

## What everyday use looks like

1. Open Node Llama on your Windows computer. Keep the app running.
2. Put the Pi and PC on the same private Wi-Fi/LAN.
3. Say **“Llama, connect to Node.”** You can also say **“Llama”**, pause until the
   screen says Listening, then say **“Connect to Node.”** Pause after the command.
4. Pocket Llama reconnects to the last paired computer that is available. Node Llama
   selects the paired Pi when it is the only ready paired device.
5. Type a Chat or Build task in Node Llama. The Pi supplies the model; Windows runs
   the existing project-scoped file tools.

You can still tap the Pocket Llama screen and hold/release to send a command, or
use **MENU → NODE / CONNECT → CONNECT TO NODE** without speaking.

“Connect to Node” is a connection command. Other handheld speech remains
conversational; this update does not turn every spoken sentence into a Windows
file action.

## 1. Update Windows

1. Close the existing Node Llama console and its old SSH window.
2. Extract the new **Node-Llama.zip**. Replace the files in your existing
   `Node-Llama` application folder. Avoid creating `Node-Llama\Node-Llama` by
   accident. Your projects and per-user settings are stored separately.
3. Run **Install-Node-Llama.cmd** once to install the new pairing dependencies.
   This step needs internet access.
4. Run **Start-Node-Llama.cmd**.
5. If Windows asks whether Python can communicate through the firewall, allow it
   on your trusted **Private** network. Node Llama's browser stays on
   `http://127.0.0.1:8877`; the additional pairing listener uses TCP 8878 and local
   discovery uses UDP 5353.
6. Open **DEVICES / CONNECT → PAIR POCKET LLAMA**. Leave the six-digit code visible.
   It lasts two minutes; generate another if it expires.

If Windows does not show a firewall prompt and discovery fails, the package
includes `Enable-Node-Discovery.ps1`. Open PowerShell **as Administrator**, change
to the extracted Node-Llama folder, and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Enable-Node-Discovery.ps1
```

That script creates rules for this app's Python executable, TCP 8878 and UDP 5353,
restricted to **Private networks and the local subnet**. It does not turn off the
firewall. Use a network you trust; do not change a public event network to Private
just to bypass its isolation. A private router or hotspot you control is preferable
when an event's guest Wi-Fi prevents devices from talking to each other.

The Windows OpenSSH Client is still required. The app automates it; Windows does
not need an SSH server. If the installer reports it missing, enable **OpenSSH
Client** in Windows Optional features, then restart Node Llama.

## 2. Update Pocket Llama

Download **Pocket-Llama.zip** to the Pi. Extract it and copy the contents of its
`Pocket-Llama` folder into your existing `/home/pocket/Pocket-Llama`, replacing
application files. Keep your existing `config.json`, models, voices and `.kiosk`
folder. They are not included in this update ZIP.

If the ZIP is named exactly `Pocket-Llama.zip` in Downloads, these commands make a
backup of the application files being replaced, then update them:

```bash
cd ~
python3 - <<'PY'
from datetime import datetime
from pathlib import Path
import shutil
import zipfile
root = Path.home() / 'Pocket-Llama'
archive = Path.home() / 'Downloads' / 'Pocket-Llama.zip'
backup = Path.home() / ('Pocket-Llama-code-backup-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
with zipfile.ZipFile(archive) as z:
    for entry in z.infolist():
        parts = Path(entry.filename).parts
        if entry.is_dir() or not parts or parts[0] != 'Pocket-Llama':
            continue
        relative = Path(*parts[1:])
        if not relative.parts or '..' in relative.parts or relative.is_absolute():
            raise RuntimeError('Unexpected ZIP path')
        if relative.parts[0] in {'config.json', 'models', 'voices', '.venv', '.kiosk', '.node-link'}:
            continue
        target = root / relative
        if target.exists():
            saved = backup / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(z.read(entry))
print('Updated. Previous application files are in:', backup)
PY
bash ~/Pocket-Llama/enable-node-link.sh
sudo reboot
```

Run the enable command as **pocket**, without putting `sudo` before `bash`. It asks
for sudo only for the SSH service configuration. Internet is needed for the
one-time dependencies. It enables SSH, checks its configuration before reload, and
turns wake listening on. Your working model services and screen settings remain.

## 3. Pair once

1. On Windows, open **DEVICES / CONNECT → PAIR POCKET LLAMA** to show a fresh code.
2. On the Pi, say **“Llama, connect to Node”**, or tap
   **MENU → NODE / CONNECT → CONNECT TO NODE**.
3. If multiple new computers appear, tap your computer's name.
4. Enter the six digits from that computer using the Pi touchscreen, then tap
   **SEND**. You do not need to speak a password or type an IP address.
5. Wait for the connection result. Pocket Llama speaks a connection confirmation;
   Node Llama shows the paired Pi and its model status.
6. In Node Llama, select the paired entry if needed. Try a short Chat request, then
   Build: **“Create hello.txt containing Hello from Pocket Llama. Check the file.”**

After this first pairing, use the voice command to reconnect after starting Node
Llama or changing networks. Pairing does not automatically start the Windows app,
wake a sleeping PC, join Wi-Fi or bypass guest-network client isolation.

## How the computer is chosen

- Use the last successfully paired computer when it is available.
- Otherwise use the sole available paired computer.
- Show a chooser when several candidates remain.
- An unfamiliar computer always requires its pairing code before receiving access.
- Use **NODE → CHOOSE COMPUTER** to override the remembered choice.

This build does **not** measure nearest-computer distance or rank PCs by Wi-Fi
signal strength. Wi-Fi signal normally describes the link to an access point; a
PC may be wired to that same network. LAN discovery establishes availability, not
physical proximity. Remembered identity is the more useful selection rule here.

Discovery is IPv4 mDNS on the same local network. Remembered IPs are also tried
when multicast is unavailable. A changed IP plus blocked multicast requires fixing
discovery or using the existing manual SSH entry on Windows.

## Wake listening and privacy

**MENU → WAKE / MIC** switches background listening.
The setting is saved. The screen shows MIC ON / MIC OFF / REC.

When on, the existing local microphone/VAD/transcription pipeline recognizes a
leading “Llama” or “Hey Llama.” A sentence without that leading wake phrase is
ignored and is not sent to the chat model or appended to chat history. Nearby
speech is nevertheless transcribed locally to detect the phrase. Short recordings
are held in memory, not written as ambient audio files by this feature.

This is an STT-based wake phrase, not a separately trained always-on keyword model.
It adds a pause for local transcription and uses CPU/battery when people are
speaking nearby. Noise, pronunciation or television audio can cause misses or
false activations. It is not voice biometrics. Test the phrase in your actual room.

The microphone pauses during app menus, model responses and playback. Wake off
leaves the idle microphone closed; tap-to-talk still works. Leave voice use idle
while Windows runs a task, because the Pi model has one generation slot.

## Pairing boundaries

- Local discovery advertises Node Llama's computer name and service identity while
  the Windows app runs. It does not advertise conversations, passwords or tokens.
- First pairing uses a six-digit, two-minute code with at most five attempts per
  opened code. SPAKE2 authenticates the code exchange and binds it to the TLS
  certificate. The code itself is not sent as a network login password.
- Subsequent connections pin that certificate and use a saved device credential.
- Model requests use SSH with a dedicated key and a pinned Pi host key. No
  interactive SSH window or Pi password is needed after pairing.
- The pairing key allows forwarding to `127.0.0.1:8080`; shell commands, PTY,
  agent forwarding and X11 are disabled. The installer additionally restricts the
  Pi account to local TCP forwarding and disables Unix-socket forwarding.
- Existing normal SSH login keys remain in their usual authorized-keys files.
  If you use custom SSH forwarding settings on this account, review the generated
  `/etc/ssh/sshd_config.d/80-pocket-llama-node.conf` first.
- Pairing files are saved locally: Windows under `%LOCALAPPDATA%\NodeLlama\pairing`,
  Pi under `~/Pocket-Llama/.node-link`. Protect those folders like credentials.
- The Windows controls and file permissions from the previous build remain.
  Connecting does not authorize unrestricted Windows shell commands.

This is prototype software, not an independent security audit or certification.

## Disconnect and forget

Say **“Llama, disconnect from Node”**, or use Node → Disconnect. If a Windows task
is active, stop it in Node Llama first. Disconnect keeps the remembered pairing.

To revoke future access, use **Pi → Node → Forget all pairings → Forget**. This
removes the dedicated authorized keys on the Pi. **Close Node Llama on each paired
PC as well:** removing an SSH key does not terminate an already authenticated SSH
tunnel. On Windows, Remove deletes its device entry and pairing record; it cannot
remove the key from an offline Pi. Forget on both sides before selling either
machine. These actions do not erase project files or chat records.

## Troubleshooting

- **No Node found:** Windows app open? Same LAN? Private firewall permission? Guest
  isolation/VPN? Restart Node Llama after changing network adapters. Use your own
  private hotspot/router if event Wi-Fi blocks local devices.
- **Wrong code:** generate a new Windows code and enter it on the selected Pi.
- **Computer identity changed:** do not accept it automatically. If you intentionally
  reinstalled/reset Node Llama, forget the old pairing and pair again.
- **Paired, connection needs attention:** pairing was saved, but SSH/model readiness
  failed. Check the Pi ran `enable-node-link.sh`, then retry Connect. The Windows
  message includes the actual SSH error. Check `pocket-llm` is active if SSH works.
- **“Llama” is missed:** use the touch Connect option; verify the microphone and say
  the phrase clearly. Do not change a working audio sample rate to force wake mode.
- **Speech is slow during a Windows task:** both use the Pi's CPU/model resources.
  Wait for one task to finish before speaking to the other interface.

## Validation for this update

The code-pairing/reconnect tests use real local TLS sockets with simulated SSH/model
completion. They cover correct/wrong/expired codes, retry limits, saved identity
checks, forgetting, selection behavior and command parsing. Voice-loop tests use
simulated microphone/transcription data; they check the two-part wake command,
background speech filtering and idle-microphone behavior. Browser tests exercise
the new pairing-code UI and the existing file/receipt workflow.

A real OpenSSH daemon test was blocked by this execution environment's chroot
restriction. Windows firewall, multicast discovery on your LAN, actual microphone
recognition, and an end-to-end Pi/Windows tunnel still require the six-step pairing
check above. No claim is made that they were tested on your physical devices.

Implementation references:
- [python-zeroconf](https://python-zeroconf.readthedocs.io/en/latest/api.html)
- [python-spake2](https://github.com/warner/python-spake2)
- [OpenSSH authorized keys](https://man.openbsd.org/sshd.8)
- [OpenSSH server forwarding configuration](https://man.openbsd.org/sshd_config.5)
