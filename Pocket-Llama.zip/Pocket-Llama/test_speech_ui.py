import json
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
from PIL import ImageChops

from app import Engine
from audio_io import play_pcm
from speech_ui import ReadyEstimate, SpeechAudio, estimate_label
from test_audio_io import FakeAudio, tone
from touch_ui import Scene, font, wrap_pixels


def part(alignments=None):
    return SimpleNamespace(audio_int16_bytes=(np.ones(1000,dtype=np.int16)*1000).tobytes(),
                           sample_rate=1000, sample_channels=1, phoneme_alignments=alignments)


class CaptionTests(unittest.TestCase):
    def test_phoneme_boundaries_reveal_words_at_their_audio_positions(self):
        a=lambda p,n: SimpleNamespace(phoneme=p,num_samples=n)
        packet=SpeechAudio.from_parts('Hello world.',[part([a('^',100),a('h',250),a(' ',150),a('w',350),a('$',150)])])
        self.assertTrue(packet.aligned)
        self.assertEqual(packet.visible(.09),'')
        self.assertEqual(packet.visible(.1),'Hello')
        self.assertEqual(packet.visible(.49),'Hello')
        self.assertEqual(packet.visible(.5),'Hello world.')

    def test_expanded_numbers_use_duration_fallback_without_dropping_words(self):
        a=lambda p,n: SimpleNamespace(phoneme=p,num_samples=n)
        packet=SpeechAudio.from_parts('12 items.',[part([a('t',100),a(' ',50),a('w',100),a(' ',50),a('i',700)])])
        self.assertFalse(packet.aligned)
        self.assertEqual(packet.visible(1),'12 items.')
        self.assertEqual(packet.visible(-.1),'')

    def test_multiple_piper_chunks_offset_word_cues_and_keep_pcm(self):
        a=lambda p,n: SimpleNamespace(phoneme=p,num_samples=n)
        chunks=[part([a('h',1000)]),part([a('w',1000)])]
        packet=SpeechAudio.from_parts('Hello world.',chunks)
        self.assertEqual(packet.cue_times,[0,1])
        self.assertEqual(len(packet.audio_int16_bytes),4000)
        self.assertEqual(packet.visible(.8),'Hello')

    def test_engine_emits_only_words_reached_by_playback_and_keeps_prefix(self):
        import queue
        packet=SpeechAudio.from_parts('Hello world.',[part()])
        engine=Engine({'output_device':'USB'},queue.Queue())
        def playback(*args, on_progress=None, **kwargs):
            for value in (-.1,.01,.01,1): on_progress(value)
        with patch('audio_io.play_pcm', side_effect=playback):
            engine.play_audio(packet,0,threading.Event(),prefix='Earlier sentence.')
        captions=[value for kind,value,_ in engine.events.queue if kind=='caption']
        self.assertEqual(captions,['Earlier sentence.','Earlier sentence. Hello','Earlier sentence. Hello world.'])

    def test_cancelled_epoch_does_not_emit_late_captions(self):
        import queue
        packet=SpeechAudio.from_parts('Hello world.',[part()])
        engine=Engine({'output_device':'USB'},queue.Queue())
        def playback(*args, on_progress=None, **kwargs):
            engine.cancel()
            on_progress(1)
        with patch('audio_io.play_pcm',side_effect=playback):
            engine.play_audio(packet,0,threading.Event())
        self.assertEqual(list(engine.events.queue),[])


class EstimateTests(unittest.TestCase):
    def test_estimate_counts_down_and_reports_overrun_instead_of_fake_zero(self):
        self.assertIn('20s',estimate_label(10,20,10))
        self.assertIn('5s',estimate_label(10,20,25))
        self.assertEqual(estimate_label(10,20,31),'Taking longer than estimated...')

    def test_estimate_learns_completed_preparation_times_and_persists_only_numbers(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'timing.json'
            estimate=ReadyEstimate(path)
            self.assertEqual(estimate.seconds,20)
            estimate.observe(12)
            estimate.observe(20)
            estimate.observe(float('nan'))
            saved=ReadyEstimate(path)
            self.assertAlmostEqual(saved.seconds,14.8)
            self.assertEqual(saved.count,2)
            self.assertEqual(set(json.loads(path.read_text())),{'count','seconds'})


class DialogueTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scene=Scene()

    def test_generating_panel_never_shows_prompt_or_future_reply(self):
        clean=self.scene.draw(state='thinking',wait_label='About 12s remaining (estimate)')
        hidden=self.scene.draw(state='thinking',user='PROMPT SHOULD NOT OVERLAP',reply='FUTURE WORDS',wait_label='About 12s remaining (estimate)')
        self.assertIsNone(ImageChops.difference(clean,hidden).getbbox())

    def test_spoken_panel_is_independent_of_transcribed_prompt(self):
        base=self.scene.draw(state='speaking',reply='Only spoken words.')
        actual=self.scene.draw(state='speaking',reply='Only spoken words.',user='Very long prompt '*100)
        self.assertIsNone(ImageChops.difference(base,actual).getbbox())

    def test_long_text_stays_inside_dialogue_region(self):
        blank=self.scene.draw(state='speaking',reply='Hello.')
        full=self.scene.draw(state='speaking',reply='supercalifragilisticexpialidocious'*80)
        box=ImageChops.difference(blank,full).getbbox()
        self.assertIsNotNone(box)
        self.assertGreaterEqual(box[0],34)
        self.assertGreaterEqual(box[1],195)
        self.assertLessEqual(box[2],448)
        self.assertLessEqual(box[3],268)
        face=font(12)
        self.assertTrue(all(face.getlength(row)<=410 for row in wrap_pixels('abc '*80+'W'*300,face,410)))


class PlaybackProgressTests(unittest.TestCase):
    def test_device_clock_and_buffer_tail_pace_captions(self):
        class Buffered(FakeAudio):
            def __init__(self):
                super().__init__()
                self.clock=0
                self.latency=.1
                self.drained=False
            @property
            def time(self):
                self.clock+=.025
                return self.clock
            def stop(self):
                self.drained=True
        sd, progress=Buffered(),[]
        with patch('audio_io.time.sleep',return_value=None):
            play_pcm(tone(22050).tobytes(),22050,1,'USB test',sd=sd,on_progress=progress.append)
        self.assertTrue(sd.drained)
        self.assertTrue(sd.closed)
        self.assertEqual(progress[-1],.6)
        self.assertTrue(any(0<p<.6 for p in progress))
        self.assertEqual(progress,sorted(progress))


if __name__=='__main__': unittest.main()
