"""Speech captions and an explicitly approximate wait estimate."""
from bisect import bisect_right
from dataclasses import dataclass
import json
import math
from pathlib import Path
import re
import unicodedata

import numpy as np


class ReadyEstimate:
    def __init__(self, path=None):
        self.path = Path(path) if path else None
        self.seconds, self.count = 20.0, 0
        if self.path and self.path.exists():
            try:
                saved = json.loads(self.path.read_text())
                value = float(saved['seconds'])
                if math.isfinite(value) and 2 <= value <= 180:
                    self.seconds = value
                    self.count = max(0, int(saved.get('count', 0)))
            except (OSError, ValueError, KeyError, TypeError):
                pass

    def observe(self, seconds):
        if not math.isfinite(seconds) or not 1 <= seconds <= 180:
            return
        self.seconds = seconds if not self.count else .65*self.seconds + .35*seconds
        self.count += 1
        if self.path:
            try:
                temporary = self.path.with_suffix('.tmp')
                temporary.write_text(json.dumps({'seconds': self.seconds, 'count': self.count})+'\n')
                temporary.replace(self.path)
            except OSError:
                pass  # A read-only card must not prevent a spoken answer.


def estimate_label(started, estimate, now):
    if started is None:
        return 'Estimating time...'
    remaining = estimate - max(0, now-started)
    if remaining <= 0:
        return 'Taking longer than estimated...'
    return f'About {math.ceil(remaining)}s remaining (estimate)'


def aligned_word_starts(parts):
    starts, offset = [], 0.0
    for part in parts:
        alignments = getattr(part, 'phoneme_alignments', None)
        if not alignments:
            return None
        cursor, in_word = offset, False
        for alignment in alignments:
            phoneme = alignment.phoneme
            count = int(alignment.num_samples)
            if count < 0:
                return None
            if phoneme.isspace():
                in_word = False
            elif phoneme not in ('^', '$', '_') and any(
                    unicodedata.category(c).startswith(('L', 'N')) for c in phoneme):
                if not in_word:
                    starts.append(cursor)
                    in_word = True
            cursor += count / part.sample_rate
        offset += len(part.audio_int16_bytes)/(2*part.sample_channels*part.sample_rate)
    return starts


def estimated_word_starts(text, pcm, rate, channels):
    """Fallback pacing within actual audio duration; not forced word alignment."""
    words = re.findall(r'\S+', text)
    if not words:
        return []
    samples = np.frombuffer(pcm, dtype=np.int16).reshape(-1, channels).astype(np.float32)
    duration = len(samples)/rate
    left, right = 0.0, duration
    if samples.size:
        strength = np.max(np.abs(samples), axis=1)
        active = np.flatnonzero(strength > max(50, float(strength.max())*.035))
        if active.size:
            left, right = active[0]/rate, (active[-1]+1)/rate
    weights = [max(1, len(re.sub(r'\W', '', word)))**.65 +
               (.8 if re.search(r'[,;:]$', word) else 0) for word in words]
    span, total, elapsed = max(.01, right-left), sum(weights), 0.0
    starts = []
    for weight in weights:
        starts.append(left+span*elapsed/total)
        elapsed += weight
    return starts


@dataclass
class SpeechAudio:
    text: str
    audio_int16_bytes: bytes
    sample_rate: int
    sample_channels: int
    cue_times: list
    cue_ends: list
    aligned: bool

    @classmethod
    def from_parts(cls, text, parts):
        if not parts:
            raise RuntimeError('The voice returned no audio for a sentence.')
        rate, channels = parts[0].sample_rate, parts[0].sample_channels
        if any((p.sample_rate, p.sample_channels) != (rate, channels) for p in parts):
            raise RuntimeError('The voice changed audio format within a sentence.')
        pcm = b''.join(p.audio_int16_bytes for p in parts)
        if not pcm:
            raise RuntimeError('The voice returned empty audio.')
        ends = [m.end() for m in re.finditer(r'\S+', text)]
        times = aligned_word_starts(parts)
        duration = len(pcm)/(2*channels*rate)
        aligned = bool(times) and len(times) == len(ends) and all(
            math.isfinite(t) and 0 <= t < duration for t in times) and times == sorted(times)
        if not aligned:
            times = estimated_word_starts(text, pcm, rate, channels)
        return cls(text, pcm, rate, channels, times, ends, bool(aligned))

    def visible(self, seconds):
        index = bisect_right(self.cue_times, seconds)-1
        return self.text[:self.cue_ends[index]] if index >= 0 else ''
