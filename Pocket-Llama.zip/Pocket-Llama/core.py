"""Conversation helpers without hardware dependencies."""
import re
from collections import deque

SYSTEM_PROMPT = (
    "You are Pocket Llama, a friendly local conversational assistant. "
    "Talk naturally and answer directly, usually in one or two short sentences. "
    "Start with a brief sentence of about ten words, then add detail if useful. "
    "Use plain spoken language. You only converse: you have no tools, internet, "
    "or ability to operate devices or execute commands. Never claim to have "
    "performed an action. Admit uncertainty. Do not include hidden reasoning."
)


def spoken_text(text):
    # Never read reasoning blocks, including an unfinished block, aloud.
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S)
    text = re.sub(r"<think>.*$", "", text, flags=re.S)
    text = re.sub(r"```.*?```", " [Code omitted from speech.] ", text, flags=re.S)
    text = re.sub(r"```.*$", " [Code omitted from speech.] ", text, flags=re.S)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    return re.sub(r"\s+", " ", text.replace("*", "").replace("`", "")).strip()


class SpeechChunker:
    """Collect complete sentences while withholding reasoning and code fences."""
    TOKENS = ("<think>", "</think>", "```")
    BOUNDARY = re.compile(r'''[.!?]+["'”’)\]]*(?=\s)''')
    ABBREVIATIONS = {"mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st",
                     "vs", "etc", "e.g", "i.e", "no", "fig", "approx"}

    def __init__(self):
        self.raw = ""
        self.pending = ""
        self.mode = "text"

    def feed(self, delta, final=False):
        self.raw += delta
        while self.raw:
            if self.mode != "text":
                marker = "</think>" if self.mode == "think" else "```"
                end = self.raw.find(marker)
                if end < 0:
                    self.raw = self.raw[-(len(marker) - 1):]
                    break
                self.raw = self.raw[end + len(marker):]
                self.mode = "text"
                continue
            marker = next((token for token in self.TOKENS if self.raw.startswith(token)), None)
            if marker:
                self.raw = self.raw[len(marker):]
                if marker == "<think>":
                    self.mode = "think"
                elif marker == "```":
                    self.mode = "code"
                    self.pending += " [Code omitted from speech.] "
                continue
            # Wait if the current chunk ends partway through a control marker.
            if any(token.startswith(self.raw) for token in self.TOKENS):
                break
            self.pending += self.raw[0]
            self.raw = self.raw[1:]
        ready = []
        end = 0
        for match in self.BOUNDARY.finditer(self.pending):
            prefix = self.pending[end:match.end()]
            last_word = re.search(r"([A-Za-z.]+)\.$", prefix)
            if last_word and (last_word[1].lower() in self.ABBREVIATIONS or len(last_word[1]) == 1):
                continue
            sentence = spoken_text(prefix)
            if sentence:
                ready.append(sentence)
            end = match.end()
        self.pending = self.pending[end:]
        if final:
            tail = spoken_text(self.pending)
            if tail:
                ready.append(tail)
            self.pending = self.raw = ""
        return ready


class Utterance:
    """30-ms frames, pre-roll, debounced speech onset, silence endpoint."""
    def __init__(self, silence_ms=1050, max_seconds=20):
        self.silence_frames = max(1, int(silence_ms / 30))
        self.max_frames = max(20, int(max_seconds / .03))
        self.pre = deque(maxlen=10)
        self.votes = deque(maxlen=5)
        self.frames = []
        self.active = False
        self.silent = 0
        self.voiced = 0

    def feed(self, frame, is_speech):
        if not self.active:
            self.pre.append(frame)
            self.votes.append(bool(is_speech))
            if sum(self.votes) < 3:
                return None
            self.active = True
            self.frames = list(self.pre)
            self.voiced = sum(self.votes)
            return None
        self.frames.append(frame)
        self.voiced += bool(is_speech)
        self.silent = 0 if is_speech else self.silent + 1
        if self.silent >= self.silence_frames or len(self.frames) >= self.max_frames:
            return b"".join(self.frames) if self.voiced >= 8 else b""
        return None


class ManualRecording:
    """Keep 16 kHz/30 ms frames until explicit send or a bounded time limit."""
    def __init__(self, max_seconds=30):
        self.max_frames = max(1, int(max_seconds / .03))
        self.frames = []
        self.voiced = 0

    def feed(self, frame, is_speech):
        if len(self.frames) < self.max_frames:
            self.frames.append(frame)
            self.voiced += bool(is_speech)
        return len(self.frames) >= self.max_frames

    def finish(self):
        # Avoid sending an empty/silent recording to Whisper.
        return b"".join(self.frames) if self.voiced >= 5 else b""


class TouchGesture:
    """A tap starts capture; a separate hold and release submits it."""
    def __init__(self, hold_seconds=.65):
        self.hold_seconds = hold_seconds
        self.started = None
        self.state = None

    def press(self, state, now):
        self.state, self.started = state, now

    def progress(self, now):
        if self.started is None or self.state != "listening":
            return 0
        return min(1, max(0, (now - self.started) / self.hold_seconds))

    def release(self, state, now):
        original, started = self.state, self.started
        self.cancel()
        if started is None or state != original:
            return None
        if state == "idle":
            return "listen"
        if state == "listening" and now - started >= self.hold_seconds:
            return "send"
        if state in ("thinking", "transcribing", "speaking"):
            return "interrupt"
        return None

    def cancel(self):
        self.started = self.state = None


def discard_oldest_pair(messages):
    """Keep the system instruction and the newest user message."""
    if len(messages) > 2:
        return [messages[0]] + messages[3:]
    raise ValueError("That prompt is too long. Please ask a shorter question.")
