#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
.venv/bin/python - <<'PY'
import json
from pathlib import Path
p=Path('config.json')
c=json.loads(p.read_text())
c.update(stt_backend='whisper',stt_url='http://127.0.0.1:8081')
p.write_text(json.dumps(c,indent=2)+'\n')
PY
sudo systemctl enable --now pocket-stt
sudo systemctl disable --now pocket-hailo
echo 'CPU Whisper selected. Close and reopen Pocket Llama, or reboot.'
