#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $EUID -eq 0 || "$PWD" != "$HOME/Pocket-Llama" || "$PWD" =~ [[:space:]%] ]]; then
  echo 'Run as your normal Pi user: bash ~/Pocket-Llama/enable-node-link.sh' >&2
  exit 1
fi
if [[ ! -x .venv/bin/python ]]; then
  echo 'The existing Pocket Llama environment is missing. Complete the main install first.' >&2
  exit 1
fi
sudo apt-get install -y openssh-server
.venv/bin/python -m pip install 'zeroconf>=0.140,<1' 'cryptography>=44,<48' 'spake2==0.9'
.venv/bin/python setup_node_link.py
printf '%s\n' 'Node connection enabled. Reboot Pocket Llama, then pair from MENU > NODE / CONNECT.'
