#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $EUID -eq 0 || "$PWD" != "$HOME/Pocket-Llama" ]]; then
  echo 'Run as your normal user from ~/Pocket-Llama.' >&2
  exit 1
fi
sudo python3 kiosk_install.py --disable --user "$(id -un)" --project "$PWD"
if [[ -f "$HOME/.config/autostart/pocket-llama.desktop.before-kiosk" ]]; then
  mv "$HOME/.config/autostart/pocket-llama.desktop.before-kiosk" "$HOME/.config/autostart/pocket-llama.desktop"
fi
echo 'Previous desktop startup restored. Reboot when convenient.'
