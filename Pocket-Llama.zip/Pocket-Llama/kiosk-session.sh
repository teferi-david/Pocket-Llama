#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
export XDG_SESSION_TYPE=wayland
export XDG_CURRENT_DESKTOP=labwc
mkdir -p logs
exec labwc -C "$PWD/.kiosk" -S "/bin/bash $PWD/kiosk-run.sh" >>logs/kiosk-session.log 2>&1
