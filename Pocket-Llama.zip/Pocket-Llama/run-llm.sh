#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
export OPENBLAS_NUM_THREADS=1
exec ./llama.cpp/build/bin/llama-server \
  --model ./models/Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf \
  --alias pocket-llama --host 127.0.0.1 --port 8080 \
  --ctx-size 4096 --parallel 1 --threads 4 --threads-batch 4 \
  --batch-size 256 --ubatch-size 128 --n-gpu-layers 0 \
  --jinja --reasoning off --chat-template-kwargs '{"enable_thinking":false}'
