import asyncio
import contextlib
import json
import queue
import threading
import unittest

from app import Engine, cancellable, lines_with_ticks
from core import SpeechChunker


class ChunkTests(unittest.TestCase):
    def test_sentences_are_released_before_final_and_not_repeated(self):
        c = SpeechChunker()
        self.assertEqual(c.feed("First sen"), [])
        self.assertEqual(c.feed("tence."), [])
        self.assertEqual(c.feed(" Second sen"), ["First sentence."])
        self.assertEqual(c.feed("tence!", final=True), ["Second sentence!"])
        self.assertEqual(c.feed("", final=True), [])

    def test_split_reasoning_and_unfinished_code_are_never_spoken(self):
        c = SpeechChunker()
        output = []
        for delta in ["<thi", "nk>Secret. ", "More secret.</thi", "nk>Visible. ",
                      "`", "``python\nsecret_code(). "]:
            output.extend(c.feed(delta))
        output.extend(c.feed("", final=True))
        self.assertEqual(output, ["Visible.", "[Code omitted from speech.]"])

    def test_decimal_and_common_abbreviation_are_not_sentence_breaks(self):
        c = SpeechChunker()
        self.assertEqual(c.feed("Dr. Smith measured 3.14 grams. Next"),
                         ["Dr. Smith measured 3.14 grams."])
        self.assertEqual(c.feed("", final=True), ["Next"])

    def test_three_complete_words_wait_for_sentence_end(self):
        c = SpeechChunker()
        self.assertEqual(c.feed("Bread rises because ye"), [])
        self.assertEqual(c.feed("ast releases gas.", final=True),
                         ["Bread rises because yeast releases gas."])

    def test_empty_ticks_never_release_an_incomplete_sentence(self):
        c = SpeechChunker()
        self.assertEqual(c.feed("These two unfinish"), [])
        for _ in range(10):
            self.assertEqual(c.feed(""), [])
        self.assertEqual(c.feed("ed words.", final=True), ["These two unfinished words."])

    def test_word_counts_commas_and_semicolons_do_not_split_sentences(self):
        text = "One two three, four five six; seven eight nine: ten eleven twelve."
        chunks = SpeechChunker().feed(text, final=True)
        self.assertEqual(chunks, [text])

    def test_per_character_stream_never_speaks_hidden_content(self):
        c = SpeechChunker()
        output = []
        text = "<think>Secret hidden reasoning.</think>These words are spoken. ```private code``` Done."
        for char in text:
            output.extend(c.feed(char))
        output.extend(c.feed("", final=True))
        self.assertEqual(" ".join(output), "These words are spoken. [Code omitted from speech.] Done.")


class FakeResponse:
    is_error = False

    def __init__(self, played):
        self.played, self.finished, self.early_speech = played, False, False

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return False

    def raise_for_status(self):
        pass

    async def aiter_lines(self):
        for delta in ["<think>secret.</think>", "First sentence. "]:
            yield "data: " + json.dumps({"choices": [{"delta": {"content": delta}}]})
        await asyncio.sleep(.06)
        self.early_speech = self.played.is_set()
        yield "data: " + json.dumps({"choices": [{"delta": {"content": "Second sentence."}}]})
        self.finished = True
        yield "data: [DONE]"


class FakeClient:
    def __init__(self, response):
        self.response = response

    async def post(self, url, **kwargs):
        class Result:
            def raise_for_status(self):
                pass
            def json(self):
                return {"prompt": "short prompt", "tokens": [1, 2, 3]}
        return Result()

    def stream(self, *args, **kwargs):
        return self.response


def audio_part():
    from types import SimpleNamespace
    return SimpleNamespace(audio_int16_bytes=b'\x10\x01'*3200, sample_rate=16000,
                           sample_channels=1, phoneme_alignments=None)


def engine():
    e = Engine({"auto_listen": True, "context_size": 4096,
                "max_reply_tokens": 96, "llm_url": "http://127.0.0.1:8080"}, queue.Queue())
    e.synthesize = lambda text, epoch, stopped: iter([audio_part()])
    return e


class PipelineTests(unittest.IsolatedAsyncioTestCase):
    async def test_leaving_idle_stream_joins_pending_network_read(self):
        ended = asyncio.Event()
        class Response:
            async def aiter_lines(self):
                try:
                    await asyncio.sleep(60)
                    yield "unreachable"
                finally:
                    ended.set()
        async with contextlib.aclosing(lines_with_ticks(Response())) as lines:
            self.assertIsNone(await anext(lines))
        self.assertTrue(ended.is_set())

    async def test_full_reply_finishes_before_speech_and_no_draft_leaks_to_ui(self):
        e, played, heard = engine(), threading.Event(), []
        response = FakeResponse(played)
        def speak(packet, epoch, stopped, prefix=""):
            self.assertTrue(response.finished)
            heard.append((packet.text, prefix))
            played.set()
        e.play_audio = speak
        reply = await asyncio.wait_for(e.answer_and_speak(FakeClient(response), "Hi", 0), 3)
        self.assertFalse(response.early_speech)
        self.assertEqual(heard, [("First sentence.", ""), ("Second sentence.", "First sentence.")])
        self.assertEqual(reply, "First sentence. Second sentence.")
        self.assertEqual(e.history[-1]["content"], reply)
        events = list(e.events.queue)
        self.assertNotIn("draft", [x[0] for x in events])
        self.assertEqual(events[0][0], "generation_wait")

    async def test_cancel_during_generation_never_starts_speech(self):
        e = engine()
        began, ended = asyncio.Event(), asyncio.Event()
        heard = []
        async def answer(client, text, epoch, enqueue):
            try:
                enqueue("Must not play.")
                began.set()
                await asyncio.sleep(60)
            finally:
                ended.set()
        e.answer = answer
        e.play_audio = lambda *args, **kwargs: heard.append(True)
        task = asyncio.create_task(cancellable(e.answer_and_speak(None, "Hi", 0), lambda: e.stale(0)))
        await began.wait()
        e.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await asyncio.wait_for(task, 3)
        self.assertTrue(ended.is_set())
        self.assertEqual(heard, [])

    async def test_cancel_joins_playback_and_drops_queued_sentences(self):
        e = engine()
        began, ended, heard = threading.Event(), threading.Event(), []
        async def answer(client, text, epoch, enqueue):
            enqueue("First.")
            enqueue("Must not play.")
            return "Full answer", [{"role": "assistant", "content": "Full answer"}]
        def speak(packet, epoch, stopped, prefix=""):
            heard.append(packet.text)
            began.set()
            stopped.wait(2)
            ended.set()
        e.answer, e.play_audio = answer, speak
        task = asyncio.create_task(cancellable(e.answer_and_speak(None, "Hi", 0), lambda: e.stale(0)))
        self.assertTrue(await asyncio.to_thread(began.wait, 2))
        e.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await asyncio.wait_for(task, 3)
        self.assertTrue(ended.is_set())
        self.assertEqual(heard, ["First."])
        self.assertEqual(e.history, [])

    async def test_audio_failure_does_not_commit_history(self):
        e = engine()
        async def answer(client, text, epoch, enqueue):
            enqueue("Hello.")
            return "Hello.", [{"role":"assistant", "content":"Hello."}]
        def speak(*args, **kwargs):
            raise RuntimeError("audio device disconnected")
        e.answer, e.play_audio = answer, speak
        with self.assertRaisesRegex(RuntimeError, "audio device disconnected"):
            await asyncio.wait_for(e.answer_and_speak(None, "Hi", 0), 3)
        self.assertEqual(e.history, [])

    async def test_generation_failure_does_not_play_partial_reply(self):
        e, heard = engine(), []
        async def answer(client, text, epoch, enqueue):
            enqueue("Hello.")
            raise RuntimeError("model connection closed")
        e.answer = answer
        e.play_audio = lambda *args, **kwargs: heard.append(True)
        with self.assertRaisesRegex(RuntimeError, "model connection closed"):
            await e.answer_and_speak(None, "Hi", 0)
        self.assertEqual(heard, [])
        self.assertEqual(e.history, [])

    async def test_saved_phrase_settings_still_produce_whole_sentences(self):
        e, heard = engine(), []
        e.cfg.update(speech_max_wait=.2, speech_first_words=2, speech_chunk_words=2)
        response = FakeResponse(threading.Event())
        e.play_audio = lambda packet, *args, **kwargs: heard.append(packet.text)
        await e.answer_and_speak(FakeClient(response), "Hi", 0)
        self.assertEqual(heard, ["First sentence.", "Second sentence."])

    async def test_next_sentence_is_synthesized_during_current_playback(self):
        e = engine()
        playing, second_ready = threading.Event(), threading.Event()
        heard = []
        async def answer(client, text, epoch, enqueue):
            enqueue("First sentence.")
            enqueue("Second sentence.")
            return "Full reply", []
        def synthesize(text, epoch, stopped):
            if text == "Second sentence.":
                self.assertTrue(playing.wait(2))
                second_ready.set()
            yield audio_part()
        def play(packet, epoch, stopped, prefix=""):
            heard.append(packet.text)
            if packet.text == "First sentence.":
                playing.set()
                self.assertTrue(second_ready.wait(2))
        e.answer, e.synthesize, e.play_audio = answer, synthesize, play
        await asyncio.wait_for(e.answer_and_speak(None, "Hi", 0), 3)
        self.assertEqual(heard, ["First sentence.", "Second sentence."])

    async def test_synthesis_failure_stops_and_joins_playback(self):
        e = engine()
        playing, playback_ended = threading.Event(), threading.Event()
        async def answer(client, text, epoch, enqueue):
            enqueue("First.")
            enqueue("Fail.")
            return "Full reply", []
        def synthesize(text, epoch, stopped):
            if text == "Fail.":
                self.assertTrue(playing.wait(2))
                raise RuntimeError("synthesis failed")
            yield audio_part()
        def play(packet, epoch, stopped, prefix=""):
            playing.set()
            stopped.wait(2)
            playback_ended.set()
        e.answer, e.synthesize, e.play_audio = answer, synthesize, play
        with self.assertRaisesRegex(RuntimeError, "synthesis failed"):
            await asyncio.wait_for(e.answer_and_speak(None, "Hi", 0), 3)
        self.assertTrue(playback_ended.is_set())
        self.assertEqual(e.history, [])

    async def test_cancel_with_full_audio_queue_joins_synthesis(self):
        e = engine()
        fifth, synth_ended, playing = threading.Event(), threading.Event(), threading.Event()
        async def answer(client, text, epoch, enqueue):
            for i in range(10): enqueue(str(i))
            return "Full reply", []
        def synthesize(text, epoch, stopped):
            try:
                if text == '4': fifth.set()
                yield audio_part()
            finally:
                synth_ended.set()
        def play(packet, epoch, stopped, prefix=""):
            playing.set()
            stopped.wait(2)
        e.answer, e.synthesize, e.play_audio = answer, synthesize, play
        task = asyncio.create_task(cancellable(e.answer_and_speak(None, "Hi", 0), lambda: e.stale(0)))
        self.assertTrue(await asyncio.to_thread(playing.wait, 2))
        await asyncio.sleep(.05)
        e.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await asyncio.wait_for(task, 3)
        self.assertTrue(synth_ended.is_set())
        self.assertFalse(fifth.is_set())


if __name__ == "__main__":
    unittest.main()
