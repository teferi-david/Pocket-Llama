#!/usr/bin/env bash
set -uo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p logs
exec >>logs/kiosk.log 2>&1
systemctl --user import-environment DISPLAY WAYLAND_DISPLAY XDG_CURRENT_DESKTOP XDG_SESSION_TYPE
dbus-update-activation-environment --systemd DISPLAY WAYLAND_DISPLAY XDG_CURRENT_DESKTOP XDG_SESSION_TYPE
systemctl --user start pipewire.service pipewire-pulse.service wireplumber.service
# Never launch the app on HDMI after a failed or incomplete display setup.
display_ready=false
for attempt in 1 2 3 4 5; do
  if python3 configure_display.py --apply --exclusive; then
    display_ready=true
    break
  fi
  sleep 1
done
if [[ $display_ready != true ]]; then
  echo 'SPI-1 setup failed. App startup stopped. See logs/kiosk.log.' >&2
  exit 1
fi
if [[ ! -f .kiosk/touch-verified && ! -f .kiosk/touch-skipped ]]; then
  .venv/bin/python calibrate_touch.py
fi
# This session launches no panel, file manager, or desktop autostart entries.
# A normal app exit opens a maintenance terminal; crashes restart the app.
failures=0
while true; do
  .venv/bin/python app.py --kiosk
  result=$?
  if [[ $result -eq 0 || $failures -ge 3 ]]; then
    foot --title='Pocket Llama maintenance' /bin/bash || break
    failures=0
  else
    failures=$((failures+1))
    sleep 2
  fi
done
