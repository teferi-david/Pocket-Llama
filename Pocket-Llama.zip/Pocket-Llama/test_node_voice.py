import asyncio
import json
from pathlib import Path
import queue
import tempfile
import unittest
from unittest.mock import AsyncMock, patch
import app


class NodeVoiceTests(unittest.IsolatedAsyncioTestCase):
    async def test_two_part_wake_command_never_reaches_chat_model(self):
        cfg=json.loads((app.ROOT/'config.example.json').read_text())
        cfg['wake_enabled']=True
        with tempfile.TemporaryDirectory() as directory,patch.object(app,'ROOT',Path(directory)):
            engine=app.Engine(cfg,queue.Queue())
            engine.load_voice=lambda _:None
            engine.warm_voice=lambda:None
            engine.ready=AsyncMock()
            heard=iter(['ordinary background speech','Llama.','Connect to Node.'])
            formats=[]
            def record(epoch,automatic=False,background=False):
                formats.append((automatic,background));return b'fictional audio'
            engine.record=record
            async def transcribe(*args):return next(heard)
            engine.transcribe=transcribe
            engine.answer_and_speak=AsyncMock()
            connected=[]
            def connect():connected.append(True);engine.closing.set()
            engine.node_link.begin=connect
            await asyncio.wait_for(engine.run_async(),timeout=3)
            self.assertEqual(formats,[(True,True),(True,True),(True,False)])
            self.assertEqual(connected,[True])
            engine.answer_and_speak.assert_not_awaited()
            self.assertEqual(engine.history,[])

    async def test_wake_off_leaves_idle_microphone_closed(self):
        cfg=json.loads((app.ROOT/'config.example.json').read_text())
        cfg['wake_enabled']=False
        with tempfile.TemporaryDirectory() as directory,patch.object(app,'ROOT',Path(directory)):
            engine=app.Engine(cfg,queue.Queue())
            engine.load_voice=lambda _:None;engine.warm_voice=lambda:None;engine.ready=AsyncMock()
            with patch.object(engine,'record') as record:
                task=asyncio.create_task(engine.run_async())
                await asyncio.sleep(.2);engine.closing.set();await task
                record.assert_not_called()

    def test_menu_pauses_capture_and_cancels_old_epoch(self):
        cfg={'interaction_mode':'touch'}
        with tempfile.TemporaryDirectory() as directory,patch.object(app,'ROOT',Path(directory)):
            engine=app.Engine(cfg,queue.Queue());old=engine.epoch
            engine.pause_background(True)
            self.assertTrue(engine.ui_paused.is_set());self.assertTrue(engine.stale(old))
            now=engine.epoch;engine.pause_background(True);self.assertEqual(engine.epoch,now)
            engine.pause_background(False);self.assertFalse(engine.ui_paused.is_set())

if __name__=='__main__':unittest.main()
