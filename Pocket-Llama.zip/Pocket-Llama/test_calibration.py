"""Regression checks for bouncing taps, retry loops and calibration rollback."""
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

import numpy as np

from calibrate_touch import (CalibrationSession, CHECKS, ProfileChange, TARGETS,
                             TouchSamples)

BASE = b'<labwc_config><keyboard/><libinput><device category="ADS7846 Touchscreen"><calibrationMatrix>1 0 0 0 1 0</calibrationMatrix></device></libinput></labwc_config>'


class SamplingTests(unittest.TestCase):
    def test_release_without_press_and_bounce_do_not_advance(self):
        sample = TouchSamples()
        sample.reset(0)
        self.assertIsNone(sample.release(.8))
        sample.press((.14,.18), 1)
        self.assertEqual(sample.release(1.2), [.14,.18])
        sample.press((.14,.18), 1.3)
        self.assertIsNone(sample.release(1.4))
        sample.press((.86,.18), 2)
        self.assertEqual(sample.release(2.2), [.86,.18])

    def test_median_press_ignores_isolated_motion_jump(self):
        sample = TouchSamples()
        sample.press((.14,.18), 1)
        for point in ((.141,.181),(.139,.179),(.14,.18),(.9,.9)):
            sample.move(point)
        np.testing.assert_allclose(sample.release(1.3), [.14,.18], atol=.001)

    def test_drag_and_very_short_contact_are_not_calibration_points(self):
        sample = TouchSamples()
        sample.press((.14,.18), 1)
        self.assertIsNone(sample.release(1.02))
        sample.press((.1,.1), 2)
        for value in np.linspace(.1,.9,20):
            sample.move((value,value))
        with self.assertRaisesRegex(ValueError, "finger still"):
            sample.release(2.5)


class CalibrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.profile = Path(self.temp.name)
        self.path = self.profile / 'rc.xml'
        self.path.write_bytes(BASE)
        self.reloads = []
        self.change = ProfileChange(self.profile, reload=lambda: self.reloads.append(True))
        self.session = CalibrationSession(self.profile, self.change)

    def collect_rotated(self):
        for x,y in TARGETS:
            self.session.accept((1-y,x))
        self.assertEqual(self.session.stage, 'verify')
        self.assertNotEqual(self.path.read_bytes(), BASE)

    def test_already_working_touch_is_verified_without_rewriting_matrix(self):
        for point in TARGETS + CHECKS:
            self.session.accept(point)
        self.assertEqual(self.session.stage, 'done')
        self.assertTrue((self.profile/'touch-verified').exists())
        self.assertEqual(self.path.read_bytes(), BASE)
        self.assertEqual(self.reloads, [])

    def test_inconsistent_points_pause_without_automatic_retry(self):
        for point in ((.1,.1),(.8,.1),(.1,.1),(.1,.7)):
            self.session.accept(point)
        self.assertEqual(self.session.stage, 'error')
        original_count = len(self.session.observed)
        for point in TARGETS:
            self.session.accept(point)
        self.assertEqual(len(self.session.observed), original_count)
        self.assertEqual(self.path.read_bytes(), BASE)

    def test_failed_verification_restores_exact_original_and_retry_does_not_compound(self):
        self.collect_rotated()
        candidate = self.path.read_bytes()
        self.session.accept((.99,.99))
        self.assertEqual(self.session.stage, 'error')
        self.assertEqual(self.path.read_bytes(), BASE)
        self.assertFalse(self.change.backup.exists())
        self.session.retry()
        self.collect_rotated()
        self.assertEqual(self.path.read_bytes(), candidate)

    def test_skip_during_verification_restores_baseline_and_persists_separate_skip_marker(self):
        self.collect_rotated()
        self.session.skip()
        self.assertEqual(self.session.stage, 'done')
        self.assertEqual(self.path.read_bytes(), BASE)
        self.assertTrue((self.profile/'touch-skipped').exists())
        self.assertFalse((self.profile/'touch-verified').exists())
        self.assertFalse(self.change.backup.exists())

    def test_good_verification_commits_matrix_and_removes_skipped_state(self):
        (self.profile/'touch-skipped').touch()
        self.collect_rotated()
        for point in CHECKS:
            self.session.accept(point)
        self.assertTrue((self.profile/'touch-verified').exists())
        self.assertFalse((self.profile/'touch-skipped').exists())
        self.assertFalse(self.change.backup.exists())
        self.change.restore()
        self.assertNotEqual(self.path.read_bytes(), BASE)

    def test_interrupted_candidate_is_recovered_before_new_attempt(self):
        self.collect_rotated()
        recovered = ProfileChange(self.profile, reload=lambda: None)
        self.assertEqual(recovered.original, BASE)
        self.assertEqual(self.path.read_bytes(), BASE)
        self.assertFalse(recovered.backup.exists())

    def test_failed_reload_rolls_back_written_configuration(self):
        calls = []
        def reload():
            calls.append(True)
            if len(calls) == 1:
                raise RuntimeError('reload failed')
        change = ProfileChange(self.profile, reload=reload)
        with self.assertRaisesRegex(RuntimeError, 'reload failed'):
            change.apply(np.array([[0,-1,1],[1,0,0],[0,0,1]]))
        self.assertEqual(self.path.read_bytes(), BASE)
        self.assertFalse(change.backup.exists())


if __name__ == '__main__':
    unittest.main()
