#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $EUID -eq 0 || "$PWD" != "$HOME/Pocket-Llama" || "$PWD" =~ [[:space:]%] ]]; then
  echo 'Run as the desktop user from ~/Pocket-Llama.' >&2
  exit 1
fi
mkdir -p "$HOME/.config/autostart"
cat > "$HOME/.config/autostart/pocket-llama.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Pocket Llama
Comment=Offline conversational assistant
Exec=${PWD}/.venv/bin/python ${PWD}/app.py
Path=${PWD}
Terminal=false
X-GNOME-Autostart-enabled=true
EOF
echo 'Autostart installed. Enable Desktop Autologin in sudo raspi-config, then reboot.'
