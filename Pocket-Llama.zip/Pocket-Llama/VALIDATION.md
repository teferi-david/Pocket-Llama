Validation of this starter package
=================================

Locally checked on 26 September 2026:

- Sixty-five automated tests passed: six recording/history/cancellation tests, ten audio-format/selection tests, seventeen sentence/generation/playback tests, eleven touchscreen tests, ten calibration tests, and eleven caption/layout/countdown/playback-clock tests.
- The calibration-loop fix tests bounced releases, press medians, very short contacts, drags, inconsistent samples pausing rather than looping, already-correct touch avoiding a matrix rewrite, failed verification restoring the exact baseline, repeated attempts not compounding the matrix, skip persistence, successful verification, interrupted-candidate recovery and reload failure rollback. A live 480x320 Tk/Xvfb check sent deliberately wrong release coordinates and passed the complete setup using press positions, then checked the visible error pause and persistent Skip button. Its paused screen was inspected. These simulated events do not establish how the physical ADS7846 panel will behave.
- The HDMI audio/small-screen update checks name-based audio selection after simulated card renumbering, rejection of ambiguous device names, preservation of unrelated configuration and its backup, repair of a cached HDMI display profile, retention of touch calibration, one combined SPI-on/HDMI-off layout, landscape correction, and refusal to fall back when SPI-1 is absent. Hardware enumeration and display commands are simulated for these regression tests.
- Sentence-speech restoration tests verify that word counts, commas, semicolons, HTTP stalls and saved experimental phrase settings do not release partial sentences. All generation now completes before speech begins. Tests confirm no partial answer is spoken on generation failure, no raw draft reaches the UI, and token boundaries preserve filtering and word order. Existing tests cover next-sentence synthesis during playback and cancellation/errors joining all workers and network reads, including a full bounded audio queue. Piper is simulated in these pipeline tests; Pi synthesis speed is not measured here.
- Audio tests use real SoXR 1.1.0 resampling with synthetic PCM signals and simulated device-format checks/streams. They cover stereo-only hardware, fallback sample rates, actionable unsupported-device errors, overflow-free mono mixing, continuous conversion of irregular 44.1/48 kHz blocks into exact 30 ms VAD frames, duration/pitch preservation, anti-aliasing, conversion of Piper's 22.05 kHz output, and cancellation closing the output stream. These are not tests on the user's USB hardware.
- A live Tk/Xvfb UI check passed for tap-to-listen, rejecting a short send tap, hold/release submission, History paging, Menu, voice volume, New chat and the shutdown confirmation flow. Models/audio were simulated; no actual shutdown was executed. Six UI states were rendered at 480x320 and inspected, and an actual Tk window screenshot was inspected.
- New UI checks passed with live Tk/Xvfb: hidden drafts, generation estimate state, caption-only visible text, full answers retained in History, and stale captions rejected after Stop. Six updated screen states were rendered and visually inspected. Caption tests cover phoneme boundaries, multi-chunk offsets, numeric-expansion fallback, bounded text layout and output buffer-tail timing. Countdown tests cover learning, persistence and estimate overruns. Actual Piper synthesis/alignment and the Pi audio device clock have not been exercised in this environment.
- Python source compiles and the example JSON parses.
- Bash syntax checks pass for all installation, startup, diagnostics and Hailo selection scripts.
- All fifteen build stages and their referenced scripts are present.
- llama.cpp, whisper.cpp, Piper and Hailo integration calls were checked against current upstream documentation/source.
- Balanced-model update: checked the public Hugging Face repository, exact Q4_K_M filename, 1,270,809,024-byte size, immutable revision, GGUF header and SHA-256 metadata. The installer verifies that checksum on the Pi.

- Timing script passed a local simulated SSE-server check: ignores hidden reasoning, combines visible chunks, reads final usage, and surfaces an error event. This is protocol testing, not Pi inference.

User-reported Pi result (26 September 2026):

- The 2B server returned a healthy response and completed both benchmark turns: first text 2.64/2.19 s, complete answer 13.12/19.99 s, 53/85 generated tokens. This confirms that the installed model runs on the user's Pi; it does not validate the full voice loop or the new caption/playback behavior.
- The old audio test failed when requesting mono 16 kHz directly from the selected input (`PaErrorCode -9997`). After the format-negotiation/resampling update, the user reported that it works well. Exact selected device names and hardware sample rates were not supplied.

Not verified in this environment:

- Running the ARM64 installer or model inference on a Raspberry Pi.
- Audio input/output on your USB devices, physical touchscreen mapping, LightDM/labwc kiosk startup, or Pi SPI animation frame rate.
- Hailo HEF inference, the experimental adapter, runtime compatibility, or offline resource availability.
- GPIO/display/UPS compatibility, power consumption, battery life, heat, and safe shutdown on your particular assembly.

Known scope:

- CPU Whisper is the initial working design; the Hailo bridge is an optional integration that needs hardware testing.
- The dedicated graphical session launches the app without the desktop panel or wallpaper. Earlier firmware/kernel boot visuals are not replaced. Kiosk startup must be confirmed on the Pi.
- Kiosk display setup now requires SPI-1 and stops application startup if that screen cannot be configured. The setup repairs an older HDMI profile; audio selection stores names without changing ALSA card numbers. Actual USB playback and small-screen-only boot still require the Pi acceptance check.
- Model services restart after failure. The dedicated session retries unexpected app exits and opens a maintenance terminal after repeated failures.
- Touch interruption is supported after joining playback before opening the mic; talking over playback is not. No automatic battery percentage, UPS shutdown daemon, or replacement SPI driver is supplied.
- The main box shows Generating plus an explicitly approximate estimate until the full reply is generated and the first speech audio is prepared. Whole sentences then play while captions reveal words using phoneme timings when available, or audio-duration pacing as a fallback. Synthesis of the next sentence overlaps playback. Piper is silently warmed before listening. The user found short-phrase speech choppy and requested this restoration. Partial-sentence word-count and timed releases are removed. Actual timing and sound quality of this package still need Pi hardware testing.
- The default is huihui-ai/Huihui-Qwen3.5-2B-abliterated, in mradermacher's Q4_K_M GGUF. It is an experimental refusal-reduced model; no guarantee of zero refusals. No conversational quality benchmark was performed here. The included benchmark-model.py measures local first-text and complete-answer latency with speech inactive.

The original user GIF is bundled unchanged; the app extracts its animated character at runtime and draws the live text and controls separately. Layout is adapted to 480x320, and controller-button labels are replaced with touch instructions.

Follow the build guide's checkpoints before using the device without a monitor or before enclosing the batteries.


## Voice connection update (preview 0.3)

Both app folders are required side by side for `test_pairing.py`. New tests use
real TLS sockets and simulate the SSH/model endpoint. They exercise pairing code
authentication, wrong/expired codes and attempt limits, certificate pinning,
reconnect, forgetting and deterministic device choice. Voice tests inject audio
and transcripts to check the separate wake phrase and connection command, ignoring
background speech and leaving the idle mic closed when wake is off.

Browser verification includes opening a fresh pairing code and the existing
retro UI/file/receipt checks. The 480×320 keypad, chooser and menu were rendered
for layout inspection. Actual microphone detection, multicast/Windows firewall
and Pi/Windows SSH remain hardware checks. A real SSH daemon test here was blocked
by the execution environment's chroot restriction; it is not counted as passed.

Final suite result: Node Llama 36 tests passed; Pocket Llama 68 tests passed.
JavaScript, shell and Python syntax checks passed.
