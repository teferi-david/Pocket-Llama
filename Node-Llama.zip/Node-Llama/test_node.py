r"""Run: .venv\Scripts\python -m unittest -v (no Pi required)."""
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import httpx

from agent import Job, SYSTEM
from connection import validate_device
from model import Cancelled, Model
from server import State, create_app
from workspace import Workspace, project_name


class FakeModel:
    def __init__(self, actions, cancel=None):
        self.actions = iter(actions)
        self.cancel = cancel or threading.Event()
        self.contexts = []
        self.closed = False

    def health(self):
        return {'ready': True, 'model': 'test-model'}

    def fit(self, system, goal, context):
        self.contexts.append(context)
        return []

    def complete(self, messages, progress, structured=True):
        if self.cancel.is_set():
            raise Cancelled()
        value = next(self.actions)
        if isinstance(value, Exception):
            raise value
        progress(json.dumps(value), 1)
        return value

    def abort(self):
        self.cancel.set()

    def close(self):
        self.closed = True


class TempCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.ws = Workspace(self.root / 'Desktop', 'Game', self.root / 'backups')
        self.device = {'id': 'test', 'name': 'Pocket Llama'}

    def tearDown(self):
        self.tmp.cleanup()

    def job(self, **kw):
        return Job(self.root / 'jobs', self.ws, 'Make a game', self.device, **kw)


class WorkspaceTests(TempCase):
    def test_escape_windows_paths_and_devices_rejected(self):
        for name in ('../secret.txt', '/secret.txt', 'C:\\secret.txt', '\\\\server\\share.txt',
                     'file.txt:stream', 'CON.txt', 'aux.js', 'x/../y.js', '.private.txt', 'x./y.js'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                self.ws.write(name, 'bad')
        self.assertFalse((self.root / 'secret.txt').exists())

    def test_link_and_hardlink_escape_rejected(self):
        outside = self.root / 'outside'
        outside.mkdir()
        (outside / 'x.txt').write_text('keep')
        try:
            (self.ws.root / 'link').symlink_to(outside, target_is_directory=True)
        except OSError:
            self.skipTest('Creating symlinks is unavailable for this user.')
        with self.assertRaises(ValueError):
            self.ws.write('link/x.txt', 'bad')
        os.link(outside / 'x.txt', self.ws.root / 'hard.txt')
        with self.assertRaises(ValueError):
            self.ws.write('hard.txt', 'bad')
        self.assertEqual((outside / 'x.txt').read_text(), 'keep')

    def test_backup_before_overwrite_and_append(self):
        self.ws.write('src/game.js', 'const x=1;')
        self.ws.write('src/game.js', 'const x=2;')
        backups=list((self.root / 'backups').glob('*/src/game.js'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_text(), 'const x=1;')

    def test_syntax_check_does_not_execute_python(self):
        marker = self.root / 'should-not-exist'
        self.ws.write('game.py', f'open({str(marker)!r}, "w").write("executed")')
        self.assertEqual(self.ws.check('game.py')['status'], 'checked')
        self.assertFalse(marker.exists())
        self.ws.write('game.py', 'print(')
        self.assertEqual(self.ws.check('game.py')['status'], 'failed')

    def test_html_checks_inline_js_and_missing_dependencies(self):
        self.ws.write('index.html', '<html><script>const a = ;</script></html>')
        with patch('workspace.shutil.which', return_value=None):
            result=self.ws.check('index.html')
        self.assertTrue(any(c['status']=='skipped' for c in result['checks']))
        self.ws.write('index.html', '<html><script src="missing.js"></script></html>')
        self.assertEqual(self.ws.check('index.html')['status'], 'failed')

    def test_live_js_syntax_check(self):
        import shutil
        if not shutil.which('node'):
            self.skipTest('Node.js is not installed')
        self.ws.write('index.html', '<html><script>const a = ;</script></html>')
        self.assertEqual(self.ws.check('index.html')['status'], 'failed')
        self.ws.write('index.html', '<html><script>const a = 1;</script></html>')
        self.assertEqual(self.ws.check('index.html')['status'], 'checked')


class AgentTests(TempCase):
    def test_write_check_failure_repair_and_finish(self):
        model = FakeModel([
            {'action':'write_file', 'path':'game.py', 'content':'print(', 'message':'Write'},
            {'action':'check_file', 'path':'game.py', 'message':'Check'},
            {'action':'write_file', 'path':'game.py', 'content':'print("game")', 'message':'Repair'},
            {'action':'check_file', 'path':'game.py', 'message':'Check again'},
            {'action':'finish', 'message':'Ready for review'}])
        job=self.job();job.run(model)
        self.assertEqual(job.state['status'], 'review')
        self.assertEqual(self.ws.read('game.py'), 'print("game")')
        self.assertIn('failed', model.contexts[2])
        self.assertTrue(model.closed)

    def test_cannot_finish_with_unchecked_changes(self):
        job=self.job()
        job.tool({'action':'write_file','path':'x.py','content':'x=1'})
        with self.assertRaisesRegex(ValueError, 'Check or fix'):
            job.tool({'action':'finish'})
        job.tool({'action':'check_file','path':'x.py'})
        job.tool({'action':'append_file','path':'x.py','content':'\ny=2'})
        with self.assertRaisesRegex(ValueError, 'Check or fix'):
            job.tool({'action':'finish'})

    def test_cancel_blocks_later_file_write(self):
        job=self.job();job.stop()
        with self.assertRaises(Cancelled):
            job.tool({'action':'write_file','path':'x.txt','content':'no'})
        self.assertFalse((self.ws.root/'x.txt').exists())

    def test_partial_action_and_path_escape_never_write(self):
        model=FakeModel([ValueError('Incomplete output'),
                         {'action':'write_file','path':'../secret.txt','content':'bad','message':'write'}])
        job=self.job(max_steps=2);job.run(model)
        self.assertEqual(job.state['status'],'incomplete')
        self.assertEqual(self.ws.files(),[])

    def test_chat_does_not_call_tools(self):
        model=FakeModel(['Hello.'])
        job=self.job(mode='chat');job.run(model)
        self.assertEqual(job.state['status'],'done')
        self.assertEqual(self.ws.files(),[])


def sse_response(value, reason='stop'):
    text=json.dumps(value)
    lines=[]
    for chunk in (text[:12],text[12:]):
        lines.append('data: '+json.dumps({'choices':[{'delta':{'content':chunk},'finish_reason':None}]})+'\n\n')
    lines.append('data: '+json.dumps({'choices':[{'delta':{},'finish_reason':reason}]})+'\n\n')
    lines.append('data: [DONE]\n\n')
    return httpx.Response(200,content=''.join(lines),headers={'content-type':'text/event-stream'})


class ModelTests(unittest.TestCase):
    def model(self, handler):
        model=Model(12345)
        model.http.close()
        model.http=httpx.Client(transport=httpx.MockTransport(handler),base_url=model.base)
        self.addCleanup(model.close)
        return model

    def test_structured_stream_uses_schema_and_reports_progress(self):
        def handler(req):
            body=json.loads(req.content)
            self.assertIn('schema',body['response_format'])
            self.assertFalse(body['chat_template_kwargs']['enable_thinking'])
            return sse_response({'action':'finish','message':'Hello'})
        model=self.model(handler);updates=[]
        value=model.complete([],lambda *v:updates.append(v))
        self.assertEqual(value['action'],'finish');self.assertTrue(updates)

    def test_truncated_and_disconnected_output_rejected(self):
        for reason in ('length',None):
            model=self.model(lambda req: sse_response({'action':'write_file','path':'x.py','content':'x=1','message':'write'},reason))
            with self.assertRaisesRegex(ValueError,'incomplete'):
                model.complete([],lambda *v:None)

    def test_invalid_action_rejected(self):
        model=self.model(lambda req:sse_response({'action':'run_shell','message':'no'}))
        from jsonschema import ValidationError
        with self.assertRaises(ValidationError):model.complete([],lambda *v:None)

    def test_context_trimming_terminates_and_preserves_goal(self):
        model=self.model(lambda req:httpx.Response(200,json={}))
        seen=[]
        def count(messages):
            seen.append(messages)
            return len(messages[1]['content'])
        model.count=count;model.max_tokens=100;model.context=450
        fitted=model.fit('system','KEEP GOAL','x'*10000)
        self.assertIn('KEEP GOAL',fitted[1]['content']);self.assertLess(len(seen),20)
        model.context=100
        with self.assertRaises(ValueError):model.fit('system','still too large','x'*1000)

    def test_cancelled_request_rejects_action(self):
        model=self.model(lambda req:sse_response({'action':'finish','message':'Hello'}))
        model.cancel.set()
        with self.assertRaises(Cancelled):model.complete([],lambda *v:None)


class ServerTests(TempCase):
    def setUp(self):
        super().setUp()
        self.state=State(self.root/'data',self.root/'Desktop')
        self.app=create_app(self.state);self.client=self.app.test_client()
        self.headers={'Host':'127.0.0.1:8877','X-Node-Token':self.state.token}

    def test_reject_cross_origin_bad_host_missing_token(self):
        self.assertEqual(self.client.get('/api/state',headers={'Host':'127.0.0.1:8877'}).status_code,403)
        self.assertEqual(self.client.get('/api/state',headers={**self.headers,'Origin':'https://evil.test'}).status_code,403)
        self.assertEqual(self.client.get('/',headers={'Host':'evil.test:8877'}).status_code,403)
        self.assertEqual(self.client.get('/api/state',headers=self.headers).status_code,200)

    def test_task_api_drives_files_and_persists_log(self):
        device=self.state.devices[0]
        self.state.connections.port=lambda _:12345
        self.state.model_factory=lambda port,cancel=None:FakeModel([
            {'action':'write_file','path':'note.txt','content':'Made on the PC','message':'write'},
            {'action':'check_file','path':'note.txt','message':'check'},
            {'action':'finish','message':'Ready'}],cancel)
        response=self.client.post('/api/jobs',headers=self.headers,json={'prompt':'Write a note','device':device['id'],'project':'My Project','mode':'build','keep_history':True})
        self.assertEqual(response.status_code,200)
        self.state.thread.join(5)
        value=self.client.get('/api/jobs/'+response.json['id'],headers=self.headers).json
        self.assertEqual(value['status'],'review')
        self.assertEqual((self.root/'Desktop'/'My Project'/'note.txt').read_text(),'Made on the PC')
        self.assertTrue(list((self.root/'data'/'jobs').glob('*.json')))

    def test_single_task_and_disconnect_lock(self):
        self.state.thread=type('Busy',(),{'is_alive':lambda _:True})()
        device=self.state.devices[0]
        value=self.client.post('/api/jobs',headers=self.headers,json={'prompt':'Make','device':device['id'],'project':'My Project'})
        self.assertEqual(value.status_code,400)
        self.assertEqual(self.client.post('/api/devices/'+device['id']+'/disconnect',headers=self.headers,json={}).status_code,400)

    def test_ssh_argument_injection_rejected(self):
        for host in ('-oProxyCommand=bad', 'host;bad', '$(bad)', 'host/other'):
            with self.assertRaises(ValueError):validate_device({'name':'Pi','host':host,'user':'pocket'})


if __name__=='__main__':
    unittest.main()
