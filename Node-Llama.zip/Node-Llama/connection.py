"""Windows OpenSSH owns encryption, credentials and host verification."""
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import threading
import time
import uuid
import ipaddress


def lan_address(host):
    allowed = [ipaddress.ip_network(n) for n in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16',
                '169.254.0.0/16', 'fc00::/7', 'fe80::/10')]
    entries = socket.getaddrinfo(host, 22, type=socket.SOCK_STREAM)
    # Prefer IPv4 on typical Pi LANs. Pass the validated address to SSH, not a
    # hostname that could resolve differently on a second lookup.
    for family, _, _, _, addr in sorted(entries, key=lambda item: item[0] != socket.AF_INET):
        ip = ipaddress.ip_address(addr[0].split('%')[0])
        if any(ip.version == network.version and ip in network for network in allowed):
            if family == socket.AF_INET6 and addr[3]:
                return addr[0].split('%')[0] + '%' + str(addr[3])
            return addr[0]
    raise ValueError('This build connects only to a private or link-local LAN address. Use the Pi address from hostname -I.')


def validate_device(data):
    name, host, user = (data.get(k, '').strip() for k in ('name', 'host', 'user'))
    if not name or len(name) > 60:
        raise ValueError('Give the device a short name.')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]{0,252}', host) or '..' in host:
        raise ValueError('Enter the Pi IPv4 address or hostname, such as pocketllama.local.')
    if not re.fullmatch(r'[a-zA-Z_][a-zA-Z0-9_-]{0,31}', user):
        raise ValueError('Enter the Pi login name, usually pocket.')
    return {'id': uuid.uuid4().hex, 'name': name, 'host': host, 'user': user}


class Connections:
    def __init__(self):
        self.lock = threading.RLock()
        self.tunnels = {}

    def connect(self, device):
        with self.lock:
            old = self.tunnels.get(device['id'])
            if old and old['process'].poll() is None:
                return old['port']
            ssh = shutil.which('ssh')
            if not ssh:
                raise ValueError('Install the Windows OpenSSH Client in Optional features, then restart Node Llama.')
            if os.name != 'nt':
                raise ValueError('The Connect button is for Windows. See README for a manual SSH tunnel on other systems.')
            address = lan_address(device['host'])
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', 0))
                port = sock.getsockname()[1]
            args = [ssh, '-N', '-T', '-o', 'ExitOnForwardFailure=yes', '-o', 'ConnectTimeout=15',
                    '-o', 'ServerAliveInterval=30', '-o', 'ServerAliveCountMax=3',
                    '-o', 'StrictHostKeyChecking=ask', '-o', 'ControlMaster=no',
                    '-o', f"HostKeyAlias={device['host']}", '-o', 'ProxyCommand=none',
                    '-o', 'ProxyJump=none', '-o', 'PermitLocalCommand=no',
                    '-L', f'127.0.0.1:{port}:127.0.0.1:8080', f"{device['user']}@{address}"]
            process = subprocess.Popen(args, creationflags=subprocess.CREATE_NEW_CONSOLE, shell=False)
            self.tunnels[device['id']] = {'process': process, 'port': port, 'started': time.monotonic()}
            return port

    def connect_paired(self, device, key_path, data_root):
        """No prompt: dedicated key + host key received in authenticated pairing."""
        from node_protocol import ssh_key
        with self.lock:
            self.disconnect(device['id'])
            ssh = shutil.which('ssh')
            if not ssh:
                raise ValueError('Enable the Windows OpenSSH Client in Optional features.')
            address = lan_address(device['host'])
            alias = 'pocket-' + device['id']
            known = Path(data_root) / (device['id'] + '.known_hosts')
            known.write_text(alias + ' ' + ssh_key(device['hostkey']) + '\n', encoding='ascii')
            with socket.socket() as sock:
                sock.bind(('127.0.0.1', 0))
                port = sock.getsockname()[1]
            log_path = Path(data_root) / (device['id'] + '.ssh.log')
            args = [ssh, '-F', os.devnull, '-N', '-T', '-i', str(key_path),
                    '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes',
                    '-o', 'PasswordAuthentication=no', '-o', 'KbdInteractiveAuthentication=no',
                    '-o', 'StrictHostKeyChecking=yes', '-o', 'UpdateHostKeys=no',
                    '-o', 'UserKnownHostsFile="' + str(known).replace('\\','/') + '"',
                    '-o', 'GlobalKnownHostsFile=' + os.devnull, '-o', 'HostKeyAlias=' + alias,
                    '-o', 'ExitOnForwardFailure=yes', '-o', 'ConnectTimeout=6',
                    '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=2',
                    '-L', f'127.0.0.1:{port}:127.0.0.1:8080', f"{device['user']}@{address}"]
            with log_path.open('wb') as log:
                process = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                    stderr=log, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), shell=False)
            self.tunnels[device['id']] = {'process': process, 'port': port, 'started': time.monotonic()}
            deadline = time.monotonic() + 8
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    message = log_path.read_text(errors='replace')[-700:]
                    raise ValueError('Automatic SSH connection failed: ' + message)
                try:
                    with socket.create_connection(('127.0.0.1', port), timeout=.2):
                        return port
                except OSError:
                    time.sleep(.1)
            self.disconnect(device['id'])
            raise ValueError('The Pi did not accept the connection. Check SSH is enabled and both devices are on the same LAN.')

    def port(self, device_id):
        with self.lock:
            item = self.tunnels.get(device_id)
            if not item or item['process'].poll() is not None:
                raise ValueError('Connect this device first. Complete login in the SSH window.')
            return item['port']

    def disconnect(self, device_id):
        with self.lock:
            item = self.tunnels.pop(device_id, None)
            if item and item['process'].poll() is None:
                item['process'].terminate()
                try:
                    item['process'].wait(timeout=3)
                except subprocess.TimeoutExpired:
                    item['process'].kill()

    def close(self):
        for device_id in list(self.tunnels):
            self.disconnect(device_id)
