import contextlib
import json
from pathlib import Path
import secrets
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

if not (Path(__file__).resolve().parents[1]/'Pocket-Llama'/'node_link.py').exists():
    raise unittest.SkipTest('Extract both app folders side by side for cross-app pairing tests.')
sys.path.append(str(Path(__file__).resolve().parents[1]/'Pocket-Llama'))
from node_link import NodeLink
from node_protocol import connection_command, wake_text, local_ip
from pairing import Pairing


class FakeConnections:
    def __init__(self):self.connected=[];self.disconnected=[]
    def connect_paired(self,device,*args):self.connected.append(dict(device))
    def port(self,key):return 8080
    def disconnect(self,key):self.disconnected.append(key)

class FakeModel:
    def __init__(self,*a):pass
    def health(self):return {'ready':True,'model':'test-model','message':'Connected · model ready'}
    def close(self):pass

class FakeState:
    def __init__(self,root):
        self.data=Path(root);self.lock=threading.RLock();self.devices=[];self.device_status={}
        self.connections=FakeConnections();self.model_factory=FakeModel
    def busy(self):return False
    def save_devices(self):pass


class PairingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.state=FakeState(self.root/'node')
        self.server=Pairing(self.state,port=0,allow_loopback=True)
        self.server.start()
        self.events=[]
        self.client=NodeLink(self.root/'pocket',self.events.append,allow_loopback=True)
        self.node={'id':self.server.config['id'],'name':'Test computer','host':'127.0.0.1','port':self.server.port}
        self.host=patch.object(self.client,'host_key',return_value=self.server.ssh_public)
        self.user=patch('node_link.getpass.getuser',return_value='pocket')
        self.host.start();self.user.start()
    def tearDown(self):
        self.host.stop();self.user.stop();self.server.close();self.temp.cleanup()
    def pair(self):
        code=self.server.open_pairing()['code']
        return self.client.pair(code,self.node)

    def test_pair_reconnect_disconnect_and_restart(self):
        self.pair()
        self.assertIn(self.client.data['pi_id'],self.server.config['peers'])
        self.assertFalse(self.server.snapshot()['code'])
        line=(self.client.root/'authorized_keys').read_text()
        self.assertIn('permitopen="127.0.0.1:8080"',line)
        self.assertIn('command="/bin/false"',line)
        self.assertNotIn(self.client.data['nodes'][self.node['id']]['token'],json.dumps(self.server.config))
        restarted=NodeLink(self.client.root,allow_loopback=True)
        restarted._connect(self.node)
        self.assertEqual(len(self.state.connections.connected),2)
        restarted.disconnect()
        self.assertIn('paired-'+self.client.data['pi_id'],self.state.connections.disconnected)
        self.client.forget_all()
        self.assertEqual((self.client.root/'authorized_keys').read_text().strip(),'')

    def test_wrong_code_never_authorizes_key_and_locks_after_five(self):
        code=self.server.open_pairing()['code']
        wrong='000000' if code!='000000' else '111111'
        for _ in range(5):
            with self.assertRaises(ValueError):self.client.pair(wrong,self.node)
        self.assertFalse((self.client.root/'authorized_keys').exists())
        self.assertFalse(self.server.config['peers'])
        with self.assertRaisesRegex(ValueError,'PAIR POCKET'):
            self.client.pair(code,self.node)

    def test_pinned_certificate_checked_before_sending_credential(self):
        self.pair()
        saved=self.client.data['nodes'][self.node['id']]
        saved['fingerprint']='0'*64
        with self.assertRaisesRegex(ValueError,'identity changed'):
            self.client._connect(self.node)
        self.assertEqual(len(self.state.connections.connected),1)

    def test_revocation_blocks_reconnect(self):
        self.pair()
        self.server.forget(self.client.data['pi_id'])
        with self.assertRaisesRegex(ValueError,'forgot the pairing'):
            self.client._connect(self.node)

    def test_expired_code_rejected(self):
        code=self.server.open_pairing()['code'];self.server.expires=0
        with self.assertRaises(ValueError):self.client.pair(code,self.node)
        self.assertFalse(self.server.config['peers'])

    def test_selection_remembers_computer_and_does_not_infer_distance(self):
        a={**self.node,'paired':False};b={**a,'id':'b'*32,'name':'Another'}
        with patch.object(self.client,'discover',return_value=[a,b]):
            self.client.begin()
        self.assertEqual(self.events[-1]['mode'],'choose')
        self.client.data['preferred']=b['id']
        a['paired']=True;b['paired']=True
        with patch.object(self.client,'discover',return_value=[a,b]),patch.object(self.client,'_connect') as connect:
            self.client.begin();connect.assert_called_once_with(b)

    def test_wake_phrase_is_leading_and_commands_are_exact(self):
        self.assertEqual(wake_text('Llama, connect to Node.'),'connect to Node.')
        self.assertEqual(wake_text('Hey llama! Connect to Node'),'Connect to Node')
        self.assertEqual(wake_text('Llama.'),'')
        self.assertIsNone(wake_text('Explain how llama connect to node works'))
        self.assertIsNone(wake_text('llamazing'))
        self.assertEqual(connection_command('Connect to Node!'),'connect')
        self.assertIsNone(connection_command('Explain connect to node'))
        self.assertEqual(connection_command('Disconnect from Node.'),'disconnect')

    def test_public_and_loopback_are_not_lan_targets(self):
        self.assertTrue(local_ip('192.168.1.5'))
        self.assertFalse(local_ip('8.8.8.8'))
        self.assertFalse(local_ip('127.0.0.1'))
        self.assertFalse(local_ip('evil.example'))

if __name__=='__main__':unittest.main()
