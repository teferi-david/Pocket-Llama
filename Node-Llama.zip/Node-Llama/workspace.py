"""Project-scoped text tools. Generated programs are never executed by these tools."""
import ast
import ctypes
from ctypes import wintypes
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import uuid

MAX_FILE = 256_000
MAX_PROJECT = 5_000_000
EXTENSIONS = {'.html', '.htm', '.css', '.js', '.mjs', '.json', '.py', '.txt', '.md', '.csv'}
RESERVED = {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(10)), *(f'LPT{i}' for i in range(10))}


def desktop():
    if os.name != 'nt':
        return Path.home() / 'Desktop'
    # Ask Windows for the real Desktop, including redirected/OneDrive Desktops.
    class GUID(ctypes.Structure):
        _fields_ = [('data', ctypes.c_ubyte * 16)]
    guid = GUID.from_buffer_copy(uuid.UUID('B4BFCC3A-DB2C-424C-B029-7FE99A87C641').bytes_le)
    value = ctypes.c_void_p()
    fn = ctypes.windll.shell32.SHGetKnownFolderPath
    fn.argtypes = [ctypes.POINTER(GUID), wintypes.DWORD, wintypes.HANDLE, ctypes.POINTER(ctypes.c_void_p)]
    fn.restype = ctypes.c_long
    result = fn(ctypes.byref(guid), 0, None, ctypes.byref(value))
    if result != 0:
        raise OSError('Windows could not resolve your Desktop folder.')
    try:
        return Path(ctypes.wstring_at(value))
    finally:
        ctypes.windll.ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        ctypes.windll.ole32.CoTaskMemFree(value)


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        temp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def is_link(path):
    if not path.exists() and not path.is_symlink():
        return False
    info = path.lstat()
    # Name-surrogate reparse points include junctions; ordinary OneDrive hydration
    # tags are not directory redirections and may remain usable.
    return path.is_symlink() or bool(getattr(info, 'st_reparse_tag', 0) & 0x20000000)


def project_name(name):
    if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _-]{0,59}', name):
        raise ValueError('Use 1–60 letters, numbers, spaces, hyphens or underscores for the project name.')
    if name != name.rstrip() or name.upper() in RESERVED:
        raise ValueError('Choose a different project name.')
    return name


class Scripts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.scripts, self.refs, self.current = [], [], None
        self.canvas = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'canvas':
            self.canvas = True
        if tag == 'script':
            if attrs.get('src'):
                self.refs.append(attrs['src'])
            elif attrs.get('type', '').lower() in ('', 'module', 'text/javascript', 'application/javascript'):
                self.current = []
        if tag == 'link' and attrs.get('href') and 'stylesheet' in attrs.get('rel', ''):
            self.refs.append(attrs['href'])

    def handle_data(self, data):
        if self.current is not None:
            self.current.append(data)

    def handle_endtag(self, tag):
        if tag == 'script' and self.current is not None:
            self.scripts.append(''.join(self.current))
            self.current = None


class Workspace:
    def __init__(self, base, name, history):
        self.base = Path(base).resolve()
        self.root = self.base / project_name(name)
        if is_link(self.root):
            raise ValueError('Project folders cannot be symbolic links or junctions.')
        self.root.mkdir(parents=True, exist_ok=True)
        self.history = Path(history)

    def path(self, name):
        if not isinstance(name, str) or len(name) > 180:
            raise ValueError('Invalid project-relative path.')
        parts = name.replace('\\', '/').split('/')
        for part in parts:
            if (not part or part in ('.', '..') or part.startswith('.') or part.endswith((' ', '.'))
                    or re.search(r'[<>:"|?*\x00-\x1f]', part) or part.split('.')[0].upper() in RESERVED):
                raise ValueError('Use an ordinary relative path inside the selected project.')
        if Path(parts[-1]).suffix.lower() not in EXTENSIONS:
            raise ValueError('Supported files: HTML, CSS, JS, JSON, Python, text, Markdown and CSV.')
        current = self.root
        if is_link(current):
            raise ValueError('Project folder changed to a link.')
        for part in parts:
            current = current / part
            if is_link(current):
                raise ValueError('Links and junctions are not allowed in project paths.')
        current.resolve().relative_to(self.root.resolve())
        if current.exists() and current.is_file() and current.stat().st_nlink > 1:
            raise ValueError('Hard-linked files are not supported.')
        return current

    def files(self):
        rows = []
        for parent, dirs, files in os.walk(self.root, followlinks=False):
            dirs[:] = sorted(d for d in dirs if not d.startswith('.') and not is_link(Path(parent) / d))
            for filename in sorted(files):
                p = Path(parent) / filename
                if filename.startswith('.') or is_link(p) or p.suffix.lower() not in EXTENSIONS:
                    continue
                rows.append({'path': p.relative_to(self.root).as_posix(), 'bytes': p.stat().st_size})
                if len(rows) > 200:
                    raise ValueError('Project exceeds the 200-file limit.')
        return rows

    def read(self, name):
        path = self.path(name)
        if path.stat().st_size > MAX_FILE:
            raise ValueError('File exceeds the 256 KB limit.')
        return path.read_text(encoding='utf-8')

    def write(self, name, content):
        if not isinstance(content, str) or len(content.encode('utf-8')) > MAX_FILE:
            raise ValueError('File exceeds the 256 KB limit.')
        path = self.path(name)
        rows = self.files()
        old_size = path.stat().st_size if path.exists() else 0
        if (sum(f['bytes'] for f in rows) - old_size + len(content.encode('utf-8')) > MAX_PROJECT
                or (not path.exists() and len(rows) >= 200)):
            raise ValueError('Project exceeds its 5 MB / 200-file limit.')
        if path.exists():
            backup = self.history / uuid.uuid4().hex / name
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, backup)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Same-directory replacement, so readers never see an incomplete write.
        temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
        try:
            temp.write_text(content, encoding='utf-8')
            self.path(name)  # Recheck before replacement.
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)
        return {'written': name, 'bytes': path.stat().st_size}

    @staticmethod
    def check_js(source):
        node = shutil.which('node')
        if not node:
            return {'status': 'skipped', 'detail': 'Node.js is not installed; JavaScript syntax was not checked.'}
        with tempfile.TemporaryDirectory(prefix='node-llama-check-') as folder:
            path = Path(folder) / 'check.mjs'
            path.write_text(source, encoding='utf-8')
            env = dict(os.environ)
            # These variables can preload executable modules even during --check.
            env.pop('NODE_OPTIONS', None)
            env.pop('NODE_PATH', None)
            result = subprocess.run([node, '--check', str(path)], capture_output=True,
                                    text=True, encoding='utf-8', errors='replace', timeout=15,
                                    cwd=folder, env=env, shell=False)
            return {'status': 'passed' if result.returncode == 0 else 'failed',
                    'detail': (result.stderr or 'JavaScript syntax passed.').replace(str(path), 'source')[:2500]}

    def check(self, name):
        text = self.read(name)
        ext = Path(name).suffix.lower()
        checks = []
        try:
            if ext == '.py':
                ast.parse(text, filename=name)
                checks.append({'status': 'passed', 'detail': 'Python syntax passed; program was not executed.'})
            elif ext == '.json':
                json.loads(text)
                checks.append({'status': 'passed', 'detail': 'Valid JSON.'})
            elif ext in ('.js', '.mjs'):
                checks.append(self.check_js(text))
            elif ext in ('.html', '.htm'):
                parser = Scripts()
                parser.feed(text)
                if not re.search(r'</html\s*>', text, flags=re.I) or parser.current is not None:
                    checks.append({'status': 'failed', 'detail': 'HTML appears incomplete: close html and script tags.'})
                else:
                    checks.append({'status': 'passed', 'detail': 'HTML document ending found. This is not full HTML validation.'})
                for script in parser.scripts:
                    checks.append(self.check_js(script))
                for ref in parser.refs:
                    if re.match(r'(?i)^(https?:)?//', ref):
                        checks.append({'status': 'failed', 'detail': f'External dependency {ref}; use offline local files.'})
                    else:
                        rel = (Path(name).parent / ref).as_posix()
                        try:
                            target = self.path(rel)
                            if not target.is_file():
                                raise ValueError('File is missing')
                            if target.suffix.lower() in ('.js', '.mjs'):
                                checks.append(self.check_js(self.read(rel)))
                        except ValueError as exc:
                            checks.append({'status': 'failed', 'detail': f'{ref}: {exc}'})
                checks.append({'status': 'info', 'detail': 'Open the game to test graphics, controls and gameplay; static checks cannot verify those.'})
            else:
                checks.append({'status': 'skipped', 'detail': 'No syntax checker for this file type.'})
        except (SyntaxError, ValueError, subprocess.TimeoutExpired) as exc:
            checks.append({'status': 'failed', 'detail': str(exc)[:2500]})
        return {'file': name, 'status': 'failed' if any(c['status'] == 'failed' for c in checks)
                else 'checked', 'checks': checks}
