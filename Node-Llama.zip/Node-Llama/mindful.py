"""Transparent local pattern matching. No model or remote service is called."""
from collections import Counter
import re

PATTERNS = [
    ('EMAIL', re.compile(r'(?<![\w.+-])[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}(?![\w-])', re.I)),
    ('SSN_PATTERN', re.compile(r'(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)')),
    ('PHONE', re.compile(r'(?<![\w])(?:\+?1[ .-]?)?(?:\(\d{3}\)|\d{3})[ .-]?\d{3}[ .-]?\d{4}(?!\d)')),
    ('LABELED_ID', re.compile(r'\b(?:serial|policy|account)\s*(?:number|no\.?|id)?\s*[:#]\s*[A-Z0-9][A-Z0-9-]{3,}', re.I)),
]


def redact(text):
    counts = Counter()
    def replace(kind):
        def inner(match):
            counts[kind] += 1
            return '[' + kind + '_REDACTED]'
        return inner
    for kind, pattern in PATTERNS:
        text = pattern.sub(replace(kind), text)
    return text, dict(counts)


def guidance(prompt):
    lower = prompt.lower()
    if re.search(r'\b(latest|today.s news|current prices|live prices|browse the web|search the internet)\b', lower):
        return {'label': 'Needs current sources', 'detail': 'This device has no web-search tool. Provide current source text or use a tool with browsing.', 'kind': 'caution'}
    if len(prompt) > 1400 or re.search(r'\b(aaa|full minecraft|3d open.world|full.stack|entire codebase|multiplayer|production.ready)\b', lower):
        return {'label': 'Break this into smaller tasks', 'detail': 'The 2B Pi model is better suited to short drafts and small files. A larger local model would suit this task better; this build does not switch models automatically.', 'kind': 'caution'}
    if re.search(r'\b(diagnos\w*|coverage decision|legal advice|invest\w*|insurance payout)\b', lower):
        return {'label': 'Use it to organize, then verify', 'detail': 'Use this small model for a draft or checklist. Verify consequential conclusions with an appropriate expert or authoritative source.', 'kind': 'caution'}
    return {'label': 'A reasonable local starting point', 'detail': 'Short summaries, drafts and small files suit this setup. Check the result; this is task guidance, not a measured accuracy score.', 'kind': 'normal'}


def inspect(prompt, mask=True):
    cleaned, counts = redact(prompt)
    return {'outbound_prompt': cleaned if mask else prompt, 'findings': counts,
            'matched_count': sum(counts.values()), 'redaction_enabled': bool(mask),
            'guidance': guidance(prompt),
            'limitations': 'Pattern checks can miss sensitive data, including names and street addresses. Review the text before sending.'}
