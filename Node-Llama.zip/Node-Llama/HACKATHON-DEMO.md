# Pocket Llama + Node Llama — Assurant judge demo

## The idea to lead with

**Pocket Llama is AI you own and carry. Node Llama lets it work on your computer
while showing what you share, what the model API costs, and what the device is
suited to do.**

Lead with a private, useful everyday task: documenting a misplaced tablet using
fictional notes. This connects naturally to Assurant's mobile/connected-device
work. The recommendation is based on the challenge text you supplied and
Assurant's public [company overview](https://www.assurant.com/); it is not an
additional judging rule or a promise of a particular score.

Keep Minecraft as an optional after-demo example of file creation. A long live
coding request on the 2B Pi is a poor use of a short judging slot. The core demo
should make the privacy boundary and user controls easy to see.

## What the two products demonstrate

| Challenge need | Pocket Llama / Node Llama demonstration | What is implemented |
|---|---|---|
| Know what data is shared | Review Data masks common identifiers locally and shows the outgoing message and Pi destination | Pattern matching on the Windows PC; masking is also applied to model context |
| Control privacy | Select a personal LAN device; use Chat or project-scoped Build; leave history off; Stop; Forget selected chat | LAN address restriction, SSH, mode separation, opt-in chat persistence, cancellation and record deletion |
| Understand spending | Open the task receipt: cloud AI API $0.00, generation calls, reported token usage | No paid model backend; no surprise switch to one; usage only when the server reports it |
| Choose a suitable tool | Show guidance for a short drafting task, then contrast its requirements with a request for current sources or a large game | Simple rules with explanations, not an AI confidence percentage or measured ranking |
| Trust a connected device | Hold the physical Pi, ask a short spoken question, then select that device in Node Llama | Standalone local voice and a separate Windows agent interface using the same model service |

The challenge says privacy protection, spending visibility **or** tool selection.
Make privacy the clearest story. The receipt and task guidance reinforce it.

## Before judging

1. Install the updated Windows companion, open **DEVICES / CONNECT**, authenticate
   and check the Pi. Resolve the SSH host fingerprint before the presentation.
   Use the Pi's IP if `.local` does not resolve. Keep the SSH window open in the
   background and do not project password entry.
2. Keep the Pi model loaded and the device cool. Test microphone and speaker at
   the actual table; use a short voice question.
3. In Node Llama, click **+** beside the message, set the Desktop project to
   **Device Demo**, select **Build**, keep masking on and saved history off.
4. Keep one successful **real Pi rehearsal** in a separate project such as
   **Device Rehearsal**. You may opt into history for that run so its receipt is
   available as a fallback. Label it as an earlier run when showing it.
5. Rehearse the exact prompts below. Measure spoken response time and the file
   task end-to-end. The previous 4–5 tokens/sec benchmark is not a measured time
   for this new task. Do not promise a particular latency until you test it.
6. Use the fictional identifiers below. Do not put your real policy number,
   password or contact details into the projected demo.
7. Put the Windows browser in full screen with F11. The UI intentionally matches
   your black-and-white reference; the data controls sit below the composer.
8. Confirm the actual event's submission deadline, permitted hardware and demo
   duration separately. This guide assumes a three-minute judging slot; those
   logistics were not supplied or verified here.

### Showing offline operation honestly

A local network can exist without internet access. If you have a private router,
keep its Wi-Fi/LAN up and disconnect its WAN/internet connection. Connect both
Windows and the Pi to that LAN, use the Pi IP, and verify both demos still work
before judges arrive. Preload all models, voices and dependencies first.

Do **not** turn off the Pi's Wi-Fi during the Node Llama task unless it has another
working LAN link. The PC still needs to communicate with the Pi. Do not disconnect
an event-owned router or change other people's network settings.

If you cannot set up a verified isolated LAN, demonstrate the live LAN workflow
and describe its local model architecture. Do not call it an air-gap test or claim
that a privacy badge alone proves zero network traffic. You can separately show
standalone Pocket Llama with its networking off, then restore the LAN connection
before the Node demonstration; budget time for that transition.

## Three-minute run of show

These are stage targets, not guaranteed generation timings. Wait for Pocket Llama
speech to finish before starting the Node task: the current Pi has one model slot.

| Time | Action | Suggested words | Visible proof |
|---|---|---|---|
| 0:00–0:20 | Hold Pocket Llama and show Node Llama | “Most AI tools ask us to send first and understand later. We wanted the user to see the destination, the cost and the limits before sending.” | Physical device and matching desktop UI |
| 0:20–0:50 | Tap Pocket Llama, ask the short question below, hold to send | “This is a local voice assistant. The model, transcription and speech run on the device.” Say internet is disconnected only if verified. | Spoken answer from the handheld |
| 0:50–1:15 | In Node Llama, select Pocket Llama, paste the fictional notes and open REVIEW DATA | “The PC catches these common identifiers before the Pi receives the request. I can inspect the result and choose what to share. Names and addresses still require my review.” | Three supported patterns masked; destination shown |
| 1:15–2:10 | Close Review and Send in BUILD mode. Explain controls while it generates | “The model runs on the Pi. Windows can write only inside this selected project. There is no cloud-model fallback. I can stop the task, and chat history is off.” | Real action log, elapsed time, file list |
| 2:10–2:35 | Open FILES, show device-notes.md, then API $0.00 / RECEIPT | “Here is the file created on this PC, and here is its receipt. Zero cloud API cost; hardware and electricity still have a cost.” | Actual output, model destination, reported usage and file actions |
| 2:35–2:50 | Show PRIVATE BY DESIGN → FORGET SELECTED CHAT | “I can remove Node Llama's chat record. It tells me precisely what remains: the file, backups and possibly the Pi's prompt cache.” | Chat disappears; generated file stays |
| 2:50–3:00 | Type “Create a full Minecraft game” without sending; show guidance | “This small model isn't the best tool for everything. The app makes that limit visible instead of automatically spending money elsewhere.” | Guidance to split the task/use a stronger model |

If your measured voice answer or file task needs longer, use a four- or five-minute
slot if allowed, shorten the output, or use the fallback below. Do not rush over the
privacy preview; it is the key user-control moment.

## Exact Pocket Llama voice prompt

Say:

> I misplaced my tablet at a cafe. What three facts should I write down? Answer in
> under thirty words.

Use the existing controls: tap to listen, speak, then hold and release to send.
This request is conversational. It does not make the handheld operate the PC.

The content of the answer can vary. Check that it is sensible during rehearsal;
do not use it as a source of insurance coverage or entitlement advice.

## Exact Node Llama prompt

Paste this, open **REVIEW DATA**, then send in **BUILD** mode:

> Fictional demo. Email: jordan@example.com. Phone: 305-555-0142. Serial: DEMO-1234.
> I misplaced my tablet at a cafe on September 26. Create device-notes.md with
> three factual bullet points and two follow-up questions. Use placeholders for
> identifiers and do not invent details. Keep it under 60 words. Check the file.

The preview should replace the three example identifiers with `[EMAIL_REDACTED]`,
`[PHONE_REDACTED]` and `[LABELED_ID_REDACTED]`. The fictional email/phone/serial should
not appear in the outgoing prompt preview. If they do, fix the issue before
presenting a privacy claim.

The artifact should be in:

```text
Your actual Desktop\Node Llama Projects\Device Demo\device-notes.md
```

A Markdown check has no dedicated syntax checker and can report **skipped**. Say
“the file was created and inspected” rather than “all tests passed.” The model's
check results and receipt show the actual status.

For an even shorter live task, use:

> Create device-notes.txt containing exactly these two lines: “Tablet misplaced
> at a cafe.” and “Date: September 26.” Check the file, then finish.

You can still demonstrate local masking first with the longer message, but explain
if you switch to the shorter task for time. Do not represent the shorter output as
the result of a different request.

## A reliable fallback

If the current live file request has not completed within the time you rehearsed:

1. Leave its real progress visible briefly or press Stop.
2. Say: “This is running on a small Pi, so generation can take time. This next file
   and receipt are from an earlier successful run on the same device.”
3. Open **Device Rehearsal**, its actual output and saved receipt, or play a short
   recording you made of that real run.
4. Continue the privacy and cost explanation using the real recorded results.

Do not substitute the developer's simulated model tests, invented token counts,
a mocked response or a staged loading sequence for live inference. The packaged
validation tests prove harness behavior; they do not prove the 2B model's skill.

## Short pitch

“Pocket Llama is an AI assistant you can own and carry. Node Llama connects that
assistant to your computer. Before a request leaves the PC, you can inspect what
will be shared and mask common identifiers. Afterward, you can see where it ran,
what the cloud API cost was, and what files changed. We make the privacy boundary,
spending and model limitations visible, so using AI is a choice people understand.”

## Likely judge questions

**What leaves the PC?**
The task text, model instructions, project filenames and requested excerpts travel
to the selected Pi over SSH. Responses return to the PC. This build has no cloud
model backend. Other applications and OS sync are outside its control.

**Is “private” the same as “no data stored anywhere”?**
No. History can be saved locally if selected. Generated files and backups remain
on the PC; the Pi may keep a prompt cache. We show those boundaries and let the
user forget the Node Llama chat record. We do not claim secure erasure or a privacy
certification.

**Is it free?**
There is no cloud-model API bill in this configuration. Hardware, electricity,
maintenance and any unrelated subscriptions still cost money. The receipt is not
a tracker for spending in other apps.

**Does the redaction catch everything?**
No. It is inspectable pattern matching for a small set of identifiers. The preview
makes its result visible, and the user can edit the message. Names, addresses,
secrets and unusual formats can be missed. This is a useful control, not a promise
of complete anonymization.

**How does it pick the right model?**
The user selects a connected device. Simple local task rules explain when the
current 2B model may be insufficient. It does not benchmark/rank all models or
silently route to a cloud provider. A stronger local-PC backend is a future option,
not a feature to claim in this build.

**Why a separate Pi if a PC can run a stronger model?**
The Pi provides a portable voice assistant and a personal compute node that can
be used with the companion app. A powerful PC can be faster and support better
models. This prototype emphasizes ownership, portability and visible control,
not superior performance over a GPU workstation.

**Why does this fit Assurant?**
The device-notes scenario uses a connected device and a familiar moment when a
person might paste personal information into AI. The demo turns that into an
explicit choice with an inspectable data route, understandable cost and limited
actions. It does not make insurance decisions or integrate with Assurant systems.

**What is actually built, and what is future work?**
Built: local voice on the existing Pi app; Windows companion; SSH device selection;
project-file agent loop; data preview; pattern masking; history controls; action
receipt; reported token counts; task guidance. Future: stronger model backends,
comprehensive sensitive-data detection, measured model selection, full Windows
control and cross-provider billing.

## Claims to keep precise

| Use this | Avoid this claim |
|---|---|
| “This app sends model requests to my selected Pi over the LAN.” | “Nothing leaves this computer.” |
| “No cloud AI provider is configured.” | “Nothing on the PC ever contacts the internet.” |
| “Cloud AI API cost is zero; hardware and electricity are separate.” | “The entire system costs nothing.” |
| “The app masks these supported patterns; review the rest.” | “All personal data is removed.” |
| “Forget removes this app's task record.” | “Every copy of the data is permanently destroyed.” |
| “These tokens were reported by the model server.” | “Estimated character counts are measured token usage.” |
| “This small model works best on short, bounded tasks.” | “It is as capable as a frontier coding model.” |
| “Earlier real run” or “simulated developer test,” as applicable | Presenting either as current live inference |

## Last rehearsal checklist

- The real Pi answers the voice prompt clearly.
- The real Pi creates the small Node Llama file at least twice successfully.
- Review Data shows all three fictional identifiers masked.
- The selected model/destination and actual usage availability appear in the receipt.
- The generated file opens from the Windows Desktop project folder.
- Stop prevents later file edits; forgetting a finished chat clears the record.
- You can explain exactly what remains stored and where.
- Your fallback is a labeled recording or saved result from the actual device.
