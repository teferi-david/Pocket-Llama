"""The Pi generates structured actions; the Windows harness interprets them."""
import json
import threading
import time

import httpx
from jsonschema import validate

SCHEMA = {
    'type': 'object',
    'properties': {
        'action': {'type': 'string', 'enum': ['list_files', 'read_file', 'write_file',
                    'append_file', 'replace_text', 'check_file', 'finish']},
        'message': {'type': 'string', 'maxLength': 500},
        'path': {'type': 'string', 'maxLength': 180},
        'content': {'type': 'string', 'maxLength': 16000},
        'old': {'type': 'string', 'maxLength': 8000},
        'start': {'type': 'integer', 'minimum': 1, 'maximum': 100000},
        'count': {'type': 'integer', 'minimum': 1, 'maximum': 80},
    },
    'required': ['action', 'message'], 'additionalProperties': False,
}


class Cancelled(Exception):
    pass


class Model:
    def __init__(self, port, cancel=None, context=4096, max_tokens=1400):
        self.base = f'http://127.0.0.1:{int(port)}'
        self.cancel = cancel or threading.Event()
        self.context = context
        self.max_tokens = max_tokens
        self.model_id = 'pocket-llama'
        self.response = None
        self.on_usage = lambda metrics: None
        self.metrics = {'generation_calls': 0, 'usage_reported_calls': 0, 'input_tokens': 0, 'output_tokens': 0}
        self.lock = threading.Lock()
        self.http = httpx.Client(base_url=self.base, trust_env=False, follow_redirects=False,
                                 timeout=httpx.Timeout(600, connect=5, write=15, pool=5))

    def stopped(self):
        if self.cancel.is_set():
            raise Cancelled()

    def health(self):
        response = self.http.get('/health', timeout=5)
        if response.status_code == 503:
            return {'ready': False, 'message': 'The Pi model is loading. Try Check connection again shortly.'}
        response.raise_for_status()
        models = self.http.get('/v1/models', timeout=5)
        models.raise_for_status()
        entries = models.json().get('data', [])
        if not entries:
            raise ValueError('The model server did not return a model.')
        self.model_id = entries[0]['id']
        return {'ready': True, 'model': self.model_id, 'message': 'Connected · model ready'}

    def count(self, messages):
        self.stopped()
        # Count the actual formatted prompt, not a characters-per-token guess.
        template = self.http.post('/apply-template', json={'messages': messages,
                    'chat_template_kwargs': {'enable_thinking': False}}, timeout=15)
        template.raise_for_status()
        prompt = template.json()['prompt']
        result = self.http.post('/tokenize', json={'content': prompt, 'add_special': True}, timeout=15)
        result.raise_for_status()
        return len(result.json()['tokens'])

    def fit(self, system, goal, context):
        # Goal is never silently discarded. Trim old activity and file excerpts instead.
        full_context = str(context)
        keep = len(full_context)
        while True:
            context = full_context[:keep]
            if keep < len(full_context) and keep:
                context += '\n[Context shortened; use read_file for more.]'
            messages = [{'role': 'system', 'content': system},
                        {'role': 'user', 'content': 'TASK:\n' + goal + '\n\nWORKSPACE STATE:\n' + context}]
            if self.count(messages) + self.max_tokens + 128 <= self.context:
                return messages
            if keep == 0:
                raise ValueError('Task is too long for this model context. Shorten it or split it into smaller tasks.')
            keep = int(keep * .65) if keep > 100 else 0

    def complete(self, messages, progress, structured=True):
        self.stopped()
        body = {'model': self.model_id, 'messages': messages, 'stream': True,
                'stream_options': {'include_usage': True},
                'max_tokens': self.max_tokens, 'temperature': .25, 'top_p': .9,
                'chat_template_kwargs': {'enable_thinking': False}, 'reasoning_effort': 'none',
                'cache_prompt': True}
        if structured:
            body['response_format'] = {'type': 'json_object', 'schema': SCHEMA}
        text, reason, last_tick = '', None, 0
        usage = None
        self.metrics['generation_calls'] += 1
        self.on_usage(dict(self.metrics))
        started = time.monotonic()
        try:
            with self.http.stream('POST', '/v1/chat/completions', json=body) as response:
                with self.lock:
                    self.response = response
                if response.status_code != 200:
                    detail = response.read().decode('utf-8', errors='replace')[:800]
                    raise ValueError(f'Model server HTTP {response.status_code}: {detail}')
                for line in response.iter_lines():
                    self.stopped()
                    if time.monotonic() - started > 1200:
                        raise ValueError('This model step exceeded 20 minutes; try a smaller task.')
                    if not line.startswith('data:'):
                        continue
                    raw = line[5:].strip()
                    if raw == '[DONE]':
                        break
                    event = json.loads(raw)
                    if event.get('error'):
                        raise ValueError(str(event['error']))
                    if event.get('usage'):
                        usage = event['usage']
                    choices = event.get('choices') or []
                    if not choices:
                        continue
                    text += choices[0].get('delta', {}).get('content') or ''
                    reason = choices[0].get('finish_reason') or reason
                    if len(text) > 100000:
                        raise ValueError('Model response is too large.')
                    now = time.monotonic()
                    if now - last_tick > .3:
                        progress(text, now - started)
                        last_tick = now
                self.stopped()
                progress(text, time.monotonic() - started)
        except Exception:
            self.stopped()
            raise
        finally:
            with self.lock:
                self.response = None
            if (isinstance(usage, dict) and isinstance(usage.get('prompt_tokens'), int)
                    and isinstance(usage.get('completion_tokens'), int)):
                self.metrics['usage_reported_calls'] += 1
                self.metrics['input_tokens'] += max(0, usage['prompt_tokens'])
                self.metrics['output_tokens'] += max(0, usage['completion_tokens'])
            self.on_usage(dict(self.metrics))
        if reason != 'stop':
            raise ValueError(f'Model output was incomplete ({reason or "connection ended"}). '
                             'No partial action was applied. Use a smaller file or append_file in short sections.')
        if not text.strip():
            raise ValueError('The model returned no visible text.')
        if structured:
            value = json.loads(text)
            validate(value, SCHEMA)
            return value
        return text

    def abort(self):
        self.cancel.set()
        # Closing the stream also asks llama.cpp to cancel this request. No Pi-wide kill.
        with self.lock:
            response = self.response
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    def close(self):
        self.http.close()
