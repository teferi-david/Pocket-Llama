# Node Llama preview 0.2 validation

Validated on Linux with Python 3.12. No remote access to the user's Pi or Windows
PC was available. Do not interpret these checks as a live device deployment.

## Passed

- 28 automated tests using real temporary files and mocked model output.
- Agent loop: write a file with a syntax error, check it, receive the real error,
  replace the file, check again, then finish. The error is included in the model's
  next prompt.
- Overwrite backups preserve the previous contents; append invalidates prior checks.
- Finish is rejected while changed files are unchecked or failing.
- Cancel prevents subsequent file writes; Chat mode has no file tools.
- Invalid action names, truncated generation and incomplete SSE streams are rejected.
- Windows-style absolute/UNC/traversal/alternate-stream paths and device filenames
  are rejected. Symlink and hard-link escapes are rejected.
- Python syntax checks do not execute generated Python. Actual Node.js syntax
  checks detect and then clear an inline JavaScript error.
- Missing Node.js is reported as a skipped JavaScript check. Missing local HTML
  dependencies fail their check.
- Prompt trimming terminates, retains the user's task and accounts for output space.
- Cross-origin, missing-session-token and invalid Host requests are rejected.
- The API permits one task at a time and prevents disconnecting its device mid-task.
- Device host input cannot inject SSH command-line options or shell syntax.
- Opt-in task logs and generated files persist to their separate directories; history-off records stay in memory.
- Python compile checks and JavaScript syntax check for the companion UI.

## Browser and HTTP integration

Ran the actual Flask/Waitress app in headless Chromium against a local simulated
llama.cpp HTTP server. The simulation supplied responses through the real model
client, including `/health`, `/v1/models`, `/apply-template`, `/tokenize` and
streaming `/v1/chat/completions` endpoints. It did not run an actual language model.

Verified:

- Connect and Check UI flow with a simulated tunnel.
- Task submission through the redesigned chat composer and three successive agent actions.
- Actual disk writes and final review state. The unit suite separately verifies a real syntax failure/repair cycle.
- File list updates and source viewer, with HTML displayed as text.
- Stop during streaming leaves the proposed file unwritten.
- Desktop rendering at 1600 × 1000 and 1280 × 800, and mobile at 390 × 844, without horizontal overflow.
- No JavaScript page errors during the exercised flow.

Additional preview 0.2 checks:

- Local Review Data does not instantiate/contact the model client.
- Email with trailing sentence punctuation, phone, SSN-shaped ID and labeled serial
  patterns are masked; names/addresses are explicitly documented as unsupported.
- Every captured model HTTP payload in the browser demo, including template and
  tokenization requests, excluded the original fictional identifiers.
- Project file excerpts are masked before the next model request.
- History defaults off through the real task API and does not write a task log.
- Forget removes the selected memory/saved record, preserving project files and
  other saved records.
- Receipt token totals come from server-reported usage events. Missing reports
  are not converted from characters or presented as measured usage.
- LAN address resolution accepts private addresses and rejects public/loopback
  destinations. Windows SSH process launch still requires physical-device testing.
- All browser requests during the test were to the companion's localhost origin;
  fonts, scripts and mascot were served locally.

`Node-Llama-Preview.png` shows the actual redesigned initial UI. It does not depict
an authenticated Pi connection or completed live model task.

## Verify on the actual devices

- Windows Python launcher and installer scripts.
- Windows OpenSSH console opening, host fingerprint check, authentication and tunnel cleanup.
- Windows Known Folder resolution on the user's Desktop/OneDrive configuration.
- Explorer and browser launching through Windows file associations.
- Actual Pi JSON grammar support, tokenization, throughput and long-request cancellation.
- The current 2B model's ability to follow the action protocol and create a playable game.
- Wi-Fi disconnect/reconnect behavior and interaction with simultaneous Pi voice requests.

The first real-device acceptance task is the small offline color-button page in
README.md. Start there before asking for a game.


## Voice connection update (preview 0.3)

Both app folders are required side by side for `test_pairing.py`. New tests use
real TLS sockets and simulate the SSH/model endpoint. They exercise pairing code
authentication, wrong/expired codes and attempt limits, certificate pinning,
reconnect, forgetting and deterministic device choice. Voice tests inject audio
and transcripts to check the separate wake phrase and connection command, ignoring
background speech and leaving the idle mic closed when wake is off.

Browser verification includes opening a fresh pairing code and the existing
retro UI/file/receipt checks. The 480×320 keypad, chooser and menu were rendered
for layout inspection. Actual microphone detection, multicast/Windows firewall
and Pi/Windows SSH remain hardware checks. A real SSH daemon test here was blocked
by the execution environment's chroot restriction; it is not counted as passed.

Final suite result: Node Llama 36 tests passed; Pocket Llama 68 tests passed.
JavaScript, shell and Python syntax checks passed.
