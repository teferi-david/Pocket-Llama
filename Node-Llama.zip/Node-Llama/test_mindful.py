import json
import socket
from unittest.mock import patch
import unittest

import httpx
from agent import Job
from connection import lan_address
from mindful import inspect, redact
from test_node import TempCase, FakeModel
from server import State, create_app
from model import Model


class PrivacyTests(TempCase):
    def test_patterns_and_honest_limitations(self):
        source='Jordan lives at 123 Main Street. jordan@example.com 305-555-0142 111-22-3333 Serial: DEMO-1234'
        result=inspect(source)
        self.assertEqual(result['matched_count'],4)
        for raw in ('jordan@example.com','305-555-0142','111-22-3333','DEMO-1234'):
            self.assertNotIn(raw,result['outbound_prompt'])
        self.assertIn('Jordan lives at 123 Main Street',result['outbound_prompt'])
        self.assertIn('names and street addresses',result['limitations'])
        self.assertEqual(inspect(source,False)['outbound_prompt'],source)
        self.assertEqual(redact('Email jordan@example.com. Next sentence.')[0],
                         'Email [EMAIL_REDACTED]. Next sentence.')

    def test_file_excerpts_masked_before_next_model_request(self):
        self.ws.write('contact.txt','Email: jordan@example.com')
        model=FakeModel([{'action':'read_file','path':'contact.txt','message':'Read'},
                         {'action':'write_file','path':'notes.txt','content':'done','message':'Write'}])
        job=Job(self.root/'jobs',self.ws,'Summarize contact.txt',self.device,max_steps=2,mask=True,keep_history=False)
        job.run(model)
        self.assertNotIn('jordan@example.com',model.contexts[1])
        self.assertIn('[EMAIL_REDACTED]',model.contexts[1])
        self.assertFalse(job.path.exists())

    def test_guidance_is_task_specific_without_fake_scores(self):
        for prompt,expected in [('Show today\'s news','Needs current sources'),
                                ('Create a full Minecraft game','Break this into smaller tasks'),
                                ('Summarize my notes','A reasonable local starting point')]:
            result=inspect(prompt)['guidance']
            self.assertEqual(result['label'],expected)
            self.assertNotIn('confidence',result)

    def test_memory_only_and_forget_do_not_delete_files(self):
        state=State(self.root/'data',self.root/'Desktop')
        client=create_app(state).test_client()
        headers={'Host':'127.0.0.1:8877','X-Node-Token':state.token}
        state.connections.port=lambda _:12345
        observed=[]
        def factory(port,cancel=None):
            model=FakeModel(['Hello'],cancel);observed.append(model);return model
        state.model_factory=factory
        data={'prompt':'Email jordan@example.com','project':'My Project','device':state.devices[0]['id'],'mode':'chat'}
        response=client.post('/api/jobs',headers=headers,json=data)
        self.assertEqual(response.status_code,200)
        state.thread.join(3)
        job_id=response.json['id']
        value=state.job(job_id)
        self.assertNotIn('jordan@example.com',value['prompt'])
        self.assertFalse(value['receipt']['history_saved'])
        self.assertFalse(list((state.data/'jobs').glob('*.json')))
        state.workspace('My Project').write('keep.txt','keep this')
        self.assertTrue(client.get('/api/state',headers=headers).json['jobs'])
        forgotten=client.post('/api/jobs/'+job_id+'/forget',headers=headers,json={})
        self.assertEqual(forgotten.status_code,200)
        self.assertFalse(client.get('/api/state',headers=headers).json['jobs'])
        self.assertEqual(state.workspace('My Project').read('keep.txt'),'keep this')

    def test_inspection_never_calls_pi(self):
        state=State(self.root/'data',self.root/'Desktop')
        state.model_factory=lambda *args,**kw:self.fail('Privacy preview contacted model')
        client=create_app(state).test_client()
        headers={'Host':'127.0.0.1:8877','X-Node-Token':state.token}
        result=client.post('/api/inspect',headers=headers,json={'prompt':'Email test@example.com','mask':True})
        self.assertEqual(result.json['outbound_prompt'],'Email [EMAIL_REDACTED]')
        self.assertFalse(list(state.data.glob('jobs/*.json')))

    def test_saved_history_forget_removes_only_requested_record(self):
        state=State(self.root/'data',self.root/'Desktop')
        job=Job(state.data/'jobs',self.ws,'One',self.device)
        job.status('done');state.session_jobs[job.id]=job
        other=Job(state.data/'jobs',self.ws,'Two',self.device);other.status('done')
        client=create_app(state).test_client()
        headers={'Host':'127.0.0.1:8877','X-Node-Token':state.token}
        result=client.post('/api/jobs/'+job.id+'/forget',headers=headers,json={})
        self.assertEqual(result.status_code,200)
        self.assertFalse(job.path.exists());self.assertTrue(other.path.exists())


class RoutingAndUsageTests(unittest.TestCase):
    def test_lan_pins_validated_address_and_rejects_public(self):
        def entry(ip):return [(socket.AF_INET,socket.SOCK_STREAM,6,'',(ip,22))]
        with patch('connection.socket.getaddrinfo',return_value=entry('192.168.1.42')):
            self.assertEqual(lan_address('pocketllama.local'),'192.168.1.42')
        for ip in ('8.8.8.8','127.0.0.1','203.0.113.12'):
            with patch('connection.socket.getaddrinfo',return_value=entry(ip)),self.assertRaises(ValueError):
                lan_address('example.com')

    def test_usage_only_counts_server_reported_tokens(self):
        def handler(request):
            body=json.loads(request.content)
            self.assertTrue(body['stream_options']['include_usage'])
            events=[{'choices':[{'delta':{'content':'Hello'},'finish_reason':'stop'}]},
                    {'choices':[],'usage':{'prompt_tokens':123,'completion_tokens':7}}]
            return httpx.Response(200,content=''.join('data: '+json.dumps(e)+'\n\n' for e in events)+'data: [DONE]\n\n')
        model=Model(12345);model.http.close()
        model.http=httpx.Client(transport=httpx.MockTransport(handler),base_url=model.base)
        reports=[];model.on_usage=lambda m:reports.append(m)
        try:
            model.complete([],lambda *a:None,structured=False)
            self.assertEqual(reports[-1],{'generation_calls':1,'usage_reported_calls':1,'input_tokens':123,'output_tokens':7})
        finally:model.close()


if __name__=='__main__':unittest.main()
