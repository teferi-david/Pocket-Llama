@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run Install-Node-Llama.cmd first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" server.py
if errorlevel 1 (
  echo.
  echo Node Llama stopped with an error. If port 8877 is already in use,
  echo use the existing Node Llama window or close it before starting another.
  pause
)
