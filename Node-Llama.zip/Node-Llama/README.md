# Node Llama — Windows companion, preview 0.3

Node Llama lets your Windows PC use Pocket Llama as a local AI processing device.
Select the Pi in the chat box and give it a task. The model runs on the Pi; this
app creates and edits files on the Windows PC, checks their syntax, sends the
results back to the model, and repeats until it finishes or reaches its limit.

**This is an initial runnable build, not a claim that your current model can
reliably build a large game.** It is designed for small browser games, simple
web projects, scripts and text files. The included task example asks for a compact
2D block-building prototype. It is not a full Minecraft implementation.

The Pocket Llama touchscreen app, landscape configuration, loading animation,
speech and conversational prompt do not need to change. This companion uses the
existing model server. Build mode exists only in the Windows app.

## Connect by voice (new)

Update both apps using `VOICE-CONNECT.md`. In Windows open **DEVICES / CONNECT →
PAIR POCKET LLAMA**. On the Pi say **“Llama, connect to Node”**, select this computer
if asked, and enter its six-digit code on the touchscreen. Future connections use
remembered pairing with no password or SSH console. The Pi needs the one-time
`enable-node-link.sh` setup. Discovery selects a remembered computer; it does not
measure distance or Wi-Fi signal strength between computers.

The original manual SSH setup below remains available as a fallback. Node Llama
now also listens for authenticated pairing on TCP 8878 and advertises itself via
local mDNS. Windows firewall permission must be limited to your Private LAN.

## Update from the previous build

Close the Node Llama console and its SSH window. Extract this ZIP into your
existing Node-Llama folder and replace its application files. Run
Install-Node-Llama.cmd once, then Start-Node-Llama.cmd and refresh your browser.
Your Desktop projects, device settings and existing saved jobs are stored
separately and remain available. This update is for the Windows companion;
install the companion Pocket Llama update and run its one-time node-link setup
if you want voice pairing. Manual SSH still works without that Pi update.

The interface now follows the supplied monochrome pixel reference: striped
window bar, left chat list, animated llama and compact composer. The llama GIF
is the supplied Pocket Llama asset. Press Start 2P is bundled locally with its
OFL license; the UI loads no remote fonts or images. The greeting is in
`templates/index.html` and currently says “HI, DAVID.”

## Controls for mindful AI use

- **+ beside the message:** choose Chat or Build, project folder, identifier
  masking and whether to save this task's chat history.
- **CHAT / BUILD below the message:** toggle conversational mode or project-file
  tools. New sessions default to Chat; deliberately choose Build for file work.
- **REVIEW DATA:** shows the message after the local pattern check and the selected
  Pi destination before Send. Opening this preview does not contact the Pi.
- **FILES:** inspect project files and open the project folder or an HTML result.
- **API $0.00 / RECEIPT:** see destination, model, generation calls, reported token
  counts, history choice, changed files and checks for the selected task.
- **PRIVATE BY DESIGN:** inspect the actual data route and forget the selected chat.
- **DEVICES / CONNECT:** manage devices, open the SSH login window and check readiness.

Masking defaults on. It replaces supported email addresses, phone numbers,
SSN-shaped identifiers and labeled account/policy/serial IDs. It is a transparent
regular-expression check, not comprehensive PII detection. It can miss names,
street addresses, credentials and unusual formats, or mask an innocent number.
Review the result. Build context, including file excerpts, is also masked before
model requests. This can prevent an exact-text replacement from matching the
original file. The user can choose to turn masking off for a task.

The PC sends task text, model instructions, project filenames and requested
excerpts to the selected Pi over SSH. The application does not send them to a
cloud AI provider. New SSH connections resolve to private/link-local LAN
addresses; the resolved address is passed to SSH. This is not a system-wide
firewall or a guarantee about Windows sync or other applications. In particular,
Desktop projects may be synced by OneDrive independently of Node Llama.

Chat history defaults off. Task records then stay in app memory (up to 50 recent
in-memory jobs), and survive browser refreshes while the Python app stays open.
Opting in saves that task record on the PC. Forget removes the selected Node Llama
record from memory and disk. It does not securely erase OS copies, generated
files, overwrite backups or the Pi's model prompt cache. Old saved task records
from preview 0.1 remain until you choose to forget them.

Cloud AI API cost is $0.00 because no paid model provider is configured. This is
not a tracker for other subscriptions and does not include hardware/electricity.
Token usage comes from the model server's stream usage report. Missing and
interrupted reports are labeled incomplete, never estimated from character counts.

Task guidance uses simple local rules to flag requests requiring current sources,
large implementations or consequential conclusions. It is not a measured quality
score or automatic model router. The current choices are saved Pocket Llama devices;
a stronger PC model or a cloud model is not implemented in this build.

For a judge demonstration, use `HACKATHON-DEMO.md`. It includes fictional device
notes, a three-minute run of show, exact prompts, limits and a fallback.

## What runs where

| Component | Location |
|---|---|
| Qwen model and text generation | Pocket Llama's Pi CPU |
| Chat interface and agent loop | Windows PC |
| File writes, backups and syntax checks | Windows PC |
| Generated game and its graphics | Windows browser when you open it |
| Network transport | Encrypted OpenSSH connection on your local network |

This does not combine the PC's GPU/RAM with the Pi or make the Pi's model faster.
The current AI HAT+ 26 TOPS is not used for this GGUF inference path. Node Llama
connects to the model already running in `pocket-llm.service`.

## 1. Prepare the Pi once

Keep the Pi powered and connected to the same local network as the Windows PC.
Use the Pi terminal (in your kiosk, Ctrl+Alt+T opens the maintenance terminal).

Enable SSH:

```bash
sudo raspi-config
```

Choose **Interface Options → SSH → Enable**. Finish and return to the terminal.
Then run:

```bash
hostname -I
systemctl is-active pocket-llm
curl --max-time 10 http://127.0.0.1:8080/health
ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub
```

Record the Pi's IPv4 address, such as `192.168.1.42`, and its SSH fingerprint.
The service should report `active` and the health response should be
`{"status":"ok"}`. A loading/503 response means the model needs more time.
If the service is inactive, run `sudo systemctl start pocket-llm` and retry.

Leave the model on **127.0.0.1:8080**. Node Llama uses SSH forwarding, so you do
not need to expose port 8080 on your router or change the model startup command.

## 2. Install the Windows companion

1. Download and extract `Node-Llama.zip` using **Extract All**. Run the files from
   the extracted `Node-Llama` folder, not from inside the ZIP viewer.
2. Install 64-bit Python 3.12 or 3.13 from
   [python.org](https://www.python.org/downloads/windows/), including its launcher.
   The installer script expects `py -3` to work. Python 3.11+ is supported by the
   app; 3.12/3.13 are the intended starting point.
3. Install Node.js LTS from [nodejs.org](https://nodejs.org/en/download). It is
   used for JavaScript **syntax checking**, including scripts inside HTML games.
   Restart Node Llama after installing it so the updated PATH is available.
4. Check `ssh -V` in Windows Terminal. If SSH is missing, add **OpenSSH Client**
   under Windows **Optional features**. You do not need the Windows SSH Server.
5. Double-click **Install-Node-Llama.cmd**. It creates a local Python environment
   and installs the requirements. This first install needs internet access.
6. Double-click **Start-Node-Llama.cmd**. A browser opens at
   **http://127.0.0.1:8877**. Keep the app's console window open.

After installation and model download, the app and Pi can communicate without an
internet connection. Node Llama does not use a cloud model, telemetry or CDN UI
assets. Your Desktop may separately be synced by OneDrive; Windows decides that.

## 3. Connect your Pocket Llama

Open **DEVICES / CONNECT** at the bottom of the sidebar. A default device is saved as **Pocket Llama / pocket@pocketllama.local**.

1. Click **Connect**. A Windows SSH window opens.
2. On the first connection, compare its ED25519 fingerprint with the Pi command
   above. Accept a matching host and enter your **Pi login password**. Characters
   will not appear while typing. If your Pi was configured for key-only login,
   use its existing SSH key instead.
3. The window may become blank after login. That is normal: it is carrying the
   encrypted tunnel. Keep it open.
4. Return to Node Llama and click **Check** on the device card. Expect
   **Connected · model ready** and the model name.
5. Select **Pocket Llama** in the device dropdown inside the chat composer.

If `pocketllama.local` does not resolve, click **+ ADD DEVICE** in the devices dialog and
add a device using the IPv4 address from `hostname -I`, username `pocket`, and
your preferred display name. Connect that entry. Remove the unused default entry
if desired. Manual devices are selected here; the new Pi voice-pairing flow discovers Node Llama
computers through local mDNS.

Each new app session needs a Connect action (or the Pi voice command for a paired
device). Manual SSH uses its normal host verification
and credentials; Node Llama does not collect or save your Pi password. Click
Disconnect, or close the SSH window, to disconnect the device. Reconnect after a
Pi restart or a network drop. If an old tunnel is unresponsive, Disconnect first.

## 4. Start with one small task

Leave Pocket Llama's voice UI idle while a Windows task runs. The current Pi server
has one model slot; talking to it simultaneously can queue requests and slow both
interfaces. This build does not lock the touchscreen or coordinate a second client.

Click **CHAT** under the composer to change it to **BUILD · FILES**. Use **+** beside the message to choose your project. Try:

> Create hello.html with a heading that says Hello from Pocket Llama and a button
> that changes the page background color. Make it work offline. Check the file.

Choose a Desktop project name, such as **First Test**, and send. Watch the action
notes and expand **Result** to inspect actual tool output. Click **FILES** below the composer, then a filename to read it. For an HTML file, click **OPEN HTML IN BROWSER** to try it.

For a game, choose **Block World** in task settings and paste this task:

> Create a small playable 2D Minecraft-inspired block-building game in index.html.
> Use canvas and plain JavaScript, no downloads. Let me move with A/D, jump with
> Space, and place or remove blocks with the mouse. Show controls and check the
> code. Keep it compact.

Files go into your actual Windows Desktop location:

```text
Desktop\Node Llama Projects\Block World\index.html
```

The Desktop is resolved through the Windows Known Folder API, including a
redirected/OneDrive Desktop. The interface displays the resolved folder path.
Click **FILES → OPEN FOLDER** to see files in Explorer. No executable installer is built
for the game; this example is a local browser game.

Use the same project name for a follow-up such as “The character falls through the
floor. Read the existing code and fix the collision check.” The agent can inspect
the saved files. Each Send starts a fresh bounded task; it does not carry the
entire previous chat into the model. State the change clearly. Recent Tasks lets
you inspect earlier actions and results.

**Chat · conversation** makes a conversational request without file tools. The
selected project provides the location for a task record but chat does not edit
its files. Node Llama is keyboard/chat driven in this build; Pi voice commands do
not trigger Windows actions.

## Timing and limitations on your Pi

Your earlier benchmark returned about 4–5 generated tokens per second. A coding
step can require hundreds of tokens; expect minutes for a small project and
potentially much longer across repairs. This is a rough extrapolation, not a
measured Node Llama benchmark. The progress display reports elapsed generation
time and characters received, not an invented completion countdown.

The 2B model has limited coding/planning ability. Grammar-constrained JSON makes
actions parseable; it does not make the code correct. A model can still repeat a
mistake or make a game that passes syntax checks but plays badly. Try small tasks
first. The harness reads the model's real tokenizer/template to keep each request
within the configured 4,096-token context, with room for a 1,400-token response.
Each task has a 24-step cap and each model request a 20-minute streaming deadline
(network reads have a 10-minute timeout). Oversized output is rejected rather than
being written as a partial file. Ask for smaller sections if it repeatedly hits
the output limit. A repeated identical action stops the run.

**Files ready for review** means the agent finished and each file it changed had
a check with no reported failure. It is not a gameplay certification. Python
checks parse syntax; JS checks use `node --check`; HTML checks examine inline and
local scripts, obvious truncation and script/stylesheet dependencies. Text/CSS
checks can be marked skipped. If Node.js is absent, JavaScript checks explicitly
say skipped. The app never silently labels skipped checks as a passed runtime test.

This version supports agentic project-file work, not arbitrary Windows desktop
control, terminal commands, software installation or unrestricted disk access.
Tools can create/read/append/replace/check supported text files inside the selected
project. Generated programs are not automatically executed. You open a browser game
from its file viewer when ready. No administrator rights are needed to run the app.

## Stop, recover and back up

**Stop** cancels generation and prevents new edits from starting. Already-finished
writes remain. It can take a moment for a blocked model connection to close; the
app will not start a second task while its worker is still exiting. Stop does not
restart the Pi or kill its model service.

Opt-in saved job records and device addresses are stored in:

```text
%LOCALAPPDATA%\NodeLlama\jobs
%LOCALAPPDATA%\NodeLlama\devices.json
```

Before replacing or appending an existing file, the previous version is copied to:

```text
%LOCALAPPDATA%\NodeLlama\backups\PROJECT\REVISION\relative\file.ext
```

Restore by copying the needed backup over the project file while no task is
running. Backups and opt-in logs are local and retained until removed. Use **PRIVATE BY DESIGN → FORGET SELECTED CHAT** to remove a task record; backups remain. Relaunching the app marks unfinished saved records interrupted; memory-only records are gone. Send a follow-up to continue from the files that were already saved.

Close the Node Llama console to stop the Windows app and close any remaining SSH
window. Closing just the browser tab leaves the app running.

## Troubleshooting

| Symptom | What to do |
|---|---|
| SSH hostname fails | Use the Pi's current IPv4 address; ensure both devices are on the same LAN, not an isolated guest Wi-Fi. |
| SSH connection refused | Enable SSH on the Pi; check it is powered and reachable. |
| SSH window closes | Test `ssh pocket@PI_ADDRESS` in Windows Terminal to read the error. |
| Password rejected | Use the Pi user password or its configured SSH key. Windows passwords are unrelated. |
| SSH connected but Check fails | Verify `pocket-llm` and `curl http://127.0.0.1:8080/health` on the Pi; leave the SSH window open. |
| 503 / model loading | Wait for Pi model startup, then Check again. |
| Model rejects schema/template request | Keep the full error from the task log. This build targets the recent llama.cpp server already installed for Pocket Llama; it requires `/apply-template`, `/tokenize` and schema JSON chat output. |
| UI says 403 after app restart | Refresh the tab so it receives the new local session token. |
| No JavaScript checker | Install Node.js LTS and restart the Node Llama console. |
| Repeated incomplete output | Ask for smaller files or shorter append steps. No incomplete action was applied. |
| Ready but game does not work | Open it, describe the concrete failure, and send a follow-up in the same project. Syntax checks cannot verify playability. |
| Port 8877 already in use | Use the existing Node Llama window, or stop it before relaunching. |

## Developer notes and verification

The Windows UI binds only to 127.0.0.1. Its JSON API requires a per-run token and
checks Host and Origin. The browser never receives the SSH password or direct Pi
access. Model responses use a validated action schema rather than depending on
the model's native function-call template. Text path checks reject traversal,
Windows device names, alternate data streams, junctions, symlinks and hard links.
Do not replace project directories externally while a task runs; these are file
scope checks, not a Windows kernel sandbox. Files are capped at 256 KB, projects
at 5 MB / 200 supported files. Generated HTML is opened separately, never served
under the privileged harness origin.

The initial validation uses simulated model responses and real local file tools.
It is not a live Pi model or Windows hardware test. See `VALIDATION.md` for the
executed checks and outstanding hardware verification.

Run the tests on Windows after installing:

```powershell
.venv\Scripts\python.exe -m unittest -v
```

For development on Linux/macOS, the Python server and file tools work with an
explicit project directory supplied to `State`. The Connect and Open buttons
target Windows. A manual SSH tunnel can forward a chosen localhost port to the
Pi's 127.0.0.1:8080, but the current UI does not expose manual-port configuration.

Primary references used for this build:

- [Raspberry Pi SSH setup](https://www.raspberrypi.com/documentation/computers/remote-access.html)
- [Microsoft OpenSSH setup](https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_install_firstuse)
- [OpenSSH forwarding options](https://man.openbsd.org/ssh)
- [llama.cpp server endpoints](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md)
- [Windows Desktop known folder](https://learn.microsoft.com/en-us/windows/win32/shell/knownfolderid)
- [Flask with Waitress on Windows](https://flask.palletsprojects.com/en/stable/deploying/waitress/)
- [Press Start 2P font and license](https://github.com/google/fonts/tree/main/ofl/pressstart2p)
