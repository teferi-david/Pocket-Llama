"""Node Llama: desktop-local UI and Windows file harness."""
import atexit
import json
import os
from pathlib import Path
import secrets
import threading
import webbrowser

from flask import Flask, abort, jsonify, render_template, request
from waitress import create_server

from agent import Job
from connection import Connections, validate_device
from model import Model
from mindful import inspect
from workspace import Workspace, atomic_json, desktop, is_link, project_name

PORT = 8877


class State:
    def __init__(self, data=None, projects=None):
        self.data = Path(data or (Path(os.environ.get('LOCALAPPDATA', Path.home() / '.local' / 'share')) / 'NodeLlama'))
        self.data.mkdir(parents=True, exist_ok=True)
        self.projects = Path(projects or desktop() / 'Node Llama Projects')
        self.projects.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.connections = Connections()
        self.pairing = None
        self.model_factory = Model
        self.active = None
        self.session_jobs = {}
        self.device_status = {}
        self.thread = None
        self.token = secrets.token_urlsafe(32)
        cfg = self.data / 'devices.json'
        if cfg.exists():
            self.devices = json.loads(cfg.read_text(encoding='utf-8'))
            for device in self.devices:
                validate_device(device)
        else:
            self.devices = [validate_device({'name': 'Pocket Llama', 'host': 'pocketllama.local', 'user': 'pocket'})]
            self.save_devices()
        for path in (self.data / 'jobs').glob('*.json'):
            value = json.loads(path.read_text(encoding='utf-8'))
            if value['status'] in ('running', 'stopping'):
                value['status'] = 'interrupted'
                atomic_json(path, value)

    def save_devices(self):
        atomic_json(self.data / 'devices.json', self.devices)

    def busy(self):
        return self.thread is not None and self.thread.is_alive()

    def device(self, device_id):
        found = next((d for d in self.devices if d['id'] == device_id), None)
        if found is None:
            raise ValueError('Select a saved device.')
        return found

    def workspace(self, name):
        return Workspace(self.projects, name, self.data / 'backups' / project_name(name))

    def job(self, job_id):
        if len(job_id) != 32 or any(c not in '0123456789abcdef' for c in job_id):
            raise ValueError('Invalid task ID.')
        if self.active and self.active.id == job_id:
            return self.active.snapshot()
        if job_id in self.session_jobs:
            return self.session_jobs[job_id].snapshot()
        path = self.data / 'jobs' / (job_id + '.json')
        if not path.exists():
            raise ValueError('Task not found.')
        return json.loads(path.read_text(encoding='utf-8'))

    def close(self):
        if self.active and self.busy():
            self.active.stop()
        if self.pairing:
            self.pairing.close()
        self.connections.close()


def create_app(state=None):
    state = state or State()
    app = Flask(__name__)
    app.config['MAX_CONTENT_LENGTH'] = 64_000
    app.config['STATE'] = state

    @app.before_request
    def local_only():
        if request.host not in (f'127.0.0.1:{PORT}', f'localhost:{PORT}'):
            abort(403)
        origin = request.headers.get('Origin')
        if origin and origin != 'http://' + request.host:
            abort(403)
        if request.path.startswith('/api/') and not secrets.compare_digest(
                request.headers.get('X-Node-Token', ''), state.token):
            abort(403)

    @app.after_request
    def headers(response):
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'"
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.errorhandler(ValueError)
    def bad_request(exc):
        return jsonify(error=str(exc)), 400

    @app.errorhandler(OSError)
    def io_error(exc):
        return jsonify(error=f'File or connection error: {exc}'), 400

    @app.get('/')
    def home():
        return render_template('index.html', token=state.token)

    @app.get('/api/state')
    def get_state():
        names = sorted(p.name for p in state.projects.iterdir() if p.is_dir() and not is_link(p))
        jobs = {}
        for path in sorted((state.data / 'jobs').glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True)[:30]:
            value = json.loads(path.read_text(encoding='utf-8'))
            jobs[value['id']] = {k: value[k] for k in ('id', 'prompt', 'project', 'status', 'created')}
        for job_id, job in state.session_jobs.items():
            value = job.snapshot()
            jobs[job_id] = {k: value[k] for k in ('id', 'prompt', 'project', 'status', 'created')}
        rows = sorted(jobs.values(), key=lambda v: v['created'], reverse=True)[:30]
        return jsonify(devices=state.devices, projects=names, folder=str(state.projects), jobs=rows,
                       device_status=state.device_status,
                       pairing=state.pairing.snapshot() if state.pairing else None,
                       active=state.active.id if state.busy() else None)

    @app.post('/api/pairing/open')
    def open_pairing():
        if not state.pairing:
            raise ValueError('Restart Node Llama to enable pairing.')
        return jsonify(state.pairing.open_pairing())

    @app.post('/api/pairing/forget/<pi_id>')
    def forget_pairing(pi_id):
        if not state.pairing:
            raise ValueError('Pairing is unavailable.')
        state.pairing.forget(pi_id)
        return jsonify(message='Pairing removed from this PC. On Pocket Llama use Node > Forget all to revoke its SSH key too.')

    @app.post('/api/inspect')
    def inspect_prompt():
        data = request.get_json()
        prompt = data.get('prompt', '')
        if not isinstance(prompt, str) or len(prompt) > 2400:
            raise ValueError('Enter up to 2,400 characters.')
        return jsonify(inspect(prompt, data.get('mask', True) is True))

    @app.post('/api/devices')
    def add_device():
        device = validate_device(request.get_json())
        with state.lock:
            if len(state.devices) >= 10:
                raise ValueError('Device limit is 10.')
            state.devices.append(device)
            state.save_devices()
        return jsonify(device)

    @app.post('/api/devices/<device_id>/<operation>')
    def device_action(device_id, operation):
        with state.lock:
            device = state.device(device_id)
            if operation in ('disconnect', 'delete') and state.busy():
                raise ValueError('Stop the active task before disconnecting or removing a device.')
            if operation == 'connect' and device.get('paired'):
                if not state.pairing:
                    raise ValueError('Restart Node Llama to enable pairing.')
                message = state.pairing.connect_pi(device['id'].removeprefix('paired-'), device['host'])
                return jsonify(message=message)
            if operation == 'connect':
                state.connections.connect(device)
                state.device_status[device_id] = {'ready': False, 'message': 'Complete SSH login, then Check.'}
                return jsonify(message='Complete SSH login in the new window, then click Check connection. Keep that window open.')
            if operation == 'check':
                port = state.connections.port(device_id)
                model = state.model_factory(port)
                try:
                    value = model.health()
                    state.device_status[device_id] = value
                    return jsonify(value)
                except Exception as exc:
                    value = {'ready': False, 'message': 'Not ready: ' + str(exc)[:500]}
                    state.device_status[device_id] = value
                    return jsonify(value)
                finally:
                    model.close()
            if operation in ('disconnect', 'delete'):
                state.connections.disconnect(device_id)
                state.device_status.pop(device_id, None)
                if operation == 'delete':
                    if device.get('paired') and state.pairing:
                        state.pairing.forget(device_id.removeprefix('paired-'))
                    state.devices = [d for d in state.devices if d['id'] != device_id]
                    state.save_devices()
                return jsonify(message='Device ' + ('removed.' if operation == 'delete' else 'disconnected.'))
            abort(404)

    @app.post('/api/jobs')
    def start_job():
        data = request.get_json()
        prompt = data.get('prompt', '').strip()
        mode = data.get('mode', 'build')
        if not 1 <= len(prompt) <= 2400 or mode not in ('build', 'chat'):
            raise ValueError('Enter a task up to 2,400 characters and choose Build or Chat.')
        with state.lock:
            if state.busy():
                raise ValueError('A task is still running. Stop it or wait for it to finish.')
            device = state.device(data.get('device'))
            port = state.connections.port(device['id'])
            workspace = state.workspace(data.get('project', ''))
            mask = data.get('mask', True) is True
            privacy = inspect(prompt, mask)
            job = Job(state.data / 'jobs', workspace, privacy['outbound_prompt'], device, mode,
                      keep_history=data.get('keep_history', False) is True, mask=mask, privacy=privacy)
            state.active = job
            state.session_jobs[job.id] = job
            if len(state.session_jobs) > 50:
                state.session_jobs.pop(next(iter(state.session_jobs)))
            state.thread = threading.Thread(target=job.run, args=(state.model_factory(port, cancel=job.cancel),), daemon=True)
            state.thread.start()
        return jsonify(job.snapshot())

    @app.get('/api/jobs/<job_id>')
    def get_job(job_id):
        return jsonify(state.job(job_id))

    @app.post('/api/jobs/<job_id>/stop')
    def stop_job(job_id):
        with state.lock:
            if state.active and state.active.id == job_id:
                state.active.stop()
        return jsonify(message='Stop requested. No new edits will begin; the current model request may take a moment to close.')

    @app.post('/api/jobs/<job_id>/forget')
    def forget_job(job_id):
        with state.lock:
            state.job(job_id)  # Validate ID before using it as a filename.
            if state.active and state.active.id == job_id and state.busy():
                raise ValueError('Stop this task and wait for it to finish before forgetting its history.')
            (state.data / 'jobs' / (job_id + '.json')).unlink(missing_ok=True)
            state.session_jobs.pop(job_id, None)
            if state.active and state.active.id == job_id:
                state.active = None
        return jsonify(message='Node Llama chat history removed. Project files, backups, OS copies and the Pi prompt cache are not erased.')

    @app.get('/api/files')
    def files():
        workspace = state.workspace(request.args.get('project', ''))
        name = request.args.get('path')
        return jsonify(text=workspace.read(name), path=name) if name else jsonify(files=workspace.files())

    @app.post('/api/open')
    def open_file():
        data = request.get_json()
        workspace = state.workspace(data.get('project', ''))
        name = data.get('path')
        target = workspace.path(name) if name else workspace.root
        if name and target.suffix.lower() not in ('.html', '.htm'):
            raise ValueError('Only HTML files can be opened from the app. Use Open folder for other files.')
        if not target.exists():
            raise ValueError('File not found.')
        if os.name != 'nt':
            raise ValueError('Open folder/game is available on Windows. The path is shown in the interface.')
        os.startfile(str(target))
        return jsonify(message='Opened in Windows.')

    return app


def main():
    state = State()
    atexit.register(state.close)
    app = create_app(state)
    # Bind before opening the browser; a second launch cannot start a duplicate harness.
    server = create_server(app, host='127.0.0.1', port=PORT, threads=8,
                           max_request_body_size=64000, channel_timeout=60)
    from pairing import Pairing
    state.pairing = Pairing(state)
    state.pairing.start()
    address = f'http://127.0.0.1:{PORT}'
    print(f'Node Llama is running at {address}\nProjects: {state.projects}\nClose this window to stop the app.')
    webbrowser.open(address)
    try:
        server.run()
    finally:
        state.close()


if __name__ == '__main__':
    main()
