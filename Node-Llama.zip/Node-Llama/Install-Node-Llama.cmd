@echo off
setlocal
cd /d "%~dp0"
echo Installing Node Llama for this Windows user...
where py >nul 2>&1
if errorlevel 1 (
  echo Install Python 3.12 or 3.13 from python.org, including the Python launcher.
  echo Then run this file again.
  pause
  exit /b 1
)
py -3 -c "import sys; assert sys.version_info >= (3,11), 'Python 3.11 or newer is required'"
if errorlevel 1 goto failed
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
where ssh >nul 2>&1
if errorlevel 1 echo OpenSSH Client is missing. Enable it in Windows Settings - Optional features before connecting.
where node >nul 2>&1
if errorlevel 1 echo Install Node.js LTS from nodejs.org to enable JavaScript syntax checking.
echo.
echo Installation complete. Double-click Start-Node-Llama.cmd.
pause
exit /b 0
:failed
echo Installation failed. Read the error above before retrying.
pause
exit /b 1
