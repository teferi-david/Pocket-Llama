$ErrorActionPreference = 'Stop'
$nodePython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path $nodePython)) { throw 'Run Install-Node-Llama.cmd first.' }
$nodeIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$nodePrincipal = [Security.Principal.WindowsPrincipal]::new($nodeIdentity)
if (-not $nodePrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Open PowerShell as Administrator, then run this file again.'
}
foreach ($rule in @(@{Name='NodeLlama-Pairing';Protocol='TCP';Port=8878},@{Name='NodeLlama-Discovery';Protocol='UDP';Port=5353})) {
    if (Get-NetFirewallRule -Name $rule.Name -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -Name $rule.Name
    }
    New-NetFirewallRule -Name $rule.Name -DisplayName $rule.Name -Direction Inbound -Action Allow -Profile Private -Program $nodePython -Protocol $rule.Protocol -LocalPort $rule.Port -RemoteAddress LocalSubnet | Out-Null
}
Write-Host 'Node Llama discovery is allowed on Private local networks only. Restart Node Llama.'
