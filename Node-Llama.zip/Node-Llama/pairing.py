"""Code-paired LAN discovery. All model traffic still uses pinned OpenSSH."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import socket
import socketserver
import ssl
import threading
import time
import uuid

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, rsa
from cryptography.x509.oid import NameOID
from spake2 import SPAKE2_B

from node_protocol import (PORT, SERVICE, VERSION, addresses, authenticate, b64, identifier,
                           local_ip, proof, receive, send, ssh_key, unb64, write_json)


class Pairing:
    def __init__(self, state, port=PORT, allow_loopback=False):
        self.state, self.port, self.allow_loopback = state, port, allow_loopback
        self.root = state.data / 'pairing'
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.config_path = self.root / 'identity.json'
        self.config = json.loads(self.config_path.read_text()) if self.config_path.exists() else {
            'id': uuid.uuid4().hex, 'name': socket.gethostname()[:50], 'peers': {}}
        self.code, self.expires, self.attempts = '', 0, 0
        self.message = 'Say “Llama, connect to Node” on Pocket Llama.'
        self.server = self.zc = self.info = None
        self.slots = threading.BoundedSemaphore(4)
        self._keys()
        write_json(self.config_path, self.config)

    def _keys(self):
        key_path, cert_path = self.root/'tls-key.pem', self.root/'tls-cert.pem'
        if not key_path.exists() or not cert_path.exists():
            key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Node Llama')])
            now = datetime.datetime.now(datetime.timezone.utc)
            cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
                    .public_key(key.public_key()).serial_number(x509.random_serial_number())
                    .not_valid_before(now-datetime.timedelta(days=1))
                    .not_valid_after(now+datetime.timedelta(days=3650)).sign(key, hashes.SHA256()))
            key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM,
                                 serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
            cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        cert = x509.load_pem_x509_certificate(cert_path.read_bytes())
        self.fingerprint = cert.fingerprint(hashes.SHA256()).hex()
        self.tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        self.tls.minimum_version = ssl.TLSVersion.TLSv1_2
        self.tls.load_cert_chain(cert_path, key_path)
        self.ssh_private = self.root / 'node_ed25519'
        if not self.ssh_private.exists():
            key = ed25519.Ed25519PrivateKey.generate()
            self.ssh_private.write_bytes(key.private_bytes(serialization.Encoding.PEM,
                                         serialization.PrivateFormat.OpenSSH, serialization.NoEncryption()))
        key = serialization.load_ssh_private_key(self.ssh_private.read_bytes(), password=None)
        self.ssh_public = key.public_key().public_bytes(serialization.Encoding.OpenSSH,
                                                        serialization.PublicFormat.OpenSSH).decode()
        if os.name != 'nt':
            self.root.chmod(0o700)
            key_path.chmod(0o600)
            self.ssh_private.chmod(0o600)

    def open_pairing(self):
        with self.lock:
            if self.server is None:
                raise ValueError(self.message)
            self.code = f'{secrets.randbelow(1000000):06d}'
            self.expires = time.monotonic()+120
            self.attempts = 0
            self.message = 'Enter this code on your Pocket Llama. It expires in two minutes.'
        return self.snapshot()

    def snapshot(self):
        with self.lock:
            remaining = max(0, int(self.expires-time.monotonic()))
            return {'name': self.config['name'], 'id': self.config['id'], 'port': self.port,
                    'addresses': addresses(), 'available': self.server is not None,
                    'code': self.code if remaining and self.attempts < 5 else '',
                    'seconds': remaining, 'message': self.message,
                    'paired': [{'id': k, 'name': v['name']} for k,v in self.config['peers'].items()]}

    def start(self):
        manager = self
        class Server(socketserver.ThreadingTCPServer):
            allow_reuse_address = True
            daemon_threads = True
        class Handler(socketserver.BaseRequestHandler):
            def handle(self):
                if not (local_ip(self.client_address[0]) or manager.allow_loopback and self.client_address[0]=='127.0.0.1'):
                    return
                if not manager.slots.acquire(blocking=False):
                    return
                try:
                    self.request.settimeout(20)
                    with manager.tls.wrap_socket(self.request, server_side=True) as sock:
                        with sock.makefile('rwb') as stream:
                            try:
                                manager.exchange(stream, self.client_address[0])
                            except Exception as exc:
                                try:
                                    send(stream, {'error': str(exc)[:240]})
                                except Exception:
                                    pass
                except (OSError, ValueError):
                    pass
                finally:
                    manager.slots.release()
        try:
            self.server = Server(('127.0.0.1' if self.allow_loopback else '0.0.0.0', self.port), Handler)
            self.port = self.server.server_address[1]
            threading.Thread(target=self.server.serve_forever, daemon=True).start()
            if not self.allow_loopback:
                from zeroconf import Zeroconf, ServiceInfo, IPVersion
                ips = addresses()
                if not ips:
                    self.message = 'Connect this PC to your private Wi-Fi/LAN, then restart Node Llama.'
                    return
                self.zc = Zeroconf(ip_version=IPVersion.V4Only)
                self.info = ServiceInfo(SERVICE, self.config['id']+'.'+SERVICE,
                    addresses=[socket.inet_aton(ip) for ip in ips], port=self.port,
                    properties={'version':str(VERSION),'id':self.config['id'],'name':self.config['name']},
                    server='node-'+self.config['id']+'.local.')
                self.zc.register_service(self.info)
        except Exception as exc:
            self.message = 'Discovery unavailable: '+str(exc)[:180]+'. Check firewall/network and restart.'

    def exchange(self, stream, address):
        request = receive(stream)
        pi_id = identifier(request.get('pi_id'))
        if request.get('version') != VERSION or request.get('node_id') != self.config['id']:
            raise ValueError('Device identity or version changed. Discover again.')
        operation = request.get('operation')
        if operation == 'pair':
            with self.lock:
                if not self.code or time.monotonic() >= self.expires or self.attempts >= 5:
                    raise ValueError('On the computer, open Devices / Connect and press PAIR POCKET LLAMA.')
                self.attempts += 1
                code, expiry = self.code, self.expires
            spake = SPAKE2_B(code.encode(), idA=pi_id.encode(), idB=self.config['id'].encode())
            outbound = spake.start()
            key = spake.finish(unb64(request.get('exchange')))
            send(stream, {'exchange':b64(outbound), 'proof':proof(key,'node',self.fingerprint,self.config['id'],pi_id)})
            confirmation = receive(stream)
            authenticate(confirmation.get('proof'), proof(key,'pocket',self.fingerprint,self.config['id'],pi_id))
            with self.lock:
                if code != self.code or expiry != self.expires or time.monotonic() >= self.expires:
                    raise ValueError('Code expired or was already used. Open a new pairing code.')
                self.code, self.expires = '', 0
            token = secrets.token_urlsafe(32)
            send(stream, {'id':self.config['id'],'name':self.config['name'],
                          'ssh_key':self.ssh_public,'token':token})
            details = receive(stream)
            user, hostkey, name = self.validate_details(details)
            with self.lock:
                self.config['peers'][pi_id] = {'token_hash':hashlib.sha256(token.encode()).hexdigest(),
                                              'user':user,'hostkey':hostkey,'name':name}
                write_json(self.config_path,self.config)
            # Persisted before trying SSH: a failed initial connection can be retried.
            send(stream, {'paired':True})
            message = self.connect_pi(pi_id, address)
            send(stream, {'message':message})
            return
        if operation not in ('connect','disconnect'):
            raise ValueError('Unknown pairing operation.')
        with self.lock:
            peer = self.config['peers'].get(pi_id)
        if not peer:
            raise ValueError('This computer forgot the pairing. Pair again with a new code.')
        token = request.get('token', '')
        if not isinstance(token,str) or len(token)>100:
            raise ValueError('Invalid device credential.')
        authenticate(hashlib.sha256(token.encode()).hexdigest(), peer['token_hash'])
        if operation == 'disconnect':
            if self.state.busy():
                raise ValueError('Stop the Windows task first, then disconnect.')
            self.state.connections.disconnect('paired-'+pi_id)
            self.state.device_status.pop('paired-'+pi_id,None)
            send(stream, {'message':'Disconnected from '+self.config['name']})
            return
        message = self.connect_pi(pi_id,address)
        send(stream, {'message':message})

    @staticmethod
    def validate_details(value):
        user = value.get('user','')
        if not isinstance(user,str) or not re.fullmatch(r'[a-zA-Z_][a-zA-Z0-9_-]{0,31}',user):
            raise ValueError('Invalid Pi account name.')
        name = value.get('name','Pocket Llama')
        if not isinstance(name,str) or not 1 <= len(name)<=60:
            raise ValueError('Invalid device name.')
        return user, ssh_key(value.get('hostkey')), name

    def connect_pi(self, pi_id, address):
        with self.state.lock:
            if self.state.busy():
                raise ValueError('Wait for the active Windows task to finish before reconnecting.')
            peer = self.config['peers'][pi_id]
            device = {'id':'paired-'+pi_id,'name':peer['name'],'host':address,'user':peer['user'],
                      'paired':True,'hostkey':peer['hostkey']}
            old = next((d for d in self.state.devices if d['id']==device['id']),None)
            if old:
                old.update(device)
            else:
                self.state.devices.append(device)
            self.state.save_devices()
            try:
                self.state.connections.connect_paired(device,self.ssh_private,self.root)
                port = self.state.connections.port(device['id'])
                model = self.state.model_factory(port)
                try:
                    status = model.health()
                finally:
                    model.close()
                self.state.device_status[device['id']] = status
                self.message = 'Connected to '+peer['name'] if status['ready'] else status['message']
            except Exception as exc:
                self.message = 'Paired; connection needs attention: '+str(exc)[:200]
                self.state.device_status[device['id']] = {'ready':False,'message':self.message}
                raise ValueError(self.message) from exc
            return self.message

    def forget(self, pi_id):
        identifier(pi_id)
        if self.state.busy():
            raise ValueError('Stop the task before forgetting a device.')
        with self.lock:
            self.config['peers'].pop(pi_id,None)
            write_json(self.config_path,self.config)
        self.state.connections.disconnect('paired-'+pi_id)
        with self.state.lock:
            self.state.devices = [d for d in self.state.devices if d['id']!='paired-'+pi_id]
            self.state.device_status.pop('paired-'+pi_id,None)
            self.state.save_devices()

    def close(self):
        if self.zc:
            self.zc.close()
            self.zc = None
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
